#include<stdio.h>
void main()
{
	int x =-1.345;
	printf(" x = %d \n", x);
}
