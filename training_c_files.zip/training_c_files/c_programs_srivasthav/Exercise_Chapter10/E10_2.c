/*E10.2*/
#include<stdio.h>
int main(void)
{
/*	char *str;
	printf("Enter a string : ");
	gets(str);              //  segmentation fault
	printf("String is %s\n",str);
	return 0;*/
	char str[20];
	printf("Enter a string : ");
	gets(str);
	printf("String is %s\n",str);
	return 0;
}
