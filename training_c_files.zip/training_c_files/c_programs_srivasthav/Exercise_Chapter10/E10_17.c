/*E10.17*/
#include<stdio.h>
#include<string.h>
int main(void)
{
	int x=10;
	unsigned int y=5;
	if((y-x)>0)
	{
		printf("unsigned\n");
	}
	else
		printf("signed");
	char str1[]="Parul";
	char str2[]="Devanshi";
	//printf("%ld\n",strlen(str2));
	//long int d=strlen(str1)-strlen(str2) ;
	if((strlen(str1) - strlen(str2))>=0)
		puts(str1);
	else
		puts(str2);
	return 0;
}
