/*E10.10*/
#include<stdio.h>
int main(void)
{
	printf("1%c\t","Determination"[2]);
	printf("2%c\t",*("Determination"+2));
	printf("3%s\t","Determination"+2);
	printf("Determination"+2);
	printf("\t5");
	printf("Determination"+strlen("Deepali"));
	printf("\t6");
	printf("Determination"+sizeof("Deepali"));
	printf("return\n");
	return 0;
}
