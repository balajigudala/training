/*E10.16*/
#include<stdio.h>
#include<string.h>
int main(void)
{
	char str1[]="deep";
	char str2[]={'d','e','e','p'};
	printf("%s\n",str2);
	if(strcmp(str1,str2)==0)
		printf("Same\n");
	else
		printf("Different\n");
	printf("%s\n%s\n",str1,str2);
	return 0;
}
