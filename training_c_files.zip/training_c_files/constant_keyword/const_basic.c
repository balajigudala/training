#include<stdio.h>
int main()
{
	const char x=20;
	printf("%c\n",x);
}
