#include<stdio.h>
void myread(char*,int n);
char* mystrcpy(char*,const char*);

/* void myread(char *ptr,int n)
{
        int i;
        printf("enter the elements : ");
        for(i=0;i<n;i++)
        {
                __fpurge(stdin);
                scanf("%c",&ptr[i]);
        }
}  */

char* mystrcpy(char*dst,const char*src)
{
	int i;
	for(i=0;src[i]!='\0';i++)
	dst[i]=src[i];
	dst[i]='\0';
	src[4]='/';
	return dst;
}

int main()
{
	int n;
	char src[50],dst[50];
	printf("enter the string ");
	scanf("%s",src);
//	printf("%s",src);
	mystrcpy(dst,src);
	printf("%s",src);
	printf("%s",dst);
}
