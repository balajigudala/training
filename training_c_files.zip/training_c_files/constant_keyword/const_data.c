#include<stdio.h>
int main()
{
	const char x=20;
	char* ptr=&x;
	//x=30;   here we cant modify data directly by using variable name
	printf("%d\n",++(*ptr));//modify data by using adrees of that variable
}
//output : 21

