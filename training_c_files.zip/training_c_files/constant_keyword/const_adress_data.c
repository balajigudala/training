#include<stdio.h>
int main()
{
	int  x=20;
	int y=40;
        const  int * const ptr=&x;
        //ptr=&x; invalid statement;we cant modify adress here
//	ptr=20; invalid statement
}
// in this program we cnat modify both data and adrees applied with constant keyword

