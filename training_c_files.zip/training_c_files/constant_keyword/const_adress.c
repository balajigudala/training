#include<stdio.h>
int main()
{
	int  x=20;
	int y=40;
        int * const ptr=&x;
        //ptr=&x; invalid statement;we cant modify adress here
//	ptr=20; invalid statement
	*ptr=40;
	printf("%d\n",*ptr);
}
//output : 21


