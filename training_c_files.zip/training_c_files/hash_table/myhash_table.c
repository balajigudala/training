#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX_NAME 32
#define SIZE 10

//   ************** structure for hash able  ***********

struct student
{
	unsigned char age;
	char gender;
	char name[MAX_NAME];
};



struct student *ptr[SIZE];

//  *********** setting the hash table with NULL *********

void init_hash_table()
{

}

// *****************   generating the key based on data   **********

int hash_student(char *name)
{


}

/************   adding data to the hash table   ***********/

int insert_hash(struct student s)
{

}

/*******************   finding the hash table that name is present or not   **********/

void  search_hash(char *name)
{

}

// ****************    main program     *****************

void main()
{
	int opt;
	printf("select the option :\n1-insert\n2-search and display \n3-delete\n\n");
	scanf("enter the 
}

