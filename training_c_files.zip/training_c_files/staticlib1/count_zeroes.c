int COUNT_ZEROES(int var)
{
        int count=0,count1=0,temp;
        printf("enter the decimal input :");
        scanf("%d",&var);
        for(temp=0,count=0;temp<32;temp++)
        {
                if((((0x1<<temp)&var)>>temp)==0)
                {
                        count++;
                }
                else
                        count1++;
        }
        printf("count of zeroes = %d\n",count);
}

