#include<stdio.h>
int main ()
{
	int n,i,j,temp;
	unsigned int *ptri;
	printf("enter the number of elemnts : ");
	scanf("%d",&n);
	ptri=(int *)calloc(n,sizeof(int));
	if(ptri==NULL)
	{
		printf("failed to allocate memory in heap \n");
	}
	printf("ente the data in adresses : ");
	for(i=0;i<n;i++)
	{
		scanf("%d",(ptri+i));
	}
	for(i=0;i<n;i++)
	{
             for(j=i+1;j<n;j++)
	     {
		     if(

	}
}

