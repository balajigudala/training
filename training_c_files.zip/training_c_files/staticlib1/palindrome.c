int PALINDROME(int var)
{
         //To check palindrome or not
        int temp,sum,var1,rem;
        printf("enter the input : " );
        scanf("%d",&var1);
        sum=0;
        temp=var1;
        while(temp>0)
        {
                rem=temp%10;
                sum=(sum*10)+rem;
                temp=temp/10;
        }
        if(var1==sum){
                printf("palindrome number\n");}
        else{
                printf("not palindrome\n");}
}

