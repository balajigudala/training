
int main()
{
	int res,n;
		res=PALINDROME(n);
		return res;
}
