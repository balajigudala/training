#include<stdio.h>
#include<unistd.h>
#include<signal.h>
void myhandler(int );
int main()
{
	int i=0;
	printf("pid is : %d\n",getpid());
	struct sigaction act;
	act.sa_handler=myhandler;
	act.sa_flags=0;
	printf("before set : %lx \n",act.sa_mask);
        sigemptyset(&act.sa_mask);
	printf("set after empty : %lx \n", act.sa_mask);
	sigaddset(&act.sa_mask,2);
	printf("set after 2nd bit set : %lx \n",act.sa_mask);
	sigaddset(&act.sa_mask,20);
	printf("set after 20th bit set : %lx \n",act.sa_mask);
	sigprocmask(SIG_BLOCK,&act.sa_mask,NULL);
	while(i<=10)
	{
		printf("%d \n",i++);
		sleep(1);
		//i++;
	}
	sigdelset(&act.sa_mask,20);
	sigdelset(&act.sa_mask,2);
	printf("set after 14th bit delete : %x \n",act.sa_mask);
	sigprocmask(SIG_UNBLOCK,&act.sa_mask,NULL);
	sigaction(2,&act ,0);
	sigaction(20,&act ,0);
//	i=10;
	while(i<=40)
	{
		printf("%d \n",i);
		i++;
		sleep(1);
	}
	sigemptyset(&act.sa_mask);
	sigprocmask(0,NULL,&act.sa_mask);
	printf("size of %d",sizeof(act.sa_mask));
	printf("signal mask variable status : %lx \n",act.sa_mask);
}

void myhandler(int signo)
{
	printf("my handler function and signal no : %d \n",signo);
}
