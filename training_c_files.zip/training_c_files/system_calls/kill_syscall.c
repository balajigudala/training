#include<stdio.h>
#include<unistd.h>
#include<signal.h>
int main()
{
	pid_t res,pidno;
	printf("enter the process id number to kill that process : ");
	scanf("%d",&pidno);
	res=kill(pidno,9);
	if(res==0)
		printf("killed - %d \n",pidno);
	else
		printf("there is no process to kill with that PID no : %d\n",res);
}


