main()
{
	system("poweroff");
}
