#include<stdio.h>
#include<unistd.h>
#include<signal.h>
static void pSigHandler(int );
int main()
{
	struct sigaction psa;
//	memset (&psa, 0, sizeof (psa));
	psa.sa_handler = pSigHandler;
	psa.sa_flags=0;
//	psa.sa_mask=0;
	sigaction (SIGINT, &psa, NULL);
	sigaction(SIGQUIT, &psa, NULL);
	sigaction(SIGPROF, &psa, NULL);
	int i=0;
	while(i<100)
	{
		printf("the pid : %d \n",getpid());
		sleep(1);
	}
}


static void pSigHandler(int signo)
{
	printf("Pareint signum: %d", signo);// debug
	switch (signo) {
		case SIGALRM:
			printf("P SIGALRM handler");//debug
			break;
		case SIGVTALRM:
			printf("P SIGVTALRM handler");//debug
			break;
		case SIGPROF:
			printf("P SIGPROF handler");//debug
			break;
		default: /*Should never get this case*/
			break;
	}
	return;
}
