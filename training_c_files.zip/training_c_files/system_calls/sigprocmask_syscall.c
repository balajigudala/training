#include<stdio.h>
#include<unistd.h>
#include<signal.h>
void myhandler();
int main()
{
	int i=0;
//	unsigned long set=0;
	sigset_t set;
	printf("set : %x \n",set);
//rintf("size of set : %ld \n ",sizeof(set));
//	for(i=63;i<=0;i++)
//		(set&(0x1<<i))==0?printf("0"):printf("1");
        sigemptyset(&set);
	printf("set aftrer empty : %lx \n",set);
//       sigfillset(&set);
//	printf("set aftrer filling : %lx \n",set);
	sigaddset(&set,2);
	printf("set after 2nd bit set : %lx \n",set);
	sigaddset(&set,14);
	signal(2,myhandler);
	printf("set after 14th bit set : %lx \n",set);
	sigprocmask(SIG_BLOCK,&set,NULL);
	while(i<=20)
	{
		printf("%d \n",i);
	//	printf("%d \n",i);
		i++;
		if(i==10)
		{
			sigdelset(&set,14);
			sigprocmask(SIG_UNBLOCK,&set,NULL);
		}

		sleep(1);
	}
//	while(i<=40);
	sigdelset(&set,14);
	printf("set after 14th bit delete : %x \n",set);
	sigprocmask(SIG_UNBLOCK,&set,NULL);
	sigemptyset(&set);
	sigprocmask(0,NULL,&set);
}
void myhandler( )
{
	printf("myhandler entered\n ");
}

