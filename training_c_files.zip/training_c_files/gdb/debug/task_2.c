#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
void strspc(char *);
void shftint(int *,int,int);
int main()
{
	int opt;
	char arr1[100];
	int arr[100],m,n,i;
	while(1)
	{
	printf("\n0-exit \n1-removing extra spaces in statement \n2-swaping integer for n times \nenter the option : ");
	__fpurge(stdin);
	scanf("%d",&opt);
		switch(opt)
		{
			case 0: 
				exit(0);
			case 1:
				printf("enter the statement : ");
				__fpurge(stdin);
				scanf("%[^\n]s",arr1);
				strspc(arr1);
				printf("\n\nthe string is :%s\n\n",arr1);
				break;
			case 2: 
				printf("enter the no of elements in an array : ");
				__fpurge(stdin);
				scanf("%d",&n);
				for(i=0;i<n;i++)
				{
					printf("enter the elements : ");
					__fpurge(stdin);
					scanf("%d",&arr[i]);
				}
				printf("enter the no of elememts to swap :");
				__fpurge(stdin);
				scanf("%d",&m);
				shftint(arr,m,n);
				for(i=0;i<n;i++)
				{
					printf(" %d",arr[i]);
				}
				break;
			default:
				printf("invalid option " );

		}
	}
}

void strspc(char *arr1)
{
	int i,j,count=0;
	for(i=0,j=0;arr1[i]!='\0';i++)
	{
		if(arr1[i]==' ')
			count++;
		if(arr1[i]!=' ')
			count=0;
		if(count>1)
			continue;
		arr1[j]=arr1[i];
		j++;
	}
	arr1[j]='\0';
}

void shftint(int *arr1,int m,int n)
{
	int i,j,temp;
	for(i=0;i<m;i++)
	{
		temp=arr1[0];
		for(j=0;j<n;j++)
		{
			arr1[j]=arr1[j+1];
		}
		arr1[n-1]=temp;
	}
}

