extern int x;
void display()
{
	printf("output : %d",x);
}

