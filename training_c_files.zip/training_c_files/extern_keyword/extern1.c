#include<stdio.h>
int x=10;
int main()
{
	display();
}
