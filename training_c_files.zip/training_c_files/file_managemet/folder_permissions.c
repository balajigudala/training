#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
int main()
{
	int fd,fd1;
	char buff[100];
	fd=open("test",O_RDWR);
	printf("F.D value : %d \n",fd);
	fd1=read(fd,buff,99);
	buff[fd1]='\0';
	printf("%s\n",buff);
	close(fd);
}

