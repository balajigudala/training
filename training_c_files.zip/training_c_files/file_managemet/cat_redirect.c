#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
int main(int arg , char *str[])
{
	char buff[1024];
	if(arg!=4)
	{
		printf("CP: missing file operand\nsyntax : ./CP <source file> <destination file> \n");
		exit(1);
	}
	if(strlen(str[2])!=2||str[2][0]!='>'||str[2][1]!='>')
	{
		printf("CP: missing file operand\nsyntax : ./CP <source file> <destination file> \n");
		exit(1);
	}
	if(strcmp(str[1],str[2])==0)
	{
		printf("CP: 'file1' and 'file1' are the same file\n");
		exit(6);
	}
	int fd1,fd2,ret1,ret2;
	fd1=open(str[1],O_RDWR);
	//printf("file 1 FD no : %d \n",fd1);
	if(fd1<0)
	{
		printf("cp: cannot stat 'file': No such file or directory\n");
		exit(2);
	}
	ret1=read(fd1,buff,1023);
	//printf("no of char red from file1 : %d \n",ret1);
	if(ret1<0)
	{
		printf("failed to read 2nd file\n");
		exit(4);
	}
	buff[ret1]='\0';
	fd2=open(str[2],O_CREAT|O_RDWR,0664);
	//printf("file2 FD no : %d \n",fd2);
	if(fd2<0)
	{
		printf("failed to open 2nd file\n");
		exit(3);
	}
	lseek(fd2,0,SEEK_END);
//et1=strlen(str[1]);
	ret2=write(fd2,buff,strlen(buff));
	//printf("no of char write to file12 : %d \n",ret2);
	if(ret2<0)
	{
		printf("failed to write \n");
		exit(4);
	}
	close(fd1);
	close(fd2);
}
