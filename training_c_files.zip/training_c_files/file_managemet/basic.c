#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
int main(int nof,char *args[])
{
	int fd,res ;
	char buff[100],sbuf[5];
//	printf("enter the statement :");
//	scanf("%[^\n]",buff);
/*	fd=creat(args[1],0777);
	printf("fd returnred by create : %d \n",fd);
	fd = open("filedone",O_RDWR);
*/
	if(nof<3)
	{
		printf("pass valid arguments \n");
		return 0;
	}
	fd=open(args[1],O_RDWR);
	printf("fd : %d \n",fd);
//	res=lseek(fd,0,SEEK_END);
//	res=write(fd,buff,strlen(buff));
        int fd2=open(args[2],O_RDWR|O_CREAT|O_TRUNC,0777);
	printf("fd2: %d \n",fd2);
	if(res<0)
	{
		printf("failed to write\n");
		return -1;
	}
	res=lseek(fd,0,SEEK_SET);
	while(res=read(fd,sbuf,5))
	{
		if(res<0)
		{
			printf("failed to read\n");
			return -1;
		}
		write(fd2,sbuf,res);
	}
	res=lseek(fd2,0,SEEK_SET);
	while(res=read(fd2,sbuf,5))
	{
		if(res<0)
		{
			printf("failed to read\n");
			return -1;
		}
		write(1,sbuf,res);
	}
	close(fd);
}
