#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
	int x=10,y,z;
//	close(1);
	y=vfork();
	if(y>0)
	{
		printf("enter the parent :");
		//__fpurge(stdin);
		scanf("%d",&x);
		__fpurge(stdin);
		printf("parent : %d \n",x);
		exit(1);
	}
	else	
	{
		printf("enter the child :");
		//__fpurge(stdin);
		scanf("%d",&z);
		__fpurge(stdin);
		printf("child : %d \n",z);
	}
}

