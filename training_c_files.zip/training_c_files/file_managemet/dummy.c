#include <stdio.h>
#include <dirent.h>
int main()
{ 	
		DIR *folder;
		int res;
	struct dirent *entry;
	int files = 0;
	res = mkdir("giribabu",0664);
	printf("res : %d\n",res);
	folder = opendir("giribabu");
/*	if(folder == NULL)
	{
		perror("Unable to read directory");
		return(1);
	}
//	while( (entry=readdir(folder)) )
	{
		files++;
		printf("%s\t",entry->d_name );
	}
	closedir(folder);
	return(0);
	*/
}
