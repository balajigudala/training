#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include<fcntl.h>
#include<sys/stat.h>
int main(int arg , char* str[])
{
	if(arg!=2)
	{
		printf("correct trhe syntax \n");
		exit(1);
	}
	int fd1;
	struct stat buff;
	fd1=stat(str[1],&buff);
	if(fd1<0)
	{
		printf("there is no file \n");
		exit(1);
	}
	printf("device name  : %lu \n",buff.st_dev);
	printf("inode no     : %lu \n",buff.st_ino);
//	printf("file mode    : %u \n",buff.st_mode);
	printf("size of file : %ld \n",buff.st_size);
//	printf("last modified: %ld \n",_unused5);
	printf((buff.st_mode & S_IRUSR )? "r" : "-");
	printf((buff.st_mode & S_IWUSR )? "w" : "-");
	printf((buff.st_mode & S_IXUSR )? "x" : "-");
	printf((buff.st_mode & S_IRGRP )? "r" : "-");
	printf((buff.st_mode & S_IRGRP )? "w" : "-");
	printf((buff.st_mode & S_IWGRP )? "x" : "-");
	printf((buff.st_mode & S_IXOTH )? "r" : "-");
	printf((buff.st_mode & S_IWOTH )? "w" : "-");
	printf((buff.st_mode & S_IXOTH )? "x" : "-");
}

/*  path /usr/usr/include/asm-generic/stat.h
  struct stat {
	unsigned long	st_dev;	           Device.  
	unsigned long	st_ino;		 File serial number.  
	unsigned int	st_mode;	 File mode.  
	unsigned int	st_nlink;	 Link count.  
	unsigned int	st_uid;		 User ID of the file's owner. 
	unsigned int	st_gid;		 Group ID of the file's group. 
	unsigned long	st_rdev;	 Device number, if device. 
	unsigned long	__pad1;
	long		st_size;	 Size of file, in bytes.  
	int		st_blksize;	 Optimal block size for I/O.  
	int		__pad2;
	long		st_blocks;	 Number 512-byte blocks allocated. 
	long		st_atime;	 Time of last access.  
	unsigned long	st_atime_nsec;
	long		st_mtime;	 Time of last modification.  
	unsigned long	st_mtime_nsec;
	long		st_ctime;	 Time of last status change.  
	unsigned long	st_ctime_nsec;
	unsigned int	__unused4;
	unsigned int	__unused5;
};


              The following symbolic constants are provided for mode:

              S_IRWXU  00700 user (file owner) has read, write, and
                       execute permission

              S_IRUSR  00400 user has read permission

              S_IWUSR  00200 user has write permission

              S_IXUSR  00100 user has execute permission

              S_IRWXG  00070 group has read, write, and execute
                       permission

              S_IRGRP  00040 group has read permission

              S_IWGRP  00020 group has write permission

              S_IXGRP  00010 group has execute permission

              S_IRWXO  00007 others have read, write, and execute
                       permission

              S_IROTH  00004 others have read permission

              S_IWOTH  00002 others have write permission

              S_IXOTH  00001 others have execute permission

According to POSIX, the effect when other bits are set in
              mode is unspecified.  On Linux, the following bits are
              also honored in mode:

              S_ISUID  0004000 set-user-ID bit

              S_ISGID  0002000 set-group-ID bit (see inode(7)).

              S_ISVTX  0001000 sticky bit (see inode(7)).
*/
