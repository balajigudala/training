#include<stdio.h>
#include<fcntl.h>
int main()
{
	int fd,fd1;
	fd=open("file1",O_RDWR);
	printf("F.D value : %d \n",fd);
	fd1=open("file1",O_RDONLY);
	printf("F.D value : %d \n",fd1);
}

