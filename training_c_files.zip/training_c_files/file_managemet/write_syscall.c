#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{
	char buff[100],rbuff[100];
	int fd,fd1,ret;
	printf("enter the string to add : \n");
	scanf("%[^\n]s",rbuff);
	//ret=strlen(rbuff);
	//rbuff[ret+2]='\n';
	fd=open("file1.txt",O_RDWR);
	printf("open : return : %d \n",fd);
	if(fd<0)
	{
		printf("\n\t failed to open file \n");
		exit(1);
	}
	ret=write(fd,rbuff,strlen(rbuff));
	printf("read : return : %d \n",ret);
	if(ret<0)
	{
		printf("\n\t failed to read file \n");
		exit(2);
	}
	//buff[ret]='\0';
	//printf("buff : %s",buff);
	close(fd);
}

