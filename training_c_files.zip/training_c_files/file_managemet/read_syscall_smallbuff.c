#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{
	char buff[5];
	int fd,fd1,ret;
	fd=open("file1.txt",O_RDONLY);
	printf("open : return : %d \n",fd);
	if(fd<0)
	{
		printf("\n\t failed to open file \n");
		exit(1);
	}
	while(ret=read(fd,buff,5))
	{
		printf("\nread : return : %d \n",ret);
		if(ret<0)
		{
			printf("\n\t failed to read file \n");
			exit(2);
		}
		buff[ret]='\0';
		printf("%s",buff);
	}
}

