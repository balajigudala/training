#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
int main(int arg,char *str[])
{
	char buff[8192];
	int fd,fd1,ret,i=1;
	int fd2,ret1,ret2;
	if(arg<=3)
	{
		if(arg<2)
		{
			printf("\ncorrect the syntax : ./CAT < filename >\n");
			exit(1);
		}
		char buff[8191];
		int fd,fd1,ret,i=1;
		while(i<arg)
		{
			fd=open(str[i],O_RDONLY);
			if(fd<0)
			{
				printf("CAT: %s: No such file or directory \n",str[i]);
				i++;
				continue;
			}
			while(ret=read(fd,buff,8191))
			{
				if(ret<0)
				{
					printf("\n\t failed to read file \n");
					//	exit(2);
				}
				buff[ret]='\0';
				printf("%s",buff);
			}
			close(fd);
			i++;
		}
	}
	else if(arg==4)
	{
		if(arg!=4)
		{
			printf("CP: missing file operand\nsyntax : ./CP <source file> <destination file> \n");
			exit(1);
		}
		if(strlen(str[2])!=2||str[2][0]!='>'||str[2][1]!='>')
		{
			printf("CP: missing file operand\nsyntax : ./CP <source file> <destination file> \n");
			exit(1);
		}
		if(strcmp(str[1],str[2])==0)
		{
			printf("CP: '%s' and '%s' are the same file\n",str[1],str[2]);
			exit(6);
		}
		int fd1,fd2,ret1,ret2;
		fd1=open(str[1],O_RDWR);
		//printf("file 1 FD no : %d \n",fd1);
		if(fd1<0)
		{
			printf("cp: cannot stat '%s': No such file or directory\n",str[1]);
			exit(1);
		}
		ret1=read(fd1,buff,8191);
		fd2=creat(str[2],0664);
		//printf("file2 FD no : %d \n",fd2);
		if(fd2<0)
		{
			printf("failed to open 2nd file\n");
			exit(3);
		}
		while(ret1=read(fd1,buff,8191))
		{
			//printf("no of char red from file1 : %d \n",ret1);
			if(ret1<0)
			{
				printf("failed to read 2nd file\n");
				exit(4);
			}
			buff[ret1]='\0';
			//et1=strlen(str[1]);
			ret2=write(fd2,buff,strlen(buff));
			//printf("no of char write to file12 : %d \n",ret2);
			if(ret2<0)
			{
				printf("failed to write \n");
				exit(4);
			}
		}
		close(fd1);
		close(fd2);
	}
	else
	{
		printf("\ncorrect the syntax : ./CP < filename >\n");
		exit(1);
	}
}
