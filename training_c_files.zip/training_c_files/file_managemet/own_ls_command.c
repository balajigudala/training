#include <stdio.h>
#include <dirent.h>
int main()
{
    DIR *folder;
    struct dirent *entry;
    int files = 0;
    //folder = opendir("/home/engineer/practice_files/file_managemet/test.c");
    folder = opendir(".");
    if(folder == NULL)
    {
        printf("Unable to read directory");
        return(1);
    }
    while((entry=readdir(folder)))
    {
       files++;
        printf("%-10s",entry->d_name );
    }
    closedir(folder);
    return(0);
}
