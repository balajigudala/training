#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
/* program to rename a file using rename() library function */
int main(int arg , char* str[])
{
	if(arg!=3)
	{
		printf("correct the syntax <executable file name> <new file name > < old file name >\n");
                exit(1);
	}
	if(strcmp(str[2],str[1])==0)
	{
		printf("The destination and source file names are same \n");
		exit(2);
	}
	if(rename(str[1], str[2]))
		printf("failed");
	else
		printf("file renamed\n");
}
