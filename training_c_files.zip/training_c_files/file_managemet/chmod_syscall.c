// program for chmod system call
#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
#include<sys/stat.h>
int str_ascii(char *str);
int main(int arg , char* str[])
{
	if(arg!=3)
	{
		printf("correct the syntax <executable file name> < permissions > < file name \n");
                exit(1);
	}
	if( strlen(str[1]) != 3 )
	{
		printf("Invalid file permissions\n");
		printf("use -h to know\n");
	}
	int num = str_ascii(str[1]);
	printf("num : %o\n", num);
	int ret = chmod(str[2], num);
	if(ret < 0)
	{
		printf("failed to change permissions\n");
		exit(1);
	}
}
int str_ascii(char *str)
{	
	if(str == NULL)
	{
		printf("NULL is recieved\n");
		exit(1);
	}
	int num = 0, digit = 0;
	int i = strlen(str), j = 0;
	while(j < i)
	{
		digit = str[j] - 48 ;
		num = num * 8 + digit;
		j++;
	}
	printf("num: %d",num);
	return num;

}









