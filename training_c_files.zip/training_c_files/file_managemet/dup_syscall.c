#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
int main()
{
	int fd1,fd2,res;
	fd1=open("file1",O_RDWR);
	printf("fd1 : %d\n",fd1);
	res=dup2(fd1,10);
//	close(1);
	printf("res : %d\n",res);
	fd1=write(res,"hello\n",6);
}


