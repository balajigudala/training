        __TMC_END__ = 1;
        return deregister_tm_clones();
        if (False)
        {
            __cxa_finalize();
            __TMC_END__ = 1;
            return deregister_tm_clones();
        }
    }
    else
    {
        return v2;
    }
}

int frame_dummy()
{
}

typedef struct struct_0 {
    unsigned long long field_0;
    struct struct_1 *field_8;
    unsigned long long field_10;
} struct_0;

int main(unsigned long a0, struct_0 *a1)
{
    unsigned int v0;  // [bp-0x18]
    unsigned int v1;  // [bp-0x14]
    unsigned int v2;  // [bp-0x10]
    unsigned int v3;  // [bp-0xc]
    unsigned long long v10;  // rax

    if (!((unsigned int)a0 == 3))
    {
        printf("follow the syntax \" ./kill <-signo.> <pidno> \" ");
        v10 = -18446744069414584321;
        return v10;
    }
    else if (!(strcmp("./kill", a1->field_0) == 0))
    {
        printf("follow the syntax \" ./kill <-signo.> <pidno> \" ");
        v10 = -18446744069414584321;
        return v10;
    }
    else if (*(a1->field_8) != 45)
    {
        printf("follow the syntax \" ./kill <-signo.> <pidno> \" ");
        v10 = -18446744069414584321;
        return v10;
    }
    v0 = 1;
    v1 = 0;
    v3 = 1;
    while (true)
    {
        if (a1->field_8[(long long)(int)v0] == 0)
        {
            v0 = 0;
            v2 = 0;
            v3 = 1;
            while (true)
            {
                if (*((char *)((int)v0 + a1->field_10)) == 0)
                {
                    v3 = kill(v2, v1);
                    v10 = v3;
                    return v10;
                }
                else if (*((char *)((int)v0 + a1->field_10)) <= 47)
                {
                    puts("the input three must be positive integer ");
                    v10 = -18446744069414584321;
                    return v10;
                }
                else if (*((char *)((int)v0 + a1->field_10)) > 57)
                {
                    puts("the input three must be positive integer ");
                    v10 = -18446744069414584321;
                    return v10;
                }
            }
            v2 = (unsigned int)(char)*((char *)((int)v0 + a1->field_10)) - 48 + ((unsigned int)((unsigned long long)v2 * 4) + v2) * 2;
            v0 += 1;
            v3 = ((unsigned int)((unsigned long long)v3 * 4) + v3) * 2;
        }
        else if (a1->field_8[(long long)(int)v0] <= 47)
        {
            puts("the input two must be positive integer 1 - 64 ");
            v10 = -18446744069414584321;
            return v10;
        }
        else if (a1->field_8[(long long)(int)v0] > 57)
        {
            puts("the input two must be positive integer 1 - 64 ");
            v10 = -18446744069414584321;
            return v10;
        }
        else
        {
            v1 = (unsigned int)a1->field_8[(long long)(int)v0] - 48 + ((unsigned int)((unsigned long long)v1 * 4) + v1) * 2;
            if (v1 > 64)
            {
                puts(" the signal number should be in range 1-64 ");
                v10 = -18446744069414584321;
                return v10;
            }
            v0 += 1;
            v3 = ((unsigned int)((unsigned long long)v3 * 4) + v3) * 2;
        }
    }
}

int __libc_csu_init(unsigned long long a0, unsigned long long a1, unsigned long long a2)
{
    unsigned long long v4;  // rdx
    unsigned long long v5;  // rsi
    unsigned long long v6;  // rdi
    unsigned long long v7;  // rbx
    unsigned long long v8;  // rax

    v8 = _init();
    if (False)
    {
        return v8;
    }
    v7 = 0;
    while (true)
    {
        v4 = a2;
        v5 = a1;
        v6 = a0;
        v8 = *((long long *)(6294944 + rbx<8> * 8))();
        v7 += 1;
        if (v7 == 1)
        {
            break;
        }
    }
    return v8;
}

int __libc_csu_fini()
{
    unsigned long v1;  // rax

    return v1;
}

int _fini()
{
    unsigned long v1;  // rax

    return v1;
}


