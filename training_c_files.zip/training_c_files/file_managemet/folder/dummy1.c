int32_t main(int32_t argc, char** argv, char** envp)
{
    int32_t rax_3;
    int32_t rax_9;
    if (argc == 3)
    {
        rax_3 = strcmp("./kill", *(int64_t*)argv);
        if ((rax_3 == 0 && *(int8_t*)argv[1] == 0x2d))
        {
            int32_t var_18_1 = 1;
            int32_t var_14_1 = 0;
            int32_t var_c_1 = 1;
            while (true)
            {
                if (argv[1][((int64_t)var_18_1)] == 0)
                {
                    int32_t var_18_2 = 0;
                    int32_t var_10_1 = 0;
                    int32_t var_c_2 = 1;
                    while (true)
                    {
                        if (argv[2][((int64_t)var_18_2)] == 0)
                        {
                            uint64_t rdx_12 = ((uint64_t)var_14_1);
                            rax_9 = kill(((uint64_t)var_10_1), ((uint64_t)rdx_12), rdx_12);
                            break;
                        }
                        if ((argv[2][((int64_t)var_18_2)] > 0x2f && argv[2][((int64_t)var_18_2)] <= 0x39))
                        {
                            int32_t rax_59 = (var_10_1 * 5);
                            var_10_1 = ((((int32_t)argv[2][((int64_t)var_18_2)]) - 0x30) + (rax_59 + rax_59));
                            var_18_2 = (var_18_2 + 1);
                            int32_t rax_72 = (var_c_2 * 5);
                            var_c_2 = (rax_72 + rax_72);
                            continue;
                        }
                        puts("the input three must be positive…");
                        rax_9 = -1;
                        break;
                    }
                    break;
                }
                if ((argv[1][((int64_t)var_18_1)] > 0x2f && argv[1][((int64_t)var_18_1)] <= 0x39))
                {
                    int32_t rax_24 = (var_14_1 * 5);
                    var_14_1 = ((((int32_t)argv[1][((int64_t)var_18_1)]) - 0x30) + (rax_24 + rax_24));
                    if (var_14_1 > 0x40)
                    {
                        puts(" the signal number should be in …");
                        rax_9 = -1;
                        break;
                    }
                    var_18_1 = (var_18_1 + 1);
                    int32_t rax_37 = (var_c_1 * 5);
                    var_c_1 = (rax_37 + rax_37);
                    continue;
                }
                puts("the input two must be positive i…");
                rax_9 = -1;
                break;
            }
        }
    }
    if (((argc != 3 || (argc == 3 && rax_3 != 0)) || ((argc == 3 && rax_3 == 0) && *(int8_t*)argv[1] != 0x2d)))
    {
        printf("follow the syntax " ./kill <-sig…);
        rax_9 = -1;
    }
    return rax_9;
}
