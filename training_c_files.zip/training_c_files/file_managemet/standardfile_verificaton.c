#include<stdio_ext.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
int main()
{
	char buff[1024];
	int fd,ret=1;
	fd=open("file1",O_RDWR);
	if(fd<0)
	{
		printf("failed to open the file \n");
		exit(1);
	}
	//ret=read(fd,buff,20);
	if(ret<0)
	{
		printf("failed to read the file \n");
		exit(1);
	}
//	ret=read(0,buff,20);
	ret=write(1,buff,20);
	buff[ret]='\0';
	__fpurge(stdin);
//	ret=write(1,buff,20);
	close(fd);
}
