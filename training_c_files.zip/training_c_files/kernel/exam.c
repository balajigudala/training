#include<stdio.h>
#define n  5
void  max_min_arr(arr)
{
	int i,j;
	int b=0,k=0,l=0,m=0;
	for(i=0;i<n;i++)
	{
		if(arr[i]>b)
			b=arr[i];
		else{
			if(arr[i]>l)
			{
				l=arr[i];
				if(l>m)
					m=l;
				else
					m=arr[i];
			}
			else
			{
				m=arr[i];
			}
		}
	}
	printf("max %d\n",b);
	printf("mini %d\n",m);
}
void main()
{
	int arr[5];
	int i;
	printf("enter array element\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",arr[i]);
	}
	max_min_arr(arr);
}
