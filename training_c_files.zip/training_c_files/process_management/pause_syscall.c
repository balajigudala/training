#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void main()
{
       	char *ptr[]={"ps","-ef",NULL};
	int var1,var2;
	var1=fork();
	if(var1 < 0)
	exit(-1);
	if(var1>0)
	{
	        printf("parent : entered\n");
		printf("parent : pid : %d \n",getpid());
		pause();
	        printf("pause : ret : %d \n ",var2);
		printf("parent : pid : %d \n",getpid());
		printf("parent : ppid : %d \n",getppid());
		printf("parent : child : pid : %d \n",var1);
	//	while(1)
	//		printf("*");
	}
	else
	{
		printf("child : pid : %d \n",getpid());
		printf("child : parent : pid : %d \n",getppid());
	//	alarm(10);
		kill(getpid(),17);
		//raise(9);
	/*	while(1)
		{
		       printf("2");
		       printf("3");
		}*/
	}
}
