#include<stdio.h>
#include<unistd.h>
int main()
{
	int pid;
	pid=vfork();
	if(pid>0)
	{
	//	sleep(5);
		printf("p1- %d \n",pid);
		printf("p2- %d \n",pid);
		exit(0);
	}
	else
	{
		printf("c1- %d \n",pid);
		printf("c2- %d \n",pid);
	}
}


