#include<stdio.h>
#include<unistd.h>
int main()
{
       	char *ptr[]={"ps","-ef",NULL};
	int var1,var2;
	var1=fork();
	if(var1>0)
	{
		var2=alarm(4);
	        printf("alarm1 1 : ret : %d \n ",var2);
		var2=alarm(8);
	        printf("alarm1 2 : ret : %d \n ",var2);
		sleep(10);
		printf("parent : pid : %d \n",getpid());
		printf("parent : ppid : %d \n",getppid());
		printf("parent : child : pid : %d \n",var1);
		while(1)
			printf("*");
	}
	else
	{
		alarm(4);
	        sleep(20);
		printf("child : pid : %d \n",getpid());
		printf("child : parent : pid : %d \n",getppid());
		while(1)
			printf("2");
	}
}
