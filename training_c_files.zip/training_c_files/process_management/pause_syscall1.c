#include<stdio.h>
#include<signal.h>
#include<unistd.h>
int main()
{
	signal(14,SIG_IGN);
	alarm(2);
	while(1)
	{
		alarm(2);
		pause();
	}
}
