#include<stdio.h>
int main()
{
	char str[10];
	scanf("%s",str);
	printf("%s",str);
}
