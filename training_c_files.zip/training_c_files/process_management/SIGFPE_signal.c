#include<stdio.h>
int main()
{
	printf("%d",1/0);
}
