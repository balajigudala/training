#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
	pid_t x,y;
	printf("enter the number : ");
	x=getpid();
	y=getppid();
	printf("PID : %d\n",x);
	printf("PPID : %d\n",y);
	//while(1)
	//	printf("*   ");
	scanf("%d",&x);
	printf("%d",x);
}
