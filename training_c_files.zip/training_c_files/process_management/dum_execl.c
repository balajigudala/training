#include<stdio.h>
#include<unistd.h>
int main()
{
	int a=20,b=40,c;
	c=a-b;
	printf("the c : %d \n",c);
//	execl("/usr/bin/gcc","gcc","-o","dharmi","execlp_syscall.c",NULL);
//	execl("/usr/bin/gcc","gcc","-g","-o","dharmi","execlp_syscall.c",NULL);
	execl("/bin/cat","cat","dum_execl.c",NULL);
}
