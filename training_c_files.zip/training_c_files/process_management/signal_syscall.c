#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<signal.h>
void myhandler(int);
int main()
{
	int var1=0,i=0,var2;
	signal(2,myhandler);
	signal(3,myhandler);
	while(i<=1000)
	{
		sleep(1);
		printf("%d \n",i);
		i++;
	}
}

void myhandler(int signo)
{
	printf("myhandler function entered \n");
	//sleep(10);
	printf("myhandler : %d  \n",signo);
}
