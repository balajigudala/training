#include<stdio.h>
#include<unistd.h>
int main()
{
	int a=20,b=40,c;
	c=a+b;
	printf("the c : %d \n",c);
	execlp("ps","ps","-ef",NULL);
}
