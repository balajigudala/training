#include<stdio.h>
#include<unistd.h>
int main()
{
	int x;
	fork();
	fork();
	fork();
	fork();
	printf("hello\n");
	scanf("%d",x);
}


