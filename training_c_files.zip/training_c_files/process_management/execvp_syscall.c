#include<stdio.h>
#include<unistd.h>
int main()
{
       	char *ptr[]={"ps","-ef",NULL};
	int var1;
	var1=fork();
	if(var1>0)
	{
	//	alarm(2);
	        sleep(5);
		printf("parent : pid : %d \n",getpid());
		printf("parent : ppid : %d \n",getppid());
		printf("parent : child : pid : %d \n",var1);
	//	whie(1)
	//		printf("*");
	}
	else
	{
	//	alarm(4);
	        sleep(10);
		printf("child : pid : %d \n",getpid());
		printf("child : parent : pid : %d \n",getppid());
	//	while(1)
	//		printf("2");
	        execvp(ptr[0],&ptr[0]);
	}
}
