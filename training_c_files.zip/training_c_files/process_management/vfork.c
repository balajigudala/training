#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
int x=10;
int main()
{
	pid_t var1;
	var1=vfork();
	if(var1<0)
	{
		printf("the vfork is failed to create the child process\n");
		exit(2);
	}
	if(var1>0)
	{
		printf("parent i d : %d \n",getpid());
		printf("parent : child : %d \n",var1);
		printf("parent : x : %d \n",x);
		exit(0);
	}
	else
	{
		x=x+20;
		printf("child proces i d : %d \n",getpid());
		printf("child : child parent : %d \n",getppid());
		printf("child : child : %d \n",var1);
		printf("child : x : %d \n",x);
		sleep(5);
	}
}
