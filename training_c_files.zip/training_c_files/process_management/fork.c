#include<stdio.h>
#include<unistd.h>
//#include<sys/types.h>
int x=10;
int main()
{
	pid_t var1;
	var1=fork();
	if(var1>0)
	{
		while(1)
		{
		//	sleep(3);
		//	x=x+20;
			printf("parent : x : %d \n",x);
			printf("parent i d : %d \n",getpid());
			printf("parent : child : %d \n",var1);
			printf("* ");
		//	execlp("gnome-calculator","gnome-calculator",NULL);
			sleep(1);
			printf("* ");
		}
	}
	else
	{
		while(1)
		{
		//	sleep(5);
		//	x=x+200;
			printf("child : x : %d \n",x);
			printf("child proces i d : %d \n",getpid());
			printf("child : child parent : %d \n",getppid());
			printf("child : child : %d \n",var1);
			printf(" ---- ");
			sleep(1);
		}
	}
}

