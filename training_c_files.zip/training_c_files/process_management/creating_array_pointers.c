#include<stdio_ext.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/wait.h>
int main()
{
	int i,j,k,len;
	char *ptr[10];
	char arr[100];
	while(1)
	{
		i=0,j=0;
		sleep(1);
		printf("enter the string : ");
		__fpurge(stdin);
		scanf("%[^\n]",arr);
		printf("the strings given : %s \n",arr);
		len=strlen(arr);
		printf("the strings len : %d \n",len);
		for(k=i=0,len++;i<len;i++)
		{
			if((arr[i]==' ')||arr[i]=='\0')
			{
				ptr[j]=&arr[k];
				k=i+1;
				j++;
				arr[i]='\0';
			}
		}
		for(i=0;i<j;i++)
			printf("the strings : %s \n",ptr[i]);
		i=fork();
		if(i<0)
		{
			printf("failed to creat process \n" );
			exit(0);
		}
		if(i>0)
		{
			printf("the parent : pid : %d \n",getpid());
			printf("the parent :c child pid : %d \n",i);
		}
		else
		{
			printf("the child : pid : %d \n",getpid());
			printf("the child :c parent pid : %d \n",getppid());
			printf("\n output : \n\n");
			execvp(ptr[0],ptr);
		}
		printf("cycle\n");
	}
}
