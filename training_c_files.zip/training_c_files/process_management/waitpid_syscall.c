#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main()
{
	pid_t pid,cpid;
	int i=0,stat=0;
	pid=fork();
	if(pid<0)
	{
		printf("failed to create the child process \n");
		exit(2);
	}
	else if(pid>0)
	{
		//sleep(15);
		cpid=waitpid(getpid(),&stat,WNOHANG);
//		cpid=waitpid(pid,&stat,WUNTRACED);
		printf("parent : child pid : %d \n ",cpid);
/*		if(WIFEXITED(stat))
		{
			printf("stat in normal  : %d \n",stat);
			printf("normal termination : %d\n",WEXITSTATUS(stat));
		}
		if(WIFSIGNALED(stat))
		{
			printf("stat in abnormal  : 0x%x \n",stat);
			printf("abnormal termination : %d\n",WTERMSIG(stat));
		}
		if(WIFSTOPPED(stat))
		{
			printf("stat in child process  : 0x%x \n",stat);
			printf("if processed killed : %d\n",WSTOPSIG(stat));
		}
		exit(20);*/
		printf("parent : pid : %d " ,getpid());

	}
	else
	{
		printf("child : child pid : %d \n",getpid());
		//scanf("%d",&i);
	//	sleep(10);
		while(i<=10)
		{
			printf("The i:%d - \n",i);
		//	abort();
		//	kill(getpid(),6);
		//	sleep(10);
		//	printf("%d - ",i/0);
			i++;
		}
	}
}
