#include<stdio.h>
#include<unistd.h>
#include<signal.h>
int main()
{
	pid_t res,pidno;
	printf("enter the process id number to kill that process : ");
	scanf("%d",&pidno);
	res=kill(getpid(),9);
	if(res==0)
		printf("returned value by kill() on sucessfull execution : %d\n",res);
	else
		printf("returned value by kill() on failure : %d\n",res); 
}


