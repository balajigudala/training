#include<stdio.h>
int main()
{
	int *ptr=NULL;
//	while(1)
		printf("p");
		while(1)
			printf("(nil)");
		printf("    8");
}

