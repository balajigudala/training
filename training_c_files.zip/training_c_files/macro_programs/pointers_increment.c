#include<stdio.h>
int main()
{
	unsigned int x = 0xaAbBcCdD;
	unsigned char *ptr;
	unsigned short int *ptr2;
	int arr[5];
	int *arr2;
	arr2=(int*)malloc(5*sizeof(int));
	printf("size of arr = %ld \n",sizeof(arr));
	printf("size of arr2 = %ld \n",sizeof(arr2));
	printf("&X = %p  *ptr = %x \n" , ptr,*ptr);
	printf("ptr2 = %p  *ptr2 = %x \n" , ptr2,*ptr2);
}
