#include<stdio.h>
int main()
{
	int i;
	 char x = 170;
//	x = x>>1;
	for(i=7;0<=i;i--)
		(((0x1<<i))&x)?printf("1"):printf("0");
	printf("\n%d\n",x);
}

