#include<stdio.h>
#define pi 3.141516

float MACRO_AREA(int rad)
{
	float f;
	printf("enter the radius : ");
	scanf("%d",&rad);
	f=pi*(rad*rad);
	printf("area is = %f \n ",f);
}

void main()
{
	int ra;
	MACRO_AREA(ra);
}



