#include<stdio.h>
int main()
{
	char a=0xaa;
	int b;
	b=(int)a;
	b=b>>4;
	printf("%x\n",b);
}

