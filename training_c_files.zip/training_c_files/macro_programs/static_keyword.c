#include <stdio.h>
void func(void);
int count = 5; 
int main()
{
	while(count--)
	{
		func();
	}
	return 0;
}
void func( void ) {
	static int i; 
	i++;
	printf("i is %d \n",i);
}
