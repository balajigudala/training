#include <stdio.h>
void main()
{
    // Example of predefined macros
    printf("This is line no.: %d\n", __LINE__);     
    printf("Name of this file: %s\n", __FILE__); 
    printf("Current Date: %s\n", __DATE__);       
    printf("Current Time: %s\n", __TIME__);       
    printf("Compilation success: %d\n", __STDC__);
}

