//swap to do read data by passing adress
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdio_ext.h>
struct book
{
	char name[20];
	int nop;
	float cost;
};
void read(struct book*);
void display(struct book*);
void swap(struct book*,struct book*);
int main()
{
	struct book b1;
	struct book b2;
	struct book temp;
	printf("eneter the book1 info : \n");
	read(&b1);
	display(&b1);
	printf("eneter the book2 info : \n");
	read(&b2);
	display(&b2);
	swap(&b1,&b2);
        /*temp=b1;
	b1=b2;      swaping the data
	b2=temp;*/
	printf("\nthe book 1 data :");
	display(&b1);
	printf("\nthe book 2 data :");
	display(&b2);
	
}
void read(struct book *b3)
{
	printf("enter the name of the book : ");
	__fpurge(stdin);
	scanf("%[^\n]s",b3->name);
	printf("enter the no of pages  : ");
	__fpurge(stdin);
	scanf("%d",&b3->nop);
	printf("enter the cost of book  : ");
	__fpurge(stdin);
	scanf("%f",&b3->cost);
}
void display(struct book *b3)
{

	printf("The name of the book is : ");
	printf("%s \n",b3->name);
	printf("The no of pages is : ");
	printf("%d \n",b3->nop);
	printf("The cost of book is : ");
	printf("%f \n",b3->cost);
}

void swap(struct book*b1,struct book *b2)
{
	struct book temp;
	strcpy(temp.name,b1->name);
	strcpy(b1->name,b2->name);
	strcpy(b2->name,temp.name);
        temp.nop=b1->nop;
        b1->nop=b2->nop;
        b2->nop=temp.nop;
        temp.cost=b1->cost;
        b1->cost=b2->cost;
        b2->cost=temp.cost;
}
	
