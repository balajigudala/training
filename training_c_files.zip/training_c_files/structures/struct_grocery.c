#include<stdio_ext.h>
#include<stdlib.h>
#include<string.h>
struct grocery
{
	char brand[20];
	char quality;
	float quantity;
	int cost;
};
struct grocery *read();
void display(struct grocery *);
void cost(struct grocery *,struct grocery *,struct grocery *,struct grocery *);
int main()
{
	int opt;
	char sel;
	struct grocery *rice=NULL;
	struct grocery *sugar=NULL;
	struct grocery *chillipowder=NULL;
	struct grocery *oil=NULL;
	while (1)
	{
		printf("\n\tmenu \na-exit \nb-read \nc-display \nd-bill\nselect the option to perform operation : ");
		__fpurge(stdin);
		scanf("%c",&sel);
		switch(sel)
		{
			case 'a':
				exit(0);
			case 'b':
				//while (1)
				{
					printf("\n\tmenu \n0-exit \n1-rice \n2-sugar \n3-chillipowder \n4-oil \nselect the option : ");
					__fpurge(stdin);
					scanf("%d",&opt);
					switch(opt)
					{
					//	case 0:
					//		return;
						case 1:
							printf("select rice qualities : ");
							rice=read();
							break;
						case 2:
							printf("select the sugar qualities : ");
							sugar=read();
							break;
						case 3:
							printf("select the chilli powder qualities : ");
							chillipowder=read();
							break;
						case 4:
							printf("select the oil qualities : ");
							oil=read();
							break;
						default:
							printf("select the valid input : ");
					}
				}
			case 'c':
				if(rice!=NULL)
				{
				printf("\nthe rice details : ");
				display(rice);
				}
				if(sugar!=NULL)
				{
				printf("\nthe sugar dstails : ");
				display(sugar);
				}
				if(chillipowder!=NULL)
				{
				printf("\nthe chilli powder details : ");
				display(chillipowder);
				}
				if(oil!=NULL)
				{
				printf("\nthe oil details :");
				display(oil);
				}
				break;
			case 'd':
				cost(rice,sugar,chillipowder,oil);
				break;
		}
	}
}

struct grocery* read()
{
        struct grocery *ptr;
	ptr=(struct grocery*)calloc(1,sizeof(struct grocery));
	printf("\nenter the brand : ");
	__fpurge(stdin);
	scanf("%[^\n]s",ptr->brand);
	printf("\nenter the quality : ");
	__fpurge(stdin);
	scanf("%c",&ptr->quality);
	printf("\nenter the quantity : ");
	__fpurge(stdin);
	scanf("%f",&ptr->quantity);
	printf("\nenter the cost : ");
	__fpurge(stdin);
	scanf("%d",&ptr->cost);
	return ptr;
}

void display(struct grocery *ptr)
{
	printf("\nThe brand : ");
	printf("%s",ptr->brand);
	printf("\nThe quality : ");
	printf("%cgrade",ptr->quality);
	printf("\nThe quantity : ");
	printf("%fkg",ptr->quantity);
	printf("\nenter the cost :");
	printf("%dRs\n",ptr->cost);
}

void cost(struct grocery *rice,struct grocery *sugar,struct grocery *chillipowder,struct grocery *oil)
{
	int sum=0;
	if(rice!=NULL)
	{
		printf("the %f kg of %d cost is %d \n",rice->quantity,rice->cost,rice->quantity*rice->cost);
		sum=rice->quantity*rice->cost;
	}
	if(sugar!=NULL)
	{
		printf("the %f kg of %d cost is %d\n",sugar->quantity,sugar->cost,sugar->quantity*sugar->cost);
		sum=sum+sugar->quantity*sugar->cost;
	}
	if(chillipowder!=NULL)
	{
		printf("the %f kg of %d cost is %d \n",chillipowder->quantity,chillipowder->cost,chillipowder->quantity*chillipowder->cost);
		sum=sum+chillipowder->quantity*chillipowder->cost;
	}
	if(oil!=NULL)
	{
		printf("the %f kg of %d cost is %d  \n",oil->quantity,oil->cost,oil->quantity*oil->cost);
		sum=sum+oil->quantity*oil->cost;
	}
	printf("\nthe total cost : %d\n",sum);
}

