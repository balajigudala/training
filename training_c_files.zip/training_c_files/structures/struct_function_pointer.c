#include<stdio_ext.h>
#include<string.h>
#include<stdlib.h>
//#define NULL 0
struct book
{
	char name[32];
	int nop;
	float cost;
};
struct book_ops
{
	struct book*(*fmem_alloc)();
	void(*fread)(struct book*,int );
	void(*fdisplay)(struct book *,int );
	void(*fswap)(struct book *,int);
	struct book *(*fdeallocate)(struct book *,int );
};
struct book * mem_alloc();
void read(struct book*,int);
void display(struct book*,int);
void swap(struct book*,int);
struct book* deallocate(struct book *,int );
int n=0;
int main()
{
	struct book_ops fun;
	fun.fread=read;
	fun.fdisplay=display;
	fun.fswap=swap;
	fun.fdeallocate=deallocate;
	fun.fmem_alloc=mem_alloc;
	int opt;
	struct book *b=NULL;
	while(1)
	{
		printf("\n\t**** menu ***** \n0-exit \n1-allocate_memory \n2-read \n3-display \n4-swap \n5-deallocate \nselect the option: ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case 0:
				printf("\n\tsuccefully stoped \n");
				exit(0);
			case 1:
				b=fun.fmem_alloc();
				break;
			case 2:
				printf("n value in switch:%d\n",n);
				fun.fread(b,n);
				break;
			case 3:
				fun.fdisplay(b,n);
				break;
			case 4:
				fun.fswap(b,n);
				break;
			case 5:
				b=fun.fdeallocate(b,n);
				break;
			default:
				printf("\n\tinvalid option \n");
		}
	}

}

struct book* mem_alloc()
{
	n++;
	printf("n:%d\n",n);
	struct book *ptr;
//	printf("enter the no of books : ");
//	scanf("%d",&n);
	ptr=(struct book*)malloc(n*sizeof(struct book));
	return ptr;
}
void read(struct book *ptr,int n)
{
	printf("n:%d\n",n);
	if(((n==0)&&(ptr==NULL)))
	{
		printf("\n\n\tmemory is empty, first allocate the memory\n\n");
		return;
	}
	else
	{
		int i;
		for(i=0;i<n;i++)
		{
			__fpurge(stdin);
			printf("\nenter the name : ");
			scanf("%s",ptr[i].name);
			__fpurge(stdin);
			printf("enter the no of pages : ");
			scanf("%d",&ptr[i].nop);
			__fpurge(stdin);
			printf("enter the cost : ");
			scanf("%f",&ptr[i].cost);
		}
	}
}

void display(struct book *ptr,int n)
{
	if(((n==0)&&(ptr==NULL)))
	{
		printf("\n\n\tthe memory is empty, nothing to display\n\n ");
		return;
	}
	int i;
	for(i=0;i<n;i++)
	{
		printf("\n\nthe book-%d information is :\n",i+1);
		printf("the name : ");
		printf("%s \n",ptr[i].name);
		printf("the no of pages : ");
		printf("%d \n",ptr[i].nop);
		printf("the cost : ");
		printf("%f \n",ptr[i].cost);
	}
}

void swap(struct book *ptr,int n)
{
	if(((n==0)&&(ptr==NULL)))
	{
		printf("\n\n\tthe memory is empty, nothing to swap\n\n ");
		return;
	}
	if(n<2)
	{
		printf("\n\n\tthe two objects must be present to swap \n\n");
		return;
	}
	struct book temp;
	temp=ptr[0];
	ptr[0]=ptr[1];
	ptr[1]=temp;
	printf("\n\n\tswaping done \n\n");
}

struct book* deallocate(struct book *ptr,int j)
{
	if(ptr==NULL)
	{
		printf("\n\n\tnothing to deallocate \n\n");
		n=0;
		return NULL;
	}
	n=0;
	free(ptr);
	printf("\n\n\tsuccesfully memory deallocated \n\n");
	return NULL;
}
