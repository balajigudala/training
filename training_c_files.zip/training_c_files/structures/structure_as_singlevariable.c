#include<stdio.h>
#include<stdio_ext.h>
struct 
{
	char name[20];
	int id;
	char gen;
	char gra;
}balu={"balu",25,'m','j'};
int main()
{
//	balu={"balu",27,'m','j'};
//	balu={.name="sai1",.id=51,.gen='f',.gra='s'};
	strcpy(balu.name,"balaji");
	balu.id=21;
	printf("%s--%d--%c--%c\n",balu.name,balu.id,balu.gen,balu.gra);
	printf("%p--%p--%p--%p\n",&balu.name,&balu.id,&balu.gen,&balu.gra);
}

/*
 * output : 
sai1--51--f--s
0x7fff21733370--0x7fff21733384--0x7fff21733388--0x7fff21733389
balu--25--m--j
0x7fff21733350--0x7fff21733364--0x7fff21733368--0x7fff21733369
balu
4
m
s
balu--4--m--s
0x7fff21733370--0x7fff21733384--0x7fff21733388--0x7fff21733389

*/
