//structure in structure 
//the structure with name 
#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
struct dob
{
	int date;
	int mon;
	int year;
};
struct student
{
	char name[32];
	int roll;
	char sec;
	float fee;
        struct dob dt;
};
void read(struct student **, int );
void display(struct student **,int);
int main()
{
	int n,i;
	printf("enter the nof students : ");
	scanf("%d",&n);
	struct student *ptr[n];
	for(i=0;i<n;i++)
	{
	ptr[i]=(struct student *)calloc(n,sizeof(struct student *));
	}
	read(ptr,n);
	display(ptr,n);
}

void read(struct student *ptr[],int n)
{
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("\nEnter the student-%d information :\n",i+1);
		printf("enter the name : ");
		__fpurge(stdin);
                scanf("%s",ptr[i]->name);
		printf("enter the roll : ");
		__fpurge(stdin);
                scanf("%d",&ptr[i]->roll);
		printf("enter the sec : ");
		__fpurge(stdin);
                scanf("%c",&ptr[i]->sec);
		printf("enter the fee : ");
		__fpurge(stdin);
                scanf("%f",&ptr[i]->fee);
		printf("enter the dob -dd/MM/YY : ");
		__fpurge(stdin);
                scanf("%d%d%d",&ptr[i]->dt.date,&ptr[i]->dt.mon,&ptr[i]->dt.year);
	}
}

void display(struct student *ptr[],int n)
{
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("\nthe student %s's information :\n",ptr[i]->name);
		printf(" the name : ");
                printf("%s \n",ptr[i]->name);
		printf(" the roll : ");
                printf("%d \n",ptr[i]->roll);
		printf(" the sec : ");
                printf("%c\n",ptr[i]->sec);
		printf(" the fee : ");
                printf("%f \n",ptr[i]->fee);
		printf(" the dob -dd/MM/YY : ");
                printf("%d-%d-%d\n",ptr[i]->dt.date,ptr[i]->dt.mon,ptr[i]->dt.year);
	}
}
