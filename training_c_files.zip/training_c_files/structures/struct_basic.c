#include<stdio.h>
#include<stdio_ext.h>
struct student
{
	char name[20];
	int id;
	char gen;
	char gra;
};
int main()
{
	struct student k={"balu",25,'m','j'};
	struct student s={.name="sai1",.id=51,.gen='f',.gra='s'};
	printf("%s--%d--%c--%c\n",s.name,s.id,s.gen,s.gra);
	printf("%p--%p--%p--%p\n",&s.name,&s.id,&s.gen,&s.gra);
	printf("%s--%d--%c--%c\n",k.name,k.id,k.gen,k.gra);
	printf("%p--%p--%p--%p\n",&k.name,&k.id,&k.gen,&k.gra);
	__fpurge(stdin);
	scanf("%s",s.name);
	__fpurge(stdin);
	scanf("%d",&s.id);
	__fpurge(stdin);
	scanf("%c",&s.gen);
	__fpurge(stdin);
	scanf("%c",&s.gra);
	printf("%s--%d--%c--%c\n",s.name,s.id,s.gen,s.gra);
	printf("%p--%p--%p--%p\n",&s.name,&s.id,&s.gen,&s.gra);
}

/*
 * output : 
sai1--51--f--s
0x7fff21733370--0x7fff21733384--0x7fff21733388--0x7fff21733389
balu--25--m--j
0x7fff21733350--0x7fff21733364--0x7fff21733368--0x7fff21733369
balu
4
m
s
balu--4--m--s
0x7fff21733370--0x7fff21733384--0x7fff21733388--0x7fff21733389


*/
