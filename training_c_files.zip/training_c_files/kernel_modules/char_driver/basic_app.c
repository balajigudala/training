#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
int main()
{
	int res,fd;
	char buff[50];
	strcpy(buff,"hi hello");
//	fd = open("file1",O_CREAT|O_RDWR);
	fd = open("file1",O_RDWR);
	printf("fd : %d \n",fd );
	res=write(fd,buff,50);
	printf("buff : %s\n",buff);
}

