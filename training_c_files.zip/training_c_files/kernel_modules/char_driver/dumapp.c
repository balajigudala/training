#include<stdio_ext.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

void main()
{
        int fd , ret ;
        char buff[1024],str[100];
        fd = open("/dev/mydevfile",O_RDONLY);
        if(fd < 0)
        {
                printf("failed to open\n");
                exit(1);
	}
    close(fd);	
}

