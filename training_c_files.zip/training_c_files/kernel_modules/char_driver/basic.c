#include<linux/module.h>
#include<linux/device.h>
#include<linux/cdev.h>
#include<linux/kernel.h>
#include<linux/ioport.h>
#include<linux/fs.h>



struct context
{
	char buff[50];
	int len;
	struct cdev mycdev;
}mycntx;


dev_t devno;
int majr;
int minr=1;


static int myopen(struct inode *ind,struct file *fil)
{
	pr_info("the open is invoked \n");
	try_module_get(THIS_MODULE);
	fil->private_data=&mycntx;
	return 0;
}


static int myclose(struct inode *ind, struct file *fil)
{
	module_put(THIS_MODULE);
	pr_info("file is closed \n");
	return 0;
}

static ssize_t mywrite(struct file *fil,const char *buff,size_t len,loff_t *offset)
{

	struct context *tdev;
	tdev=fil->private_data;
	copy_from_user(tev->buff,buff,len);
	tdev->len=len;
	pr_info("this write is invoked \n");
	return len;
}

static ssize_t myread(struct file *fil, char*buff,size_t len,loff_t *offset)
{

	int ret;
	struct context *tdev;
	tdev = fil->private_data;
	ret=copy_to_user(buff,tdev->buff,tdev->len);
	pr_info("the buff : %s\n",buff);
	pr_info("read is invoked %d \n",ret);
	return ret;
}

struct file_operations fops = {.owner=THIS_MODULE, .open = myopen , .release=myclose, .read=myread,  .write = mywrite};

static int my_initfun(void)
{
	int res;
	res=alloc_chrdev_region(&devno,minr,1,"balu");
	pr_info("major no : %d \n",majr=MAJOR(devno));
	pr_info("minor no : %d \n",minr=MINOR(devno));
	pr_info("dev no : %d \n",devno);
	cdev_init(&mycntx.mycdev,&fops);
	cdev_add(&mycntx.mycdev,devno,1);
	return 0;
}

static void my_exitfun(void)
{
	pr_info("the exit is invoked \n");
	cdev_del(&mycntx.mycdev);
	unregister_chrdev_region(devno,1);
}

module_init(my_initfun);
module_exit(my_exitfun);

MODULE_AUTHOR("BALAJI");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("BALU");
