#include<linux/module.h>
#include<linux/kthread.h> // for kernel threads
#include<linux/sched.h>  // for task_struct
#include<linux/uaccess.h>  // for cop_to_user
#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/fs.h>
#include<linux/ioport.h>
#include<linux/poll.h> // for registeration purpouse we have to use i.e register_chardev_region
#include<linux/errno.h>
#include<linux/cdev.h>
#include<linux/kdev_t.h>
#include<linux/device.h>

struct task_struct *thr,*thr2;
struct mutex mtx;
int mglb=0;
int a=1;
//mykthred
int mykthread(void *ptr)
{
        while(mglb<=100)
        {
                mutex_lock(&mtx);
                if(mglb%2)
                        pr_info("thread1 : %d \n",mglb++);
        //else
                mutex_unlock(&mtx);
        }

        return 0;
}

int mykthread2(void *ptr)
{
        while(mglb<=100)
        {
                mutex_lock(&mtx);
                if(!(mglb%2))
                        pr_info("\t\tthread2 : %d \n",mglb++);
        //      else
                mutex_unlock(&mtx);
        }
        return 0;
}


/* my thread function 
int mythread_fn(void *ptr)
{
	while(1)
		pr_info(" my thread is invoked\n" );
	return 0;
}*/

//declaration of fuvctions
static int mychar_driver(void)
//int init_module(void)
//static int __init fun_start(void)
{
	int res=0;
	mutex_init(&mtx);
	thr=kthread_create(mykthread,&a,"balu");
	if(thr)
		pr_info("our thread created succesfully \n");
	else
		pr_info("failed to create the thread \n");
	res=wake_up_process(thr);
	if(res==0)
		pr_info("out thread has already started \n" );
	else
		pr_info("out thread started now\n" );

//	proc=proc_mkdir("balu_dir",NULL);
//	proc_create("balu_file",0777,proc,&pops);
        thr2=kthread_run(mykthread2,&a,"mykthread2");
	return 0;
}


static void mychar_exit(void)
//void cleanup_module(void) 
//static void __exit fun_end(void)
{
	int res=0;
//	res=kthread_stop(thr);
//	kthread_stop(thr);
  //      kthread_stop(thr2);
	if(res==0)
	{
		pr_info("our thread is stoped \n" );
	}
	printk(KERN_INFO "my char driver : \n");
	printk(KERN_INFO "unloaded succesfully\n");
//	proc_remove(proc);
}

module_init(mychar_driver);
module_exit(mychar_exit);

MODULE_AUTHOR("BALAJI");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("basic module");


