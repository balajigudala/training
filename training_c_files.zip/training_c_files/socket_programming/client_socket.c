#include<stdio_ext.h>
#include<fcntl.h>
#include<stdio.h>
#include<string.h>
#include<netinet/in.h>
#include<sys/socket.h>
int main()
{
	int sockfd,client_size,ret;
	char buff[256];
	struct sockaddr_in serv;
	sockfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	bzero(&serv,sizeof(serv));
	//memset(&serv,0,sizeof(serv));
	serv.sin_family=AF_INET;
	serv.sin_port=htons(5002);
//	serv.sin_addr.s_addr=inet_addr("192.168.143.74");
	serv.sin_addr.s_addr=inet_addr("127.0.0.1");
	connect(sockfd,(struct sock_addr *)&serv,sizeof(serv));
	while(1)
	{
		bzero(buff,sizeof(buff));
		printf("\nenter the message : ");
		__fpurge(stdin);
		scanf("%[^\n]s",buff);
		if((strcmp(buff,"exit")==0))
				break;
		ret=send(sockfd,buff,strlen(buff),0);
		ret=recv(sockfd,buff,256,0);
		printf("\nrecieved : %s\n",buff);
	}
	close(sockfd);
}
