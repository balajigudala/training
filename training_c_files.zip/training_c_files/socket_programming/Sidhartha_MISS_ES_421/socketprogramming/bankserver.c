#include"struct.h"
struct status s;
struct profile pr;
struct login lp;
struct Bank b;

void Deposit(struct Bank b,int newsockfd);
void Profile(int newsockfd);
void Register(int newsockfd);
void Crt_prf(struct profile pr,int newsockfd);
int Checking(void* mkd,int newsockfd);
void Withdraw(struct Bank b,int newsockfd);
void Login(int newsockfd);
void Balance(int newsockfd);

void Register(int newsockfd)//to register new account
{
	void *mkd;
	int ret;
	char lct[40]="BANKDATABASE/";
	read(newsockfd,&pr,sizeof(pr));
	strcat(lct,pr.userid);
	printf("add:%s\n",lct);
	mkd=opendir(lct);
	if(mkd==NULL)
		mkdir(lct,0777);
	ret=Checking(mkd,newsockfd);//checking wheather it is existed user using function
	if(ret==0)
		Crt_prf(pr,newsockfd);// if new user creating the files by using function
}
void Crt_prf(struct profile pr,int newsockfd)//function for creation
{
	int fd,tfd;
	char lct[40]="BANKDATABASE/";
	char add[40]="BANKDATABASE/";
	strcat(lct,pr.userid);
	//printf("add:%s\n",lct);
	strcat(lct,"/profile_info");
	//printf("add:%s\n",lct);
	fd=open(lct,O_RDWR|O_CREAT,0777);
	if(fd<0)
	{
		printf("failed to create profile file\n");
		return;
	}
	strcat(add,pr.userid);
	strcat(add,"/Trans_history");
	tfd=open(add,O_RDWR|O_CREAT,0777);
	if(tfd<0)
	{
		printf("failed to create trans-history\n");
		return;
	}
	write(fd,&pr,sizeof(pr));
	s.stat=0;
	write(newsockfd,&s,sizeof(s));
	close(fd);
}
int Checking(void* mkd,int newsockfd)//function for checking the user
{
	int res=0;
	if(mkd!=NULL)
	{
		res++;
		s.stat=-1;
		write(newsockfd,&s,sizeof(s));
	}
	return res;
}
void Withdraw(struct Bank b,int newsockfd)//withdraw function
{
        struct profile pr;
        printf("enter the deposit\n");
        read(newsockfd,&lp,sizeof(lp));
        //printf("login id:%s\n",lp.userid);
        int fd;
        char lct[40]="BANKDATABASE/";
        strcat(lct,lp.userid);
        strcat(lct,"/profile_info");
        //printf("lct:%s\n",lct);
        fd=open(lct,O_RDWR);
        if(fd<0)
        {
                printf("failed to open profile in deposit\n");
                return;
        }
        read(fd,&pr,sizeof(pr));
        pr.bal=pr.bal - b.amt;
        lseek(fd,0,SEEK_SET);
        ftruncate(fd,0);
        write(fd,&pr,sizeof(pr));
        b.stat=1;
        write(newsockfd,&b,sizeof(b));
}




void Login(int newsockfd)//to login the user 
{
	printf("login enterd\n");
	void* mkd;
	int fd;
	read(newsockfd,&lp,sizeof(lp));
	char lct[40]="BANKDATABASE/";
	//printf("lp.pas:%s\n",lp.pswrd);
	strcat(lct,lp.userid);
	printf("%s\n",lct);
	mkd=opendir(lct);
	if(mkd==NULL)
	{
		bzero(&s,sizeof(s));
		s.stat=-1;
		write(newsockfd,&s,sizeof(&s));
	}
	else
	{
	strcat(lct,"/profile_info");
	printf("add:%s\n",lct);
	fd=open(lct,O_RDWR);
	if(fd<0)
	{
		printf("failed to open profile file while login\n");
		return;
	}
	read(fd,&pr,sizeof(pr));
	if(strcmp(pr.passw,lp.pswrd)==0)
	{
		 bzero(&s,sizeof(s));
                s.stat=1;
                write(newsockfd,&s,sizeof(&s));

	}
	else
	{
		 bzero(&s,sizeof(s));
                s.stat=2;
                write(newsockfd,&s,sizeof(&s));

	}
	read(newsockfd,&b,sizeof(b));
	printf("switch:%d\n",b.swit);
	switch(b.swit)
	{
		case 1:
			Deposit(b,newsockfd);
			break;
		case 2:
			Balance(newsockfd);
			break;
		case 3:
			Withdraw(b,newsockfd);
		case 5:
			Profile(newsockfd);
			break;
	}

}
}
void Balance(int newsockfd)//checking the balance
{
	 struct profile pr;
        read(newsockfd,&lp,sizeof(lp));
        //printf("login id:%s\n",lp.userid);
        int fd;
        char lct[40]="BANKDATABASE/";
        strcat(lct,lp.userid);
        strcat(lct,"/profile_info");
        //printf("lct:%s\n",lct);
        fd=open(lct,O_RDWR);
        if(fd<0)
        {
                printf("failed to open profile in profile\n");
                return;
        }
        read(fd,&pr,sizeof(pr));
        write(newsockfd,&pr,sizeof(pr));
}
void Profile(int newsockfd)//verifying the profile
{
	struct profile pr;
        printf("enter the profile\n");
        read(newsockfd,&lp,sizeof(lp));
        //printf("login id:%s\n",lp.userid);
        int fd;
        char lct[40]="BANKDATABASE/";
	strcat(lct,lp.userid);
	strcat(lct,"/profile_info");
	printf("lct:%s\n",lct);
	fd=open(lct,O_RDWR);
	if(fd<0)
        {
                printf("failed to open profile in profile\n");
                return;
        }
	read(fd,&pr,sizeof(pr));
	write(newsockfd,&pr,sizeof(pr));
}
void Deposit(struct Bank b,int newsockfd)//depositing the money
{
	struct profile pr;
	printf("enter the deposit\n");
	read(newsockfd,&lp,sizeof(lp));
	//printf("login id:%s\n",lp.userid);
	int fd;
	char lct[40]="BANKDATABASE/";
	strcat(lct,lp.userid);
	strcat(lct,"/profile_info");
	//printf("lct:%s\n",lct);
	fd=open(lct,O_RDWR);
	if(fd<0)
	{
		printf("failed to open profile in deposit\n");
		return;
	}
	read(fd,&pr,sizeof(pr));
	pr.bal=pr.bal+ b.amt;
	lseek(fd,0,SEEK_SET);
	ftruncate(fd,0);
	write(fd,&pr,sizeof(pr));
	b.stat=1;
	write(newsockfd,&b,sizeof(b));
}
	

void main()
{
	void *mkd;
	char buf[50];
	struct sockaddr_in serv,client;
	int sockfd,newsockfd,bi,client_size;

	mkd=opendir("BANKDATABASE");
	//printf("mkd:%p\n",mkd);
	if(mkd==NULL)
	{
		mkdir("BANKDATABASE",0777);
	}

	sockfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	//printf("sockfd:%d\n",sockfd);
	if(sockfd<0)
	{
		printf("failed to create socket\n");
		exit(1);
	}
	bzero(&serv,sizeof(serv));
	serv.sin_family=AF_INET;
	serv.sin_port=htons(1222);
	serv.sin_addr.s_addr=INADDR_ANY;

	bi=bind(sockfd,(struct sockaddr*)&serv,sizeof(serv));
	printf("bind: %d\n",bi);
	listen(sockfd,5);
	client_size=sizeof(client);

	newsockfd=accept(sockfd,(struct sockaddr *)&client,&client_size);
	//printf("newsockfd:%d\n",newsockfd);
	read(newsockfd,buf,50);
	printf("%s\n",buf);
	while(1)
	{
		read(newsockfd,&s,sizeof(s));
		switch(s.swt)
		{
			case 1:
				Register(newsockfd);
				break;
			case 2:
				Login(newsockfd);
				break;
			case 3:
				exit(1);
	}


}
close(newsockfd);
}
		
