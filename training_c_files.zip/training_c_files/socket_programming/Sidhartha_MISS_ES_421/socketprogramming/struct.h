#include<stdio.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<time.h>
#include<string.h>
#include<dirent.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/stat.h>
#include<arpa/inet.h>
#include<stdio_ext.h>
#include<unistd.h>
struct status
{
int swt;
int stat;
};
struct usr_addrs
{
char h_no[20];
char area[30];
char loca[30];
char state[30];
char dst[30];
};
struct nomine
{
char n_name[50];
char n_mbl[15];
char n_adhr[16];
};
struct dob
{
int date;
int mnth;
int year;
};
struct timee 
{
unsigned int day;
unsigned int month;
unsigned int year;
unsigned int hour;
unsigned int minute;
unsigned int secs;
};
struct profile 
{
char usr_name[50];
char userid[10];
char passw[20];
char gen;
char mbl_nmbr[15];
char adhar[15];
char acc_nmbr[30];
unsigned int bal;
struct nomine nm;
struct dob db;
struct timee tm;
struct usr_addrs add;
};
struct login
{
char userid[12];
char pswrd[16];
};
struct Bank
{
unsigned int amt;
int stat;
int swit;
};
