#include"struct.h"

struct profile pr;
struct tm tim;
struct login lg;
struct Bank b;
struct status s;

void Login(int sockfd);
void Register(int sockfd);
void SUB_menu(int opt,struct login lg,int sockfd);
void Profile(int sockfd);

void Register(int sockfd)//for user regestration
{
	bzero(&pr,sizeof(pr));
	char buf[10];
	int i;
	time_t t=time(NULL);
	printf("enter user name\n");
	scanf("%[^\n]s",pr.usr_name);
	__fpurge(stdin);
	printf("enter user id of 8 digits\n");
	scanf("%s",pr.userid);
	__fpurge(stdin);
	if(strlen(pr.userid)!=8)
	{
		printf("please enter the user id of size 8 characters\n");
		return;
	}
	printf("enter password in range of 8 to 16\n");
	scanf("%s",pr.passw);
	__fpurge(stdin);
	if((strlen(pr.passw)<8) || (strlen(pr.passw)>16))
	{
		printf("please enter the password in the range of 8 to 16 characters\n");
		return;
	}
	printf("enter gender\n");
	scanf("%c",&pr.gen);
	__fpurge(stdin);
       	printf("enter mobile number 10 digits\n");
        scanf("%s",pr.mbl_nmbr);
        __fpurge(stdin);
	if(strlen(pr.mbl_nmbr)!=10)
	{
		printf("please the enter the 10 digit mobile number\n");
		return;
	}
	 printf("enter Aadhar number of 12 digits\n");
        scanf("%s",pr.adhar);
        __fpurge(stdin);
	if(strlen(pr.adhar)!=12)
	{
		printf("please enter the 12 digit adhar number\n");
		return ;
	}
	strcpy(pr.acc_nmbr,pr.mbl_nmbr);
	for(i=0;i<4;i++)
	{
		buf[i]=pr.adhar[i];
	}
	strcat(pr.acc_nmbr,buf);
	printf("acc:nmbr: %s\n",pr.acc_nmbr);
	pr.bal=0;
	printf("enter nominee name\n");
	scanf("%s",pr.nm.n_name);
	__fpurge(stdin);
	printf("enter nominee mobile number\n");
        scanf("%s",pr.nm.n_mbl);
        __fpurge(stdin);
	printf("enter nominee adhar number\n");
        scanf("%s",pr.nm.n_adhr);
        __fpurge(stdin);
	printf("enter date of birth(date month year)\n");
	scanf("%d %d %d",&pr.db.date,&pr.db.mnth,&pr.db.year);
	__fpurge(stdin);

	tim=*localtime(&t);
	pr.tm.day=tim.tm_mday;
	pr.tm.month=tim.tm_mon+1;
	pr.tm.year=tim.tm_year+1900;
	pr.tm.hour=tim.tm_hour;
	pr.tm.minute=tim.tm_min;
	pr.tm.secs=tim.tm_sec;

	printf("\n---enter user address---\n");
	printf("enter house number\n");
	scanf("%s",pr.add.h_no);
	__fpurge(stdin);
	printf("enter area\n");
        scanf("%[^\n]s",pr.add.area);
        __fpurge(stdin);
	printf("enter location\n");
        scanf("%[^\n]s",pr.add.loca);
        __fpurge(stdin);
	printf("enter state\n");
        scanf("%[^\n]s",pr.add.state);
        __fpurge(stdin);
	printf("enter district\n");
        scanf("%[^\n]s",pr.add.dst);
        __fpurge(stdin);
	write(sockfd,&pr,sizeof(pr));
        read(sockfd,&s,sizeof(s));
	if(s.stat==-1)
	{
		printf("\n-----user already exists try to register with another user----\n");
		return;
	}
	else
		printf("\n----- user registered succesfullu-----\n");

}
void Login(int sockfd)
{
	int opt;
	bzero(&lg,sizeof(lg));
	printf("enter the 8 digits user id\n");
	scanf("%s",lg.userid);
	__fpurge(stdin);
	printf("enter the password\n");
	scanf("%s",lg.pswrd);
	__fpurge(stdin);
	write(sockfd,&lg,sizeof(lg));
	read(sockfd,&s,sizeof(s));
	if(s.stat==-1)
	{
		printf("\n------user does not exist----------\n");
		return ;
	}
	else if(s.stat==1)
	{
		printf("\n---------user login sucessfull----------\n");
		printf("\nselect the operation you want to perform\n");
		printf("1)Deposit\n2)Balance\n3)Withdraw\n4)Transaction history\n5)Profile info\n6)Logout\n");
		scanf("%d",&opt);
		__fpurge(stdin);
		SUB_menu(opt,lg,sockfd);
		return;
	}
	else if(s.stat==2)
	{
		printf("\n----------yo have enetered wrong password---------\n");
	}
}

void SUB_menu(int opt,struct login lg,int sockfd)//after loging into perform these operations
{
	int amnt;
	switch(opt)
	{
		case 1:
		        printf("enter the amount you want to deposit\n");
		      	scanf("%d",&amnt);
			__fpurge(stdin);
			bzero(&b,sizeof(b));
			b.amt=amnt;
			b.swit=1;
			write(sockfd,&b,sizeof(b));
			write(sockfd,&lg,sizeof(lg));
			read(sockfd,&b,sizeof(b));
			if(b.stat==1)
				printf("amount credited sucessfully\n");
			break;
		 case 2:
			b.swit=2;
			write(sockfd,&b,sizeof(b));
			write(sockfd,&lg,sizeof(lg));
			read(sockfd,&pr,sizeof(pr));
			printf("\n--- User Balance is :%d\n",pr.bal);
			break;
		case 3:
			printf("enter the amount you want to withdraw\n");
                        scanf("%d",&amnt);
                        __fpurge(stdin);
                        bzero(&b,sizeof(b));
                        b.amt=amnt;
                        b.swit=3;
                        write(sockfd,&b,sizeof(b));
                        write(sockfd,&lg,sizeof(lg));
                        //read(sockfd,&b,sizeof(b));
                        if(b.stat==1)
                                printf("amount debited  sucessfully\n");

			break;
		case 4:
			break;
		case 5:
			bzero(&b,sizeof(b));
                        b.swit=5;
                        write(sockfd,&b,sizeof(b));
                        write(sockfd,&lg,sizeof(lg));
			Profile(sockfd);
			break;
		case 6:
			return;
	}
}

void Profile(int sockfd)   // to print the profile of the user
{
	read(sockfd,&pr,sizeof(pr));
        printf("user name:             %s\n",pr.usr_name);
        printf("user id:               %s\n",pr.userid);
        printf("user password:         %s\n",pr.passw);
        printf("user Gender:           %c \n",pr.gen);
        printf("user mobile number:    %s\n",pr.mbl_nmbr);
        printf("Adhar Number:          %s\n",pr.adhar);
	printf("acc:nmbr:              %s\n",pr.acc_nmbr);
        printf("user balance:          %d\n",pr.bal);
        printf("nominee name:          %s \n",pr.nm.n_name);
        printf("nominee mobile number: %s\n",pr.nm.n_mbl);
        printf("nominee adhar number:  %s \n",pr.nm.n_adhr);
        printf("date of birth :        %d %d %d \n",pr.db.date,pr.db.mnth,pr.db.year);
        printf("day: %d month: %d year: %d  time: %dhrs %dmins %dsecs  \n",pr.tm.day,pr.tm.month,pr.tm.year,pr.tm.hour,pr.tm.minute,pr.tm.secs);
        printf("house number:          %s\n",pr.add.h_no);
        printf("area:                  %s\n",pr.add.area);
        printf("location               %s\n",pr.add.loca);
        printf("state :                %s\n",pr.add.state);
        printf("district :             %s\n",pr.add.dst);
}

void main()
{
	void *mkd;
	struct sockaddr_in serv;
	int sockfd,opt;

	sockfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sockfd<0)
	{
                printf("failed to create socket\n");
                exit(1);
        }
	bzero(&serv,sizeof(serv));
        serv.sin_family=AF_INET;
        serv.sin_port=htons(1222);
        serv.sin_addr.s_addr=inet_addr("127.0.0.1");
	connect(sockfd,(struct sockaddr *)&serv,sizeof(serv));
	send(sockfd,"server and client are connected",strlen("server and client are connected"),0);
        
       	mkd=opendir("BANKDATABASE");
        if(mkd==NULL)
        {
                printf("failed to open file\n");
                exit(1);
        }
        //printf("mkd:%pi\n",mkd);
	while(1)
	{
		printf("\n\nselect the operation to be performed\n");
		printf("1)REGISTER\n2)LOGIN\n3)EXIT\n\n");
		scanf("%d",&opt);
		__fpurge(stdin);
		switch(opt)
		{
			case 1:
				bzero(&s,sizeof(s));
				s.swt=1;
				write(sockfd,&s,sizeof(s));
				Register(sockfd);
				break;
			case 2:
				bzero(&s,sizeof(s));
                                s.swt=2;
				write(sockfd,&s,sizeof(s));
				Login(sockfd);
				break;
			case 3:
				bzero(&s,sizeof(s));
                                s.swt=3;
				write(sockfd,&s,sizeof(s));
				exit(1);
		}
	}

}

