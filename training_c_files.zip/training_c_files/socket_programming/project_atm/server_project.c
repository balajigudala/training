#include<stdio.h>
struct dob
{
	unsigned int day;
	unsigned int mon;
	unsigned int year;
}
struct reg
{
	int opt;
	char u_name;

