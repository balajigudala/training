#include<stdio_ext.h>
#include<fcntl.h>
#include<stdio.h>
#include<string.h>
#include<netinet/in.h>
#include<sys/socket.h>
int main()
{
	int sockfd,newsockfd,client_size,ret;
	char buff[256];
	struct sockaddr_in serv,client;
	sockfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	bzero(&serv,sizeof(serv));
	serv.sin_family=AF_INET;
	serv.sin_port=htons(5002);
	serv.sin_addr.s_addr=INADDR_ANY;
	ret=bind(sockfd,(struct sock_addr *)&serv,sizeof(serv));
	printf("bind ret : %d \n",ret);
	listen(sockfd,1);
	client_size=sizeof(client);
	newsockfd=accept(sockfd,(struct sockaddr *)&client,&client_size);
	while(1)
	{
		bzero(buff,sizeof(buff));
	//	ret=read(newsockfd,buff,256);
		ret=recv(newsockfd,buff,256,0);
		//write(1,buff,ret);
		printf("\nrecieved message : %s\n ",buff);
		printf("\nenter the message : " );
		__fpurge(stdin);
		scanf("%[^\n]s",buff);
		//	ret=write(newsockfd,buff,strlen(buff));
		if((strcmp(buff,"exit")==0))
			break;
		ret=send(newsockfd,buff,strlen(buff),0);
	}
	close(newsockfd);
}
