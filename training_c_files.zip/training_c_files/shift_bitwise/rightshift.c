#include<stdio.h>
int main()
{
	char x=0x80;
	x=x>>4;
	printf("%x",x);
}
