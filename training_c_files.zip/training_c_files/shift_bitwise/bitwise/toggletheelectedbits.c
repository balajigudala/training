#include<stdio.h>
int main()
{
        unsigned int z;
        unsigned int a,b;
        printf("// The program to toggle the required bits //\n");
        printf("enter the hexadecimal input  : ");
        scanf("%x",&z);
	printf("enter the bits required to toggle : ");
	scanf("%d%d",&a,&b);
	printf("swapped output : ");
        ((1&&(z&(0x1<<a)))==((1&&z&(0x1<<b))))?printf("%x\n",z):((z=(z^((0x1<<a)|(0x1<<b)))),printf("%x\n",z));
}
