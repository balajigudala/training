#include<stdio.h>
int main()
{
	unsigned int x;
	int bit;
	printf("enter the input in hexa : ");
	scanf("%x",&x);
//	fpurge();
        printf("enter the nibble required : ");
	scanf("%d",&bit);
        unsigned int y=(((x&(~(0xf<<(bit+4))))|((x&(0xf<<bit))))>>bit);
        unsigned  char z=y;	
        printf("%x",z);
}
