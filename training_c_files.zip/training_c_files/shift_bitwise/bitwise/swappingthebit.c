#include<stdio.h>
int main()
{
	unsigned int x;
	scanf("%x",&x);
	unsigned int bit1,bit2;
	scanf("%d%d",&bit1,&bit2);
	unsigned int y=(((x&~((0x1<<bit1)|(0x1<<bit2)))|((x&(0x1<<bit1))<<bit2-bit1)|(x&(0x1<<bit2))>>bit2-bit1));
	printf("%x",y);		
}
