#include<stdio.h>
int main()
{
	unsigned int var,sum,count=0,count1=0,var1;
	int opt,bit1,bit2,temp=0;
	printf("1-Count no of zeroes\n2-Count of 101\n3-Binary using Bitwise\n4-Swap the bits\n5-Rewrite 101-111\n");
	printf("enter the option to parcticipate the operation : ");
	scanf("%d",&opt);
	printf("enter the hexa decimal input : ");
	scanf("%x",&var);
	switch (opt)
	{
		case 1:
			//count of zeros in given input
			for(temp=0,count=0;temp<32;temp++)
			{
				if((((0x1<<temp)&var)>>temp)==0)
				{
					count++;
				}
				else
					count1++;
			}
			printf("count of zeroes = %d\n",count);
			break;
		case 2:
			//count of 101 combinations in given input
			for(count=temp=0;temp<30;temp++)
			{
				if(((var&(0x7<<temp))>>temp)==5)
					count++;

			}
			printf("%d\n",count);
			break;
		case 3:
			//hexadecimal to binary convertion for given input
			for(temp=31;temp>=0;temp--)
			{
				if((((0x1<<temp)&var)>>temp)==0)
					printf("0");
				else
					printf("1");

			}
			printf("\n");
			break;
		case 4:
			//swapping the required bits in the given hexa decimal input
			printf("enter the bits position to swap : ");
			scanf("%d%d",&bit1,&bit2);
			sum=(((var&(~((0x1<<bit1)|(0x1<<bit2))))|((var&(0x1<<bit1))<<bit2-bit1)|(var&(0x1<<bit2))>>bit2-bit1));
			printf("swapped output =%x\n",sum);
			break;
		case 5:
			//modifying the 101 combination to 111 for given hexa decimal input
			//sum=var;
			for(count=temp=sum=var1=0;temp<30;temp++)
			{
				if(((var&(0x7<<temp))>>temp)==5)
				{
					sum=(((~((0x7)<<(temp)))&var)|((0x7)<<(temp)));
					var1=(sum|var1);
				}
			}
			printf("modified input = 0x%x\n",var1);
			break;
	}
}


