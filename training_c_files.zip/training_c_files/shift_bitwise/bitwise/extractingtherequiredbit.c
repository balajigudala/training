#include<stdio.h>
unsigned int mock;
int main()
{
	unsigned int x;
	printf("enter the hexa decimal input to swap : ");
	scanf("%x",&x);
	printf("enter the mock value : ");
	scanf("%x",&mock);
	printf("enter the bit1 and bit2 to swap  :  ");
	unsigned int bit1,bit2;
	scanf("%d%d",&bit1,&bit2);
	if(bit1>bit2)
	{
		int temp=bit1,bit1=bit2,bit2=temp;
	}
	(mock==0x1)?mock=0x1:mock==0xf?mock==0xf?mock=0xf:mock==0xff
	unsigned long int y=((x&(~((mock<<bit1)|(mock<<bit2))))|(((mock<<bit1)&x)<<(mock-bit1))|(((mock<<bit2)&x)>>(bit2-bit1)));
	printf("0x%lx",y);		
}
