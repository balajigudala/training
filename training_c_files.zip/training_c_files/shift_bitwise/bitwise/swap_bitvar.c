#include"header.h"
int SWAP_BITVAR(int a)
{
        //swapping with bitwise
        int b;
        printf("enter the two variables a : b :  ");
        scanf("%d%d",&a,&b);
        a=a^b;
        b=a^b;
        a=a^b;
        printf("swapped output is a=%d, b=%d\n",a,b);

}

