#include"header.h"
int MOD_BITS(unsigned int var)
{
        //modifying the 101 combination to 111 for given hexa decimal input
        int count,temp,sum;
        unsigned int var1;
        printf("enter the input : ");
        scanf("%x",&var);
        for(count=temp=sum=var1=0;temp<30;temp++)
        {
                if(((var&(0x7<<temp))>>temp)==5)
                {
                        sum=(((~((0x7)<<(temp)))&var)|((0x7)<<(temp)));
                        var1=(sum|var1);
                }

        }

        printf("0x%x\n",var1);
}

