#include"header.h"
int DEC_BINBIT(int var1)
{
        //binary convertion
        int sum,pow,rem;
        printf("enter the input : " );
        scanf("%d",&var1);
        sum=0;
        pow=1;
        while(var1!=0)
        {
                rem=var1%2;
                var1= var1/2;
                sum=sum+(rem*pow);
                pow =pow * 10;
        }
        printf("binary = %u\n", sum);
}

