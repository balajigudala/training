#include<stdio.h>
int main()
{
	int shift,count;
	unsigned int var;
	scanf("%x",&var);
	unsigned int zar;
	for(count=shift=0;shift<28;shift++)
	{
		if(((var&(0x7<<shift))>>shift)==5)
			count++;
	
	}
	printf("%d",count);
}
