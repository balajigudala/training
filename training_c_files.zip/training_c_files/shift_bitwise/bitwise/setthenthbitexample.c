// The program to set nth bit of given number 
#include<stdio.h>
int main()
{
        unsigned int y,z,x;
	printf("enter the given input and set bit value in hexadecimal : ");
	scanf("%x%x",&x,&y);
        z=x|y;
        printf("the given char %x\nthe set bit value is%x\nthe output after set is %x\n",x,y,z);
}

