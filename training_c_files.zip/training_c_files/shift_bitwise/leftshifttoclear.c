#include<stdio.h>
int main()
{
        unsigned int y,z,x,n;
        printf("// The program to clear the n th bit using leftshift  //\n");
        printf("enter the given input in hexadecimal to clear the nth bit : ");
        scanf("%x",&x);
        printf("enter the LSB starting bit to clear : ");
        scanf("%d",&y);
        printf("enter the n of consecutive bits to clear : ");
        scanf("%x",&n);
        z=x&(~(n<<y));
        printf("the given char %x\nthe nth bit to clear is%d\n the no of consecutive bits to clear is %x\nthe output after clear is %x\n",x,y,n,z);
}


