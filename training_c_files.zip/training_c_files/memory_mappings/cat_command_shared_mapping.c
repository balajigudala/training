#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/mman.h>
#include<sys/stat.h>
int main(int arg,char *str[])
{
	int fd,ret,size,i=1;
	char *ptr;
	struct stat buff;
	while(i<arg)
	{
		fd=open(str[i],O_RDWR);
		//	printf("fd : %d \n",fd);
		if(fd<0)
		{
			printf("cat: %s: Non such file or directory\n",str[i]);
			i++;
			continue;
		}
		fstat(fd,&buff);
		size=buff.st_size;
		//	printf("size : %d \n",size);
		ptr=mmap(NULL,buff.st_size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
		write(1,ptr,size);
		ret=munmap(ptr,size);
		i++;
	}
}
