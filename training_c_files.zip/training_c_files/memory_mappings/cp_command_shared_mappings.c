#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/mman.h>
#include<sys/stat.h>
int main(int arg,char *str[])
{
	int fd,fd2,ret,size,i=1;
	char *ptr,*ptr2;
	struct stat buff;
	fd=open(str[i],O_RDWR);
	//	printf("fd : %d \n",fd);
	fstat(fd,&buff);
	size=buff.st_size;
	//	printf("size : %d \n",size);
	ptr=mmap(NULL,buff.st_size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
//	write(1,ptr,size);
//	ret=munmap(ptr,size);
        fd2 =open(str[2],O_RDWR|O_CREAT|O_TRUNC,0664);
	printf("fd2 : %d \n",fd2);
	ret=ftruncate(fd2,size);
	printf("ftrunc ret  : %d \n",ret);
	//printf("%s\n",ptr2);
	ptr2=mmap(NULL,size,PROT_READ|PROT_WRITE,MAP_SHARED,fd2,0);
	printf(" %p    %p \n", ptr,ptr2);
	memcpy(ptr2,ptr,size);
//	printf("%s",ptr2);
}
