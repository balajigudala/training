#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/mman.h>
int main()
{
	int *ptr;
#ifdef USE_MAP_ANON
	ptr=mmap(NULL,sizeof(int),PROT_READ|PROT_WRITE,MAP_SHARED|MAP_ANONYMOUS,1,0);
	if(ptr==NULL)
		printf("failed in define ");
#else
	int fd=open("dev/zero",O_RDWR);
	ptr=mmap(NULL,sizeof(int),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
	if(ptr==NULL)
		printf("failed in else ");
	close(fd);
	int pid=fork();
	if(pid>0)
	{
		sleep(2);
		printf("parent process : %d\n",*ptr);
		exit(0);
	}
	else
	{
		*ptr=4;
		printf("child process : %d \n",*ptr);
		exit(2);
	}
#endif
}

