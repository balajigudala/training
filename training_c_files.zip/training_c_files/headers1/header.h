#include<stdio.h>
int PALINDROME(int);
int DEC_BIN(int);

