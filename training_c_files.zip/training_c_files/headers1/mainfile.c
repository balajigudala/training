#include"header.h"
int main()
{
	int res,n;
		res=NO_DIGITS(n);
		return res;
}
