#include"header.h"
int NO_DIGITS(int var1)
{
        //no of digits
        int count;
        printf("enter the input : " );
        scanf("%d",&var1);
        count=0;
        while(var1!=0)
        {
                var1=var1/10;
                count++;
        }
        printf("count = %d\n",count);

}

