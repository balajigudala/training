int sum=0,a=10;
