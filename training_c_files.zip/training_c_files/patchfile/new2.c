#include<stdio.h>
int main()
{
	int a=10,sum=0;
	int b=20;
	sum=a+b;
	printf("sum : %d \n",sum);
}

