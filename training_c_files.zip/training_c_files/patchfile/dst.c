#include<stdio.h>
int main()
{
	printf("gudala"\n);
}

