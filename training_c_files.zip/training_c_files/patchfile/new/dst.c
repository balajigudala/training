#list
apple
ant
banana
bat
cat
dog
