#list
apple
banana
cat
dog
