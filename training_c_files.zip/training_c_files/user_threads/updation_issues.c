#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
int glob = 0;
void * mythread_fun1(void *);
void * mythread_fun2(void *);
int main()
{
	pthread_t ti1,ti2;
	int i,ret,ret1,loop=10000;
	void *res;
	ret=pthread_create(&ti1,0,mythread_fun1,&loop);
	ret1=pthread_create(&ti2,0,mythread_fun2,&loop);
	if(ret<0||ret1<0)
	{
		printf("failed to create the new thread \n ");
		exit(1);
	}
	pthread_join(ti1,&res);
	pthread_join(ti2,&res);
	printf("glob : %d \n", glob);
}
void* mythread_fun1(void *ptr)
{
	int i,local,loop;
	loop = *(int *)ptr;
	for(i=0;i<=loop;i++)
	{
		local = glob;
		local++;
		glob = local;
	}
}
void* mythread_fun2(void *ptr)
{
	int i,local,loop;
	loop = *(int *)ptr;
	for(i=0;i<=loop;i++)
	{
		local = glob;
		local++;
		glob = local;
	}
}
