#include<stdio.h>
#include<pthread.h>
int glob=0;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

void * mythread_fun1(void *loop)
{
	int i,var =*(int*)loop;
	printf("my thread function 1 invoked : %d\n",i);
	int local;
	for(i=0;i<var;i++)
	{
		pthread_mutex_lock(&mtx);
		local=glob;
		local++;
		glob=local;
		pthread_mutex_unlock(&mtx);
	}
	return loop;
}


void * mythread_fun2(void *loop)
{
	int i,var =*(int*)loop;
	printf("my thread function 2 invoked : %d\n",i);
	int local;
	for(i=0;i<var;i++)
	{
		pthread_mutex_lock(&mtx);
		local=glob;
		local++;
		glob=local;
		pthread_mutex_unlock(&mtx);
	}
	return loop;
}


int main()
{
	pthread_t t1,t2;
	int loop=200000,res,res2;
	res=pthread_create(&t1,0,mythread_fun1,&loop);
	res2=pthread_create(&t2,0,mythread_fun2,&loop);
	if(res&&res2)
	{
		printf("failed to create the thread \n");
		return -1;
	}
	printf("res : %d \nt1 : %ld \n",res,t1);
	printf("res2 : %d \nt2 : %ld \n",res2,t2);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("the glob : %d \n",glob);
}


