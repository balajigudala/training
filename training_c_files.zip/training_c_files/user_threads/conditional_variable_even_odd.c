#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
int glob = 0,loop=100,i=0;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cnd = PTHREAD_COND_INITIALIZER;
void * mythread_fun1(void *);
void * mythread_fun2(void *);
int main()
{
	pthread_t ti1,ti2;
	int i,ret,ret1;
	void *res;
	ret=pthread_create(&ti1,0,mythread_fun1,&loop);
	ret1=pthread_create(&ti2,0,mythread_fun2,&loop);
	if(ret<0||ret1<0)
	{
		printf("failed to create the new thread \n ");
		exit(1);
	}
	pthread_join(ti1,NULL);
	printf("\n\nthread1 completd ");
	pthread_join(ti2,NULL);
	printf("glob : %d \n", glob);
}
void* mythread_fun1(void *ptr)
{
	int local;
	while(i<loop)
	{
		pthread_mutex_lock(&mtx);
		if(i%2)
		{
			pthread_cond_wait(&cnd,&mtx);
		}
		else
			printf("th1 : %d  : %ld \n",i++,pthread_self());
		pthread_mutex_unlock(&mtx);
	        pthread_cond_signal(&cnd);
	}
}
void* mythread_fun2(void *ptr)
{
	int local;
	while(i<loop)
	{
		pthread_mutex_lock(&mtx);
		if(!(i%2))
		{
			pthread_cond_wait(&cnd,&mtx);
		}
		else
			printf("\t\t\t\tth2 : %d  : %ld \n",i++,pthread_self());
		pthread_mutex_unlock(&mtx);
		pthread_cond_signal(&cnd);
	}
}


/*
syntax : timedwait : int pthread_cond_timedwait(pthread_cond_t *restrict cond,pthread_mutex_t *restrict mutex,const struct timespec *restrict abstime);
syntax : int pthread_cond_wait(pthread_cond_t *restrict cond,
pthread_mutex_t *restrict mutex);

*/
