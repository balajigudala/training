#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
int glob = 0,i=0;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
void * mythread_fun1(void *);
void * mythread_fun2(void *);
int main( )
{
	pthread_t ti1,ti2;
	int ret,ret1,loop=100;
	void *res;
	ret=pthread_create(&ti1,0,mythread_fun1,&loop);
	ret1=pthread_create(&ti2,0,mythread_fun2,&loop);
	if(ret<0||ret1<0)
	{
		printf("failed to create the new thread \n ");
		exit(1);
	}
	pthread_join(ti1,&res);
	printf("\n\nthread1 completd ");
	pthread_join(ti2,&res);
	printf("glob : %d \n", glob);
}
void* mythread_fun1(void *ptr)
{
	int local,loop;
	loop = *(int *)ptr;
	for(i;i<loop;i++)
	{
			pthread_mutex_lock(&mtx);
		if(!(i%2))
		{
			printf("thread 1 : %d\n",i);
			pthread_mutex_lock(&mtx);
		}
		else
			pthread_mutex_unlock(&mtx);
//		pthread_mutex_lock(&mtx);
//		local = glob;
//		local++;
//		printf("\n\n\n-");
//		glob = local;
	}

}
void* mythread_fun2(void *ptr)
{
	int local,loop;
	loop = *(int *)ptr;
	for(i;i<loop;i++)
	{
			pthread_mutex_lock(&mtx);
		if((i%2))
		{
			printf("thread 2 : %d\n",i);
			pthread_mutex_lock(&mtx);
		}
		else
			pthread_mutex_unlock(&mtx);
/*	for(i;i<loop&&i%2;i++)
	{
		printf("thread 2 : %d\n",i);
		pthread_mutex_lock(&mtx);
		local = glob;
		local++;
		printf("*   ");
		glob = local;
		pthread_mutex_unlock(&mtx);
*/	}
}
