#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
int glob = 0;
pthread_mutex_t mtx1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mtx2= PTHREAD_MUTEX_INITIALIZER;
void * mythread_fun1(void *);
void * mythread_fun2(void *);
int main()
{
	pthread_t ti1,ti2;
	int i,ret,ret1,loop=100000;
	void *res;
	ret=pthread_create(&ti1,0,mythread_fun1,&loop);
	ret1=pthread_create(&ti2,0,mythread_fun2,&loop);
	if(ret<0||ret1<0)
	{
		printf("failed to create the new thread \n ");
		exit(1);
	}
	pthread_join(ti1,&res);
	printf("\n\nthread1 completd ");
	pthread_join(ti2,&res);
	printf("glob : %d \n", glob);
}
void* mythread_fun1(void *ptr)
{
	int i,local,loop;
	loop = *(int *)ptr;
	for(i=0;i<=loop;i++)
	{
		pthread_mutex_lock(&mtx1);
		local = glob;
		local++;
		printf("\t\t-");
		glob = local;
		pthread_mutex_unlock(&mtx2);
	}
}
void* mythread_fun2(void *ptr)
{
	int i,local,loop;
	loop = *(int *)ptr;
	for(i=0;i<=loop;i++)
	{
		pthread_mutex_lock(&mtx1);
		local = glob;
		local++;	
		printf("\t\t*");
		glob = local;
		pthread_mutex_unlock(&mtx2);
	}
}
