#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
void * mythread(void *);
int main()
{
	pthread_t ti1,ti2;
	int i,ret,ret1,loop=1000;
	ret=pthread_create(&ti1,0,mythread,&loop);
	if(ret<0)
	{
		printf("failed to create the new thread \n ");
		exit(1);
	}
	ti2=pthread_self();
	printf("main : created ret thread ID : %lu \n",ti1);
	printf("main : created ret2 thread ID : %lu \n",ti2);
	for(i=0;i<=500;i++)
	{
		printf("%d ",i);
	}
	pthread_exit(&ret);
	sleep(1);
	printf("main : created thread ID : %d \n",ret);
	exit(2);
}
void* mythread(void *ptr)
{
	int i;
	pthread_t ti1,ti2;
	for(i=0;i<=*(int*)ptr;i++)
	{
		printf("my%d ",i);
		ti2=pthread_self();
		printf("main : created ret thread ID : %lu \n",ti2);
	}
}
/*
main : created ret thread ID : 140694182643456
main : created ret2 thread ID : 140694182647616
main : created ret thread ID : 140694182643456
*/
