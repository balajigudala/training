#include<stdio.h>
int add(int a, int b)
{
	printf("add\n");
	return (a+b);
}
