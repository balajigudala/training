int sub(int a,int b)
{
	return (b-a);
}
