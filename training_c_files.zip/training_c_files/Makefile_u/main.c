#include<stdio.h>
int add(int, int);
int sub(int ,int );
int main()
{
	int var1=10,var2=20,res;
	res=add(var1,var2);
	printf("add : %d \n",res);
	res=sub(var1,var2);
	printf("sub : %d \n",res);
	printf("finish");
}


