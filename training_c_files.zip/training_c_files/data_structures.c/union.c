#include<stdio.h>
union data
{
	int age,*ch;
}u1;
void main()
{
	u1.age=10;
	printf("%d\n",u1.age);
	u1.ch='a';
	printf("%d\n",u1.age);
	printf("%c\n",u1.age);
	printf("%ld\n",sizeof(u1));
}
