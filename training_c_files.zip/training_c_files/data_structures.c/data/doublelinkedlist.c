#include<stdio_ext.h>
#include<stdlib.h>
#pragma pack(1)
struct node
{
	struct node *prev;
	int data;
	struct node *next;
};
void add_at_begn(int );
void del_at_begn();
void display();
void add_at_last(int );
void del_at_last();
void create_list(int*,int);
void del_purticular_node(int);
void add_at_position(int ,int);
void reverse_list();
void delete_duplicates();
void delete_list();
void swap(int ,int);
void add_after_node(int ,int);
void add_before_node(int ,int);
void selection_sort();
struct node *head=NULL;
int main()
{
	int *ptr,n,i,num,dum,opt;
	while(1)
	{
		printf("\n\t>>>>>>>>>>>>>>>   menu   <<<<<<<<<<<<<<\n0 -exit\n1 -add at beggining \n2 -delete at beginning \n3 -add at last\n4 -delete at last\n5 -display\n6 -create list\n7 -delete purticular node \n8 -add node at position\n9 -reverse the list \n10-delete duplicates data nodes \n11-delete the list \n12-swap the selected data \n13-add_after the node \n14-add before the node \n15-selection sort\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case 0:
				printf("\n\tsucesfull termination\n\n");
				exit(0);
			case 1:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_begn(num);
				break;
			case 2:
				del_at_begn();
				break;
			case 3:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_last(num);
				break;
			case 4:
				del_at_last();
				break;
			case 5:
				display();
				break;
			case 6:
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc(1*sizeof(int));
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
				}
				create_list(ptr,n);
				free(ptr);
				break;
			case 7:
				printf("\nenter the data to delete : ");
				__fpurge(stdin);
				scanf("%d",&num);
				del_purticular_node(num);
				break;
			case 8:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the position to add : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				add_at_position(num,dum);
				break;
			case 9:
				reverse_list();
				break;
			case 10:
				delete_duplicates();
				break;
			case 11:
				delete_list();
				break;
			case 12:
				printf("\nenter the data1 : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the data2 : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				swap(num,dum);
				break;
			case 13:
				printf("\nenter the data to search : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				printf("\nenter the data to add after node : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_after_node(dum,num);
				break;
			case 14:
				printf("\nenter the data to search : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				printf("\nenter the data to add before node : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_before_node(dum,num);
				break;
			case 15:
				selection_sort();
				break;

			default:
				printf("\n\tinvalid optiion\n\n");
		}
	}
}
void add_at_begn(int num)
{
	struct node *ptr;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	ptr->next=NULL;
	if(head!=NULL)
	{
		head->prev=ptr;
		ptr->next=head;
	}
	else
                ptr->next=NULL;
	head=ptr;
}

void del_at_begn()
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=head;
	head=head->next;
	free(temp);
}

void display()
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	temp=head;
	printf("\n\nthe data is : ");
	while(temp!=NULL)
	{
		printf("  %d",temp->data);
		temp=temp->next;
	}
	printf("\n\n");
}

void add_at_last(int num)
{
	struct node *ptr,*temp;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->next=NULL;
	ptr->data=num;
	if(head==NULL)
	{
		ptr->prev=NULL;
		head=ptr;
		return;
	}
	temp=head;
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	ptr->prev=temp;
	temp->next=ptr;
}

void del_at_last()
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tlist is empty\n\n");
		return;
	}
	if(head->next==NULL)
	{
		temp=head;
		head=head->next;
		free(temp);
		return;
	}
	temp=head;
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	temp->prev->next=temp->next;
	free(temp);
}

void create_list(int *arr,int n)
{
	struct node *start=NULL,*prev,*ptr,*temp;
	int i;
        for(i=0;i<n;i++)
	{
		ptr=(struct node*)malloc(1*sizeof(struct node));
		ptr->next=NULL;
		ptr->data=arr[i];
		if(start==NULL)
		{
			ptr->prev=start;
			start=ptr;
			prev=ptr;
		}
		else
		{
			prev->next=ptr;
			ptr->prev=prev;
			prev=ptr;
		}
	}
	if(head==NULL)
	{
		head=start;
		return;
	}
	temp=head;
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	temp->next=start;
	start->prev=temp;
}

void del_purticular_node(int num)
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->data==num)
	{
		if(head->next==NULL)
		{
		free(head);
		head=NULL;
		return;
		}
		temp=head;
		head=head->next;
		head->prev=NULL;
		free(temp);
		return;
	}
	temp=head->next;
	while(temp!=NULL)
	{
		if(temp->data==num)
		{
			temp->prev->next=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->prev;
			free(temp);
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found \n\n");
}

void add_at_position(int num,int pos)
{
	int count=0;
	struct node *ptr,*temp;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	if(pos==0)
	{
		ptr->next=head;
		ptr->prev=NULL;
		head=ptr;
		return;
	}
	temp=head;
	count=0;
	while(temp!=NULL)
	{
		count++;
		if(count==pos)
		{
			ptr->next=temp->next;
			ptr->prev=temp;
			temp->next=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe position is not found\n\n");
}

void reverse_list()
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tlist is empty\n\n");
		return;
	}
	if(head->next==NULL)
		return;
	temp=head;
	while(temp!=NULL)
	{
		ptr=temp->prev;
		temp->prev=temp->next;
		temp->next=ptr;
		head=temp;
		temp=temp->prev;
	}
}

void delete_duplicates()
{
	struct node *temp,*ptr,*main1;
	if(head==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	if(head->next==NULL)
		return;
	for(main1=head;main1!=NULL;main1=main1->next)
	{
		for(temp=main1->next;temp!=NULL;temp=temp->next)
		{
			if(main1->data==temp->data)
			{
				temp->prev->next=temp->next;
				if(temp->next!=NULL)
					temp->next->prev=temp->prev;
				ptr=temp->prev;
				free(temp);
				temp=ptr;
			}
		}
	}
}

void delete_list()
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		ptr=temp->next;
		free(temp);
		temp=ptr;
	}
	head=temp;
}

void swap(int num,int dum)
{
	int pos1=0,pos2=0;
	struct node *cur1,*cur2,*temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->next==NULL)
		return;
	if(num==dum)
		return;
	cur1=cur2=head;
	while(cur1!=NULL)
	{
		pos1++;
		if(cur1->data==num)
			break;
		cur1=cur1->next;
	}
	while(cur2!=NULL)
	{
		pos2++;
		if(cur2->data==dum)
			break;
		cur2=cur2->next;
	}
	if((cur1==NULL)||(cur2==NULL))
	{
		printf("\n\tthe data not found\n\n");
		return;
	}
	if(pos1>pos2)
	{
		temp=cur1;
		cur1=cur2;
		cur2=temp;
	}
	if(cur1->next!=cur2)
	{
		cur1->next->prev=cur2;
		cur2->prev->next=cur1;
		if(head==cur1)
			head=cur2;
		else
			cur1->prev->next=cur2;
		if(cur2->next!=NULL)
			cur2->next->prev=cur1;
		temp=cur1->next;
		cur1->next=cur2->next;
		cur2->next=temp;
		temp=cur1->prev;
		cur1->prev=cur2->prev;
		cur2->prev=temp;
	}
	else
	{
		if(head==cur1)
			head=cur2;
		else
			cur1->prev->next=cur2;
		if(cur2->next!=NULL)
			cur2->next->prev=cur1;
		cur1->next=cur2->next;
		cur2->prev=cur1->prev;
		cur2->next=cur1;
		cur1->prev=cur2;
	}
}

void add_after_node(int snum,int num)
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	temp=head;
	while(temp!=NULL)
	{
		if(temp->data==snum)
		{
			if(temp->next!=NULL)
			{
				ptr->next=temp->next;
				ptr->prev=temp;
				temp->next->prev=ptr;
				temp->next=ptr;
				return;
			}
			else
			{
				ptr->next=NULL;
				temp->next=ptr;
				ptr->prev=temp;
				return;
			}
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found\n\n");
}

void add_before_node(int snum,int num)
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=head;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	while(temp!=NULL)
	{
		if(temp->data==snum)
		{
			if(head==temp)
			{
				ptr->prev=NULL;
				ptr->next=temp;
				temp->prev=ptr;
				head=ptr;
				return;
			}
			ptr->next=temp;
			ptr->prev=temp->prev;
			temp->prev->next=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found\n\n");
}

void selection_sort()
{
	struct node *temp,*ptr,*dum;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	for(temp=head;temp!=NULL;temp=temp->next)
	{
		for(ptr=temp->next;ptr!=NULL;ptr=ptr->next)
		{
			if(temp->data>ptr->data)
			{
				if(temp->next!=ptr)
				{
					temp->next->prev=ptr;
					ptr->prev->next=temp;
					if(head==temp)
						head=ptr;
					else
						temp->prev->next=ptr;
					if(ptr->next!=NULL)
						ptr->next->prev=temp;
					dum=temp->next;
					temp->next=ptr->next;
					ptr->next=dum;
					dum=temp->prev;
					temp->prev=ptr->prev;
					ptr->prev=dum;
				}
				else
				{
					if(head==temp)
						head=ptr;
					else
						temp->prev->next=ptr;
					if(ptr->next!=NULL)
						ptr->next->prev=temp;
					temp->next=ptr->next;
					ptr->prev=temp->prev;
					ptr->next=temp;
					temp->prev=ptr;
				}
				dum=temp;
                                temp=ptr;
                                ptr=temp;
			}
		}
	}
}
