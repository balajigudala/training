//     ************ list of operations for double linked circular list *************
#include<stdio_ext.h>
#include<stdlib.h>
#pragma pack(1)
struct node
{
        struct node *prev;
        int data;
        struct node *next;
};
void add_at_begn(int );
void del_at_begn();
void display(struct node *);
void add_at_last(int );
void del_at_last();
struct node* create_list(struct node *,int*,int);
void del_purticular_node(int);
void add_at_position(int ,int);
void reverse_list();
void delete_duplicates();
void delete_list();
void swap(int ,int);
void add_after_node(int ,int);
void add_before_node(int ,int);
struct node * selection_sort(struct node*);
struct node* bubble_sort(struct node *);
void merge_sort();
struct node *head=NULL,*well=NULL,*done=NULL,*res=NULL;

void add_at_begn(int num)
{
        struct node *ptr;
        ptr=(struct node*)malloc(1*sizeof(struct node));
        ptr->data=num;
        if(head==NULL)
        {
                ptr->prev=head=ptr->next=ptr;
		return;
        }
	ptr->next=head;
	ptr->prev=head->prev;
	head->prev->next=ptr;
	head->prev=ptr;
	head=ptr;

}
void display(struct node *head1)
{
        struct node *temp;
        if(head1==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        temp=head1;
        printf("\n\nthe data is : \n");
        while(temp->next!=head1)
        {
                printf("%-15p -- cur :%-15p -- %d -- %-15p\n",temp->prev,temp,temp->data,temp->next);
                temp=temp->next;
        }

                printf("%-15p -- cur :%-15p -- %d -- %-15p\n",temp->prev,temp,temp->data,temp->next);
        printf("\n\n");
}

void del_at_begn()
{
        struct node *temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->next==head)
	{
		free(head);
		head=NULL;
		return;
	}
	head->next->prev=head->prev;
	head->prev->next=head->next;
	temp=head;
	head=head->next;
	free(temp);
}
void add_at_last(int num)
{
	struct node *ptr,*temp;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	if(head==NULL)
	{
		ptr->prev=ptr->next=head=ptr;
		return;
	}

}

void del_purticular_node(int num)
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->data==num)
	{
		if(head->next==head)
		{
			free(head);
			head=NULL;
			return;
		}
		temp=head;
		head->prev->next=head->next;
		head->next->prev=head->prev;
		head=head->next;
		free(temp);
		return;
	}
	temp=head->next;
	while(temp!=head)
	{
		if(temp->data==num)
		{
			temp->prev->next=temp->next;
			if(temp->next!=head)
			{
				temp->next->prev=temp->prev;
			}
			else

				head->prev=temp->prev;
			free(temp);
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found \n\n");
}

void reverse_list()
{
	struct node *temp,*ptr,*new;
	if(head==NULL)
	{
		printf("\n\tlist is empty\n\n");
		return;
	}
	if(head->next==head)
		return;
	temp=head;
	new=head->prev;
	do
	{
		ptr=temp->prev;
		temp->prev=temp->next;
		temp->next=ptr;
		temp=temp->next;
	}
	while(temp!=head);
	head=new;
}

void delete_duplicates()
{
	struct node *temp,*ptr,*main1;
	if(head==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	if(head->next==head)
		return;
	for(main1=head;main1->next!=head;main1=main1->next)
	{
		temp=main1->next;
		do
		{
			if(main1->data==temp->data)
			{
				temp->prev->next=temp->next;
				if(temp->next!=head)
					temp->next->prev=temp->prev;
				ptr=temp->prev;
				free(temp);
				temp=ptr;
			}
			temp=temp->next;
		}
		while(temp!=head);
	}
}

void swap(int x ,int y)
{
	struct node  *p,*q,*temp,*ptr;
	int pos1 =0 ,pos2=0,f1=0,f2=0;
	if(head == NULL)
	{
		printf("list is empty\n");
		return;
	}
	if(x==y)
	{
		printf("numbers are same\n");
		return;
	}
	p=q=head;

	do
	{
		pos1++;
		if(p->data ==x)
		{
			f1=1;
			break;
		}
		p=p->next;
	}while(p!=head);

	do
	{
		pos2++;
		if(q->data ==y)
		{
			f2=1;
			break;
		}
		q=q->next;
	}while(q!=head);

	if((f1!=1)||(f2!=1))
	{
		printf("one of the node is not present\n");
		return;
	}
	if(pos1>pos2)
	{
		temp =p;
		p=q;
		q=temp;
	}
	if(p->next != q)
	{
		temp = p->prev;
		p->prev = q->prev;
		q->prev = temp;

		temp = p->next;
		p->next = q->next;
		q->next = temp;

		q->next->prev = q;
		p->prev->next = p;

		if(q->prev == q)
		{
			q->prev = head;
			head = q;
		}
		else
			q->prev->next = q;
		if(p->next == p)
			p->next = head;
		else
			p->next->prev = p;


	}
	else
	{
		p->next = q->next;
		q->next = p;

		q->prev = p->prev;
		p->prev = q;

		if(p!=head)
			q->prev->next = q;
		else
		{
			ptr = head;
			while(ptr->next != head)
				ptr = ptr->next;
			ptr->next = q;
			head = q;
		}
		p->next->prev = p;
	}
}


struct node * create_list(struct node *head1,int *arr,int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
		if(ptr==NULL)
		{
			printf("\n\tfailed to allocate memmory \n\n");
			exit(1);
		}
		ptr->data=arr[i];
		if(head1==NULL)
		{
			ptr->prev=ptr->next=head1=ptr;
		}
		else
		{
			ptr->next=head1;
			ptr->prev=head1->prev;
			head1->prev->next=ptr;
			head1->prev=ptr;
		}
	}
	return head1;
}


struct node * selection_sort(struct node *head1)
{
	struct node  *p,*q,*temp,*ptr;
	if(head1 == NULL)
	{
		printf("list is empty\n");
		return head1 ;
	}
	if(head1->next==head1)
		return head1;
	for(p=head1;p->next!=head1;p=p->next)
	{
		q=p->next;
		do
		{
			if(p->data>q->data)
			{
				if(p->next != q)
				{
					temp = p->prev;
					p->prev = q->prev;
					q->prev = temp;

					temp = p->next;
					p->next = q->next;
					q->next = temp;

					q->next->prev = q;
					p->prev->next = p;

					if(q->prev == q)
					{
						q->prev = head1;
						head1 = q;
					}
					else
						q->prev->next = q;
					if(p->next == p)
						p->next = head1;
					else
						p->next->prev = p;
				}
				else
				{
					p->next = q->next;
					q->next = p;

					q->prev = p->prev;
					p->prev = q;

					if(p!=head1)
						q->prev->next = q;
					else
					{
						ptr = head1;
						while(ptr->next != head1)
							ptr = ptr->next;
						ptr->next = q;
						head1 = q;
					}
					p->next->prev = p;
				}
				temp=p;
				p=q;
				q=temp;
			}
			q=q->next;
		}
		while(q!=head1);
	}
	return head1;
}




int main()
{
	int *ptr,n,i,num,dum,opt;
	while(1)
	{
		printf("\n\t>>>>>>>>>>>>>>>   menu   <<<<<<<<<<<<<<\n\n-1 -clear\n 0 -exit\n 1 -add at beggining \n 2 -delete at beginning \n 3 -add at last\n 4 -delete at last\n 5 -display\n 6 -create list\n 7 -delete purticular node \n 8 -add node at position\n 9 -reverse the list \n 10-delete duplicates data nodes \n 11-delete the list \n 12-swap the selected data \n 13-add_after the node \n 14-add before the node \n 15-selection sort \n 16-bubble sorting \n 17-merge_sorting\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case -1:
				system("clear");
				break;
			case 0:
				printf("\n\tsucesfull termination\n\n");
				exit(0);
			case 1:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_begn(num);
				break;
			case 2:
				del_at_begn();
				break;
			case 3:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_last(num);
				break;
			case 4:
				//                              del_at_last();
				break;
			case 5:
				display(head);
				break;
			case 7:
				printf("\nenter the data to delete : ");
				__fpurge(stdin);
				scanf("%d",&num);
				del_purticular_node(num);
				break;
			case 9:
				reverse_list();
				break;
			case 10:
				delete_duplicates();
				break;
			case 12:
				printf("\nenter the data1 : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the data2 : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				swap(num,dum);
				break;
			case 6:
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc(n*sizeof(int));
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
				}
				head=create_list(head,ptr,n);
				free(ptr);
				break;
			case 15:
				head=selection_sort(head);
				break;
				/*                      case 8:
							printf("\nenter the data to add : ");
							79,4-32        4%
							__fpurge(stdin);
							scanf("%d",&num);
							printf("\nenter the position to add : ");
							__fpurge(stdin);
							scanf("%d",&dum);
							add_at_position(num,dum);
							break;
							case 11:
							delete_list();
							break;
							case 13:
							printf("\nenter the data to search : ");
							__fpurge(stdin);
							scanf("%d",&dum);
							printf("\nenter the data to add after node : ");
							__fpurge(stdin);
							scanf("%d",&num);
							add_after_node(dum,num);
							break;
							case 14:
							printf("\nenter the data to search : ");
							__fpurge(stdin);
							scanf("%d",&dum);
							printf("\nenter the data to add before node : ");
							__fpurge(stdin);
							scanf("%d",&num);
							add_before_node(dum,num);
							break;
							case 16:
							head=bubble_sort(head);
							break;
							case 17:
							printf("\nenter the no of elements : ");
							__fpurge(stdin);
							scanf("%d",&n);
							ptr=(int*)malloc(1*sizeof(int));
							for(i=0;i<n;i++)
							{
							printf("enter the data : ");
							__fpurge(stdin);
							scanf("%d",&ptr[i]);
							}
							well=create_list(well,ptr,n);
							well=selection_sort(well);
				//display(well);
				free(ptr);
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc(1*sizeof(int));
				for(i=0;i<n;i++)
				{
				printf("enter the data : ");
				__fpurge(stdin);
				scanf("%d",&ptr[i]);
				}
				done=create_list(done,ptr,n);
				done=selection_sort(done);
				//display(done);
				free(ptr);
				merge_sort();
				display(res);
				break;
				*/                        default:
				printf("\n\tinvalid option\n\n");
		}
	}
}

