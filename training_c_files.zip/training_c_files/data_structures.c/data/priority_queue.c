#include<stdio_ext.h>
#include<stdlib.h>
struct prior
{
	struct prior *prev;
	int pre;
	int data;
	struct prior *next;
};


void display();
void display_prior(int);
void insert(int ,int);

struct prior *head=NULL;

void display()
{
	struct prior *temp;
        if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	printf("the  priority    :    data  \n\n");
	while(temp!=NULL)
	{
		printf("%12d     :     %d  \n",temp->pre,temp->data);
		temp=temp->next;
	}
}

void display_prior(int perd)
{
        struct prior *temp;
	int count=0;
        if(head==NULL)
        {
                printf("\n\t The queue is empty \n\n");
                return;
        }
        temp=head;
        printf("\n\n     priority    :    data  \n\n");
        while(temp!=NULL)
        {
		if(perd==temp->pre)
		{
			count++;
			printf("%12d     :     %d  \n",temp->pre,temp->data);
		}
                temp=temp->next;
        }
	if(count==0)
		printf("the data with %d priority value is not found ",perd);
}

void insert(int perd ,int num)
{
	struct prior *temp,*ptr;
	if(perd<=0)
	{
		printf("\n\t the priority value shouldn't be negitive value\n\n");
		return;
	}
	ptr=(struct prior *)malloc(1*sizeof(struct prior));
	if(ptr==NULL)
	{
		printf("\n\tfailed to allocate memory\n\n");
		return;
	}
	ptr->data=num;
	ptr->pre=perd;
	if(head==NULL)
	{
		ptr->prev=NULL;
		ptr->next=NULL;
		head=ptr;
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->pre>perd)
		{
			if(head==temp)
			{
				temp->prev=ptr;
				ptr->next=temp;
				ptr->prev=NULL;
				head=ptr;
				return;
			}
			temp->prev->next=ptr;
			ptr->prev=temp->prev;
			ptr->next=temp;
			temp->prev=ptr;
			return;
		}
		if(temp->next==NULL)
			break;
		temp=temp->next;
	}
	temp->next=ptr;
	ptr->next=NULL;
	ptr->prev=temp;
}

void delete()
{
	struct prior *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		ptr=temp;
		temp=temp->next;
		free(ptr);
	}
	head=temp;
}

void delete_prior(int perd)
{
        struct prior *temp,*ptr;
        if(head==NULL)
        {
                printf("\n\t The queue is empty \n\n");
                return;
        }
        temp=head;
        while(temp!=NULL)
        {
		if(temp->pre==perd)
		{
			if(head==temp)
			{
				ptr=temp;
				if(temp->next!=NULL)
					temp->next->prev=NULL;
				head=temp=temp->next;
			}
			else
			{
				ptr=temp;
				temp->prev->next=temp->next;
				if(temp->next!=NULL)
					temp->next->prev=temp->prev;
				temp=temp->prev;
			}
			free(ptr);
		}
		else
			temp=temp->next;
	}
}

struct prior * create_list(struct prior *head1,int *arr,int n)
{     
	struct prior *temp,*iptr;
	int i;
	for(i=0;i<n;i=i+2)
	{
		if(arr[i]<=0)
		{
			printf("\n\t the priority value shouldn't be negitive and zero values\n\n");
			continue;
		}
		iptr=(struct prior *)malloc(1*sizeof(struct prior));
		if(iptr==NULL)
		{
			printf("failed to allocate memory");
			exit(-1);
		}
		iptr->data=arr[i+2];
		iptr->pre=arr[i];
		if(head1==NULL)
		{
			iptr->prev=NULL;
			iptr->next=NULL;
			head1=iptr;
			continue;
		}
		temp=head1;
		while(temp!=NULL)
		{
			if(temp->pre>arr[i])
			{
				if(head1==temp)
				{
					temp->prev=iptr;
					iptr->next=temp;
					iptr->prev=NULL;
					head1=iptr;
					break;
				}
				temp->prev->next=iptr;
				iptr->prev=temp->prev;
				iptr->next=temp;
				temp->prev=iptr;
				break;
			}
			if(temp->next==NULL)
				break;
			temp=temp->next;
		}
		temp->next=iptr;
		iptr->next=NULL;
		iptr->prev=temp;
	}
	return head1;
}


int main()
{
	int *ptr,i,n,num,dum,opt;
	char sub;
	while(1)
	{
		printf("\n\t>>>>>>>>>>>>   menu - priority queue  <<<<<<<<<<<<\n\n-1 - clear \n 0 - exit \n 1 - insert \n 2 - display \n 3 - delete");
		printf("\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case -1:
				system("clear");
				break;
			case 0:
				printf("\n\t succesfull termination \n\n");
				exit(0);
			case 1:
				printf("\nenter the priority value : ");
				scanf("%d",&num);
				printf("\nenter the data to insert : ");
				scanf("%d",&dum);
				insert(num,dum);
				break;
			case 2:
				//while(1)
				{	
					printf("\n\n a-display the selected priority data values \n b-display the all data in Queue  \n\nselect the sub options : ");
					__fpurge(stdin);
					scanf("%c",&sub);
					switch(sub)
					{
						case 'z':
							break;
						case 'a':
							printf("\nenter the priority value to display : ");
							scanf("%d",&num);
							display_prior(num);
							break;
						case 'b':
							display();
							break;
						default:
							printf("\n\tenter the valid sub Option\n\n");
					}
				}
				break;
			case 3:
				{
					printf("\n\n a-delete the selected priority data values \n b-delete  all the data in Queue  \n\nselect the sub options : ");
					__fpurge(stdin);
					scanf("%c",&sub);
					switch(sub)
					{
						case 'z':
							break;
						case 'a':
							printf("\nenter the priority value to delete : ");
							scanf("%d",&num);
							delete_prior(num);
							break;
						case 'b':
							delete();
							break;
						default:
							printf("\n\tenter the valid sub Option\n\n");
					}
				}
				break;
			case 4:
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc((n=2*n)*sizeof(int));
				for(i=0;i<n;i=i+2)
				{
					printf("enter the priority value : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i+1]);
				}
				head=create_list(head,ptr,n);
				free(ptr);
				break;

			default:
				printf("\n\tenter the valid Option\n\n");
		}
	}
}
