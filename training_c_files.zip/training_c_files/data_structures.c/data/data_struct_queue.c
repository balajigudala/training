#include<stdio_ext.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *link;
}__attribute__((packed));
void create_list(int*,int);
void display();
void insert(int);
void delete();
void delete_queue();
void delete_purticular_node(int);
void delete_duplicates();
struct node *front=NULL,*rear=NULL;
int main()
{
	int num,dum,size,opt,*ptr,i;
	while(1)
	{
		printf("\n\t>>>>>>>  menu  <<<<<<<\n\n0 -exit \n1 -create list \n2 -insert \n3 -delete\n4 -display\n5 -delete queue \n6 -search queue \n7 -delete purticular node \n8 -delete duplicates\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case 0:
				printf("\n\tsuccesfull termination\n\n");
				exit(0);
			case 1:
				printf("\n\nenter the no of nodes : ");
				scanf("%d",&size);
				ptr=(int *)malloc(size*sizeof(int));
				if(ptr==NULL)
				{
					printf("\n\tfailed to allocate memory \n\n");
					break;
				}
				for(i=0;i<size;i++)
				{
					printf("enter the data : ");
					scanf("%d",&ptr[i]);
				}
				create_list(ptr,size);
				break;
			case 2:
				printf("\n\nenter the data to insert : ");
				scanf("%d",&num);
				insert(num);
				break;
			case 3:
				delete();
				break;
			case 4:
				printf("\n\nthe data in queue is : ");
				display();
				printf("\n\n");
				break;
			case 5:
			       delete_queue();
			       break;
			case 7:
			       printf("\n\nenter the data to delete : ");
			       scanf("%d",&num);
			       delete_purticular_node(num);
			       break;
			case 8:
			       delete_duplicates();
			       break;
			default:
				printf("\n\tinvalid option\n\n");
		}
	}
}

void create_list(int *iptr,int size)
{
	int i;
	struct node *ptr;
	for(i=0;i<size;i++)
	{
		ptr=(struct node*)malloc(1*sizeof(struct node));
		ptr->data=iptr[i];
		ptr->link=NULL;
		if(front==NULL)
		{
			front=rear=ptr;
		}
		else
		{
			rear->link=ptr;
			rear=ptr;
		//	prev=ptr;
		}
	}
}

void display()
{
	struct node *temp;
	if(front==NULL)
	{
		printf("The Queue is empty\n\n");
		return;
	}
	temp=front;
	while(temp!=NULL)
	{
		printf(" %d",temp->data);
		temp=temp->link;
	}
}

void insert(int num)
{
	struct node *ptr;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	ptr->link=NULL;
	if(front==NULL)
	{
		front=rear=ptr;
	}
	else
	{
		rear->link=ptr;
		rear=ptr;
	}
}

void delete()
{
	struct node *temp;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	if(front==rear)
	{
		free(front);
		rear=front=NULL;
		return;
	}
	temp=front->link;
	free(front);
	front=temp;
}

void delete_queue()
{
	struct node *temp,*ptr;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	temp=front;
	while(temp!=NULL)
	{
		if(temp==rear)
		{
			front=rear=NULL;
			free(temp);
			return;
		}
		ptr=temp;
		temp=temp->link;
		free(ptr);
	}
}

void delete_purticular_node(int num)
{
	struct node *temp,*prev;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	if(front==rear)
	{
		if(front->data==num)
		{
			free(front);
			front=rear=NULL;
			return;
		}
		printf("\n\tthe element not found\n\n");
	}
	else
	{
		temp=front;
		while(temp!=NULL)
		{
			if(temp->data==num)
			{
				if(temp==rear)
				{
					rear=prev;
					prev->link=NULL;
					free(temp);
					return;
				}
				if(front->data==num)
				{
					temp=front->link;
					free(front);
					front=temp;
					return;
				}
				prev->link=temp->link;
				free(temp);
				return;
			}
			prev=temp;
			temp=temp->link;
		}
		printf("\n\telement not found\n\t");
	}
}

void delete_duplicates()
{
	struct node *main,*cur,*prev,*temp;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	if(rear==front)
		return;
	for(main=front;main!=NULL;main=main->link)
	{
		for(prev=main,cur=main->link;cur!=NULL;prev=cur,cur=cur->link)
		{
			if(main->data==cur->data)
			{
				if(cur==rear)
				{
					prev->link=cur->link;
					free(cur);
					rear=prev;
					break;
				}
				else
				{
					prev->link=cur->link;
					free(cur);
					cur=prev;
				}
			}
		}
	}
}
