#include<stdio_ext.h>
#include<stdlib.h>
#pragma pack(1)
struct node
{
        struct node *prev;
        int data;
        struct node *next;
};
struct node *front=NULL,*rear=NULL,*rear1=NULL,*well=NULL,*wrear=NULL,*done=NULL,*drear=NULL,*res=NULL,*rrear=NULL;
void pop();
void display(struct node *);
void insert(int );
struct node* create_queue(struct node *,struct node *,int*,int);
void del_purticular_node(int);
void add_at_position(int ,int);
void reverse_queue();
void delete_duplicates();
void delete_queue();
void swap(int ,int);
struct node * selection_sort(struct node*,struct node *);
struct node* bubble_sort(struct node *,struct node *);
void merge_sort();

void pop()
{
        struct node *temp;
        if(front==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        temp=front;
        if(temp->next==NULL)
	{
		free(front);
                rear=front=NULL;
		return;
	}
	temp=front;
        front=front->next;
	front->prev=NULL;
        free(temp);
}

void display(struct node *head1)
{
        struct node *temp;
        if(head1==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        temp=head1;
        printf("\n\nthe data is : ");
        while(temp!=NULL)
        {
                printf("  %d",temp->data);
                temp=temp->next;
        }
        printf("\n\n");
}

void insert(int num)
{
        struct node *ptr,*temp;
        ptr=(struct node*)malloc(1*sizeof(struct node));
        ptr->next=NULL;
        ptr->data=num;
        if(front==NULL)
        {
                ptr->prev=NULL;
                front=rear=ptr;
                return;
        }
        rear->next=ptr;
	ptr->prev=rear;
        rear=ptr;
}

void delete_queue()
{
        struct node *temp,*ptr;
        if(front==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        temp=front;
        while(temp!=NULL)
        {
                ptr=temp->next;
                free(temp);
                temp=ptr;
        }
        front=rear=temp;
}


//*************************          create the list         *****************************
struct node * create_queue(struct node *head1,struct node *rearfun,int *arr,int n)
{
        struct node *ptr;
        int i;
        for(i=0;i<n;i++)
        {
                ptr=(struct node*)malloc(1*sizeof(struct node));
                ptr->next=NULL;
                ptr->data=arr[i];
                if(head1==NULL)
                {
                        ptr->prev=NULL;
                        head1=rearfun=ptr;
			rear1=rearfun;
                }
                else
                {
                        rearfun->next=ptr;
                        ptr->prev=rearfun;
			rearfun=ptr;
                }
        }
	rear1=rearfun;
        return head1;
}

void del_purticular_node(int num)
{
        struct node *temp;
        if(front==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        if(front->data==num)
        {
                if(front->next==NULL)
                {
                free(front);
                front=rear=NULL;
                return;
                }
                temp=front;
                front=front->next;
                front->prev=NULL;
                free(temp);
                return;
        }
        temp=front->next;
        while(temp!=NULL)
        {
                if(temp->data==num)
                {
			if(temp->next==NULL)
				rear=temp->prev;
                        temp->prev->next=temp->next;
                        if(temp->next!=NULL)
                                temp->next->prev=temp->prev;
                        free(temp);
                        return;
                }
                temp=temp->next;
        }
        printf("\n\tthe data not found \n\n");
}

void reverse_queue()
{
        struct node *temp,*ptr;
        if(front==NULL)
        {
                printf("\n\tlist is empty\n\n");
                return;
        }
        if(front->next==NULL)
                return;
        rear=temp=front;
        while(temp!=NULL)
        {
		front=temp;
                ptr=temp->prev;
                temp->prev=temp->next;
                temp->next=ptr;
                temp=temp->prev;
        }
}

//************************      delete the duplicate nodes    *************************
void delete_duplicates()
{
        struct node *temp,*ptr,*main1;
        if(front==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        if(front->next==NULL)
                return;
        for(main1=front;main1!=NULL;main1=main1->next)
        {
                for(temp=main1->next;temp!=NULL;temp=temp->next)
                {
                        if(main1->data==temp->data)
                        {
				if(temp->next==NULL)
					rear=temp->prev;
                                temp->prev->next=temp->next;
                                if(temp->next!=NULL)
                                        temp->next->prev=temp->prev;
                                ptr=temp->prev;
                                free(temp);
                                temp=ptr;
                        }
                }
        }
}

// *******************************  swap the node by link  **************************
void swap(int num,int dum)
{
        int pos1=0,pos2=0;
        struct node *cur1,*cur2,*temp,*ptr;
        if(front==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        if(front->next==NULL)
                return;
        if(num==dum)
                return;
        cur1=cur2=front;
        while(cur1!=NULL)
        {
                pos1++;
                if(cur1->data==num)
                        break;
                cur1=cur1->next;
        }
        while(cur2!=NULL)
        {
                pos2++;
                if(cur2->data==dum)
                        break;
                cur2=cur2->next;
        }
        if((cur1==NULL)||(cur2==NULL))
        {
                printf("\n\tthe data not found\n\n");
                return;
        }
        if(pos1>pos2)
        {
                temp=cur1;
                cur1=cur2;
                cur2=temp;
        }
        if(cur1->next!=cur2)
        {
		if(cur2->next==NULL)
			rear=cur1;
                cur1->next->prev=cur2;
                cur2->prev->next=cur1;
                if(front==cur1)
                        front=cur2;
                else
                        cur1->prev->next=cur2;
                if(cur2->next!=NULL)
                        cur2->next->prev=cur1;
                temp=cur1->next;
                cur1->next=cur2->next;
                cur2->next=temp;
                temp=cur1->prev;
                cur1->prev=cur2->prev;
                cur2->prev=temp;
        }
        else
        {
		if(cur2->next==NULL)
			rear=cur1;
                if(front==cur1)
                        front=cur2;
                else
                        cur1->prev->next=cur2;
                if(cur2->next!=NULL)
                        cur2->next->prev=cur1;
                cur1->next=cur2->next;
                cur2->prev=cur1->prev;
                cur2->next=cur1;
                cur1->prev=cur2;
        }
}

struct node * selection_sort(struct node *head1,struct node *rearfun)
{
        struct node *temp,*ptr,*dum;
        if(head1==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return head1;
        }
        for(temp=head1;temp!=NULL;temp=temp->next)
        {
                for(ptr=temp->next;ptr!=NULL;ptr=ptr->next)
                {
                        if(temp->data>ptr->data)
                        {
                                if(temp->next!=ptr)
                                {
					if(ptr==rearfun)
						rearfun=temp;
                                        temp->next->prev=ptr;
                                        ptr->prev->next=temp;
                                        if(head1==temp)
                                                head1=ptr;
                                        else
                                                temp->prev->next=ptr;
                                        if(ptr->next!=NULL)
                                                ptr->next->prev=temp;
                                        dum=temp->next;
                                        temp->next=ptr->next;
                                        ptr->next=dum;
                                        dum=temp->prev;
                                        temp->prev=ptr->prev;
                                        ptr->prev=dum;
                                }
                                else
                                {
					if(ptr==rearfun)
						rearfun=temp;
                                        if(head1==temp)
                                                head1=ptr;
                                        else
                                                temp->prev->next=ptr;
                                        if(ptr->next!=NULL)
                                                ptr->next->prev=temp;
                                        temp->next=ptr->next;
                                        ptr->prev=temp->prev;
                                        ptr->next=temp;
                                        temp->prev=ptr;
                                }
                                dum=temp;
                                temp=ptr;
                                ptr=temp;
                        }
                }
        }
	rear1=rearfun;
        return head1;
}

struct node* bubble_sort(struct node *head1,struct node *rearfun)
{
        struct node *temp,*dum,*nxt,*dum1;
        if(head1==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return head1;
        }
        for(dum=NULL;head1->next!=dum;dum=nxt)
        {
                for(temp=head1;temp->next!=dum;temp=temp->next)
                {
                        nxt=temp->next;
                        if(temp->data>nxt->data)
                        {
				if(nxt->next==NULL)
					rearfun=temp;
                                if(nxt->next!=NULL)
                                        nxt->next->prev=temp;
                                nxt->prev=temp->prev;
                                temp->next=nxt->next;
                                nxt->next=temp;
                                temp->prev=nxt;
                                if(head1==temp)
                                        head1=nxt;
                                else
                                        nxt->prev->next=nxt;
                                dum1=temp;
                                temp=nxt;
                                nxt=dum1;
                        }
                }
        }
        return head1;
}

//*******************************    merge sorting   ***************************************
void merge_sort()
{
        struct node *temp1,*temp2,*dum,*dumprev;
	res=NULL;
        if((well==NULL)&&(done==NULL))
        {
                printf("\n\tthe both lists are empty \n\n");
                return;
        }
        for(temp1=well,temp2=done,res=NULL;((temp1!=NULL)&&(temp2!=NULL));)
        {
                dum=(struct node*)malloc(1*sizeof(struct node));
                dum->next=NULL;
                if(temp1->data==temp2->data)
                {
                        if(res==NULL)
                        {
                                dum->prev=NULL;
                                dum->data=temp1->data;
                                res=dum;
                                dumprev=dum;
                        }
                        else
                        {
                                dum->data=temp1->data;
                                dum->prev=dumprev;
                                dum->prev->next=dum;
                                dumprev=dum;
                        }
                        temp1=temp1->next;
                        temp2=temp2->next;
                }
                else if(temp1->data>temp2->data)
                {
                        if(res==NULL)
                        {
                                dum->prev=NULL;
                                dum->data=temp2->data;
                                res=dum;
                                dumprev=dum;
                        }
                        else
                        {
                                dum->data=temp2->data;
                                dum->prev=dumprev;
                                dum->prev->next=dum;
                                dumprev=dum;
                        }
                        temp2=temp2->next;
                }
                else
                {
                        if(res==NULL)
                        {
                                dum->prev=NULL;
                                dum->data=temp1->data;
                                res=dum;
                                dumprev=dum;
                        }
                        else
                        {
                                dum->data=temp1->data;
                                dum->prev=dumprev;
                                dum->prev->next=dum;
                                dumprev=dum;
                        }
                        temp1=temp1->next;
                }
        }
       for(temp1;temp1!=NULL;temp1=temp1->next)
        {
                dum=(struct node*)malloc(1*sizeof(struct node));
                dum->next=NULL;
                if(res==NULL)
                {
                        dum->prev=NULL;
                        dum->data=temp1->data;
                        res=dum;
                        dumprev=dum;
                }
                else
                {
                        dum->prev=dumprev;
                        dum->prev->next=dum;
                        dum->data=temp1->data;
                        dumprev=dum;
                }
        }
        for(temp2;temp2!=NULL;temp2=temp2->next)
        {
                dum=(struct node*)malloc(1*sizeof(struct node));
                dum->next=NULL;
                if(res==NULL)
                {
                        dum->prev=NULL;
                        dum->data=temp2->data;
                        res=dum;
                        dumprev=dum;
                }
                else
                {
                        dum->prev=dumprev;
                        dum->prev->next=dum;
                        dum->data=temp2->data;
                        dumprev=dum;
                }
        }
}

int main()
{
        int *ptr,n,i,num,dum,opt;
        while(1)
        {
                printf("\n\t>>>>>>>>>>>>>>>   menu   <<<<<<<<<<<<<<\n\n-1 -clear\n 0 -exit\n 1 -pop \n 2 -insert\n 3 -display\n 4 -create queue\n 5 -delete purticular node \n 6 -reverse the queue \n 7 -delete duplicates data nodes \n 8 -delete the queue \n 9 -swap the selected data \n 10-selection sort \n 11-bubble sorting \n 12-merge_sorting\n\nselect the option : ");
                __fpurge(stdin);
                scanf("%d",&opt);
                switch(opt)
                {
                        case -1:
                                system("clear");
                                break;
                        case 0:
                                printf("\n\tsucesfull termination\n\n");
                                exit(0);
                        case 1:
                                pop();
                                break;
			case 2: 
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				insert(num);
				break;
			case 3:
				display(front);
				break;
			case 4:
                                printf("\nenter the no of nodes : ");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int*)malloc(n*sizeof(int));
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                front=create_queue(front,rear,ptr,n);
				rear=rear1;
				rear1=NULL;
                                free(ptr);
                                break;
			case 5:
                                printf("\nenter the data to delete : ");
                                __fpurge(stdin);
                                scanf("%d",&num);
                                del_purticular_node(num);
                                break;
			case 6:
				reverse_queue();
				break;
			case 7:
				delete_duplicates();
				break;
			case 8:
				delete_queue();
				break;
			case 9:
                                printf("\nenter the data1 for swap : ");
                                __fpurge(stdin);
                                scanf("%d",&num);
                                printf("\nenter the data2 for swap : ");
                                __fpurge(stdin);
                                scanf("%d",&dum);
                                swap(num,dum);
                                break;
			case 10:
				front=selection_sort(front,rear);
				rear=rear1;
				rear1=NULL;
				break;
			case 11:
				front=bubble_sort(front,rear);
				rear=rear1;
				rear1=NULL;
				break;
			case 12:
                                printf("\nenter the no of nodes : ");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int*)malloc(n*sizeof(int));
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                well=create_queue(well,wrear,ptr,n);
				wrear=rear1;
				rear1=NULL;
                                well=selection_sort(well,wrear);
				wrear=rear1;
				rear1=NULL;
                                display(well);
                                free(ptr);
                                printf("\nenter the no of elements : ");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int*)malloc(n*sizeof(int));
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                done=create_queue(done,drear,ptr,n);
				drear=rear1;
				rear1=NULL;
                                done=selection_sort(done,drear);
				drear=rear1;
				rear1=NULL;
                                display(done);
                                free(ptr);
                                merge_sort();
                                display(res);
				well=done=drear=wrear=NULL;
                                break;
			default:
				printf("\n\tEnter the valid optiom \n\n");
		}
	}
}

