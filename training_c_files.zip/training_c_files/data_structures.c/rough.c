#include<stdio.h>
const int y=10;
int main()
{
	unsigned char x;
	scanf("%d",&x);
	printf("result : %d \n",x);
}
