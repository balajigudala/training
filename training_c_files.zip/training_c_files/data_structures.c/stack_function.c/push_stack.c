//          *****************  adding nodes at beginning or pop  ****************
#include"stack_header.h"
extern struct node *head;
void push_stack(int num)
{
        struct node *ptr;
        ptr=(struct node *)calloc(1,sizeof(struct node));
        if(ptr==NULL)
        {
                printf("\n\tfailed to alloc the memory in heap\n\n");
                exit(-1);
        }
        if(ptr==NULL)
        {
                printf("\n\tfailed to allocate \n\n");
                exit(1);
        }
        ptr->data=num;
        ptr->link=head;
        head=ptr;
}

