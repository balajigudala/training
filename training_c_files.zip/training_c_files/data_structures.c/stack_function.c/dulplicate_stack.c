#include"stack_header.h"
extern struct node *head;
void delete_duplicate_nodes()
{
        struct node *main1,*cur,*prev;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        for(main1=head;main1!=NULL;main1=main1->link)
        {
                for(cur=main1->link,prev=main1;cur!=NULL;prev=cur,cur=cur->link)
                {
                        if(main1->data==cur->data)
                        {
                                prev->link=cur->link;
                                free(cur);
                                cur=prev;
                        }
                }
        }
}

