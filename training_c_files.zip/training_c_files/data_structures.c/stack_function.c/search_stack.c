#include"stack_header.h"
extern struct node *head;
int search_data(int num)
{
        struct node *ptr;
        int cnt=0;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return -1;
        }
        ptr=head;
        while(ptr!=NULL)
        {
                cnt++;
                if((ptr->data)==num)
                        return cnt;
                ptr=ptr->link;
        }
        return 0;
}

