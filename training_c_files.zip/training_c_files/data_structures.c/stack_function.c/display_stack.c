//         ****************   display the elements  ********************
#include"stack_header.h"
extern struct node *head;
void display()
{
        struct node *ptr;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        ptr=head;
        printf("\nThe data : ");
        while(ptr!=NULL)
        {
                printf("%d  ",ptr->data);
                ptr=ptr->link;
        }
        printf("\n\n");
}

