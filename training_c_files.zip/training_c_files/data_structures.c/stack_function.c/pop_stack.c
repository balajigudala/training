//         *****************  delete nodes at beginning or pop  ****************
#include"stack_header.h"
extern struct node *head;
void pop_stack()
{
        struct node *ptr;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        ptr=head;
        head=head->link;
        free(ptr);
}
