#include"stack_header.h"
#include<stdio.h>
struct node *head = NULL;
int main()
{
        int opt,dum,num,n,nodes,i,snum;
        int *ptr;
        while(1)
        {
                printf("\n\t*****  stack menu  *****\n0 -exit \n1 -creating the stack list \n2 -push \n3 -pop \n4 -displaying the data in nodes \n5 -count the nodes \n6 -search the data \n7 -delete the stack \n8 -add the node after selected node\n9 -add the node before selected node \n10-delete purticular node \n11-reverse the stack \n12-swaping the seleted nodes \n13-delete duplicate nodes\n\nselect the option : ");
                __fpurge(stdin);
                scanf("%d",&opt);
                switch(opt)
                {
                        case 0:
                                printf("\n\tthe sucessfull termination of program\n\n");
                                exit(0);
                        case 1:
                                printf("enter the no of nodes :");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int *)malloc(n*sizeof(int));
                                if(ptr==NULL)
                                {
                                        printf("\n\tfailed to allocate memory\n\n");
                                        exit(0);
                                }
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        scanf("%d",&ptr[i]);
                                }
                                create_stack(ptr,n);
                                free(ptr);
                                break;

                        case 2:
                                printf("\n\nenter the data :");
                                __fpurge(stdin);
                                scanf("%d",&num);
                                push_stack(num);
                                break;
                        case 3:
                                pop_stack();
                                break;
                        case 4:
                                display();
                                break;
                        case 5:
                                dum=cnt_nodes();
                                if(dum>0)
                                        printf("\n\nthe nodes present is/are :%d\n\n",dum);
                                break;
                        case 6:
                                printf("\n\nenter the data to search :");
                                __fpurge(stdin);
                                scanf("%d",&num);
                                dum=search_data(num);
                                if(dum>0)
                                        printf("\n\nthe %d is present in the %d node \n\n",num,dum);
                                else if(dum==0)
                                        printf("\n\nthe given no %d is not found\n\n",num);
                                break;
                        case 7:
                                delete_stack();
                                break;
                        case 8:
                                printf("\n\nenter the data to data to be search and to be add : ");
                                __fpurge(stdin);
                                scanf("%d%d",&snum,&num);
                                add_after_node(snum,num);
                                break;
                        case 9:
                                printf("\n\nenter the data to data to be search and to be add : ");
                                __fpurge(stdin);
                                scanf("%d%d",&snum,&num);
				add_before_node(snum,num);
                                break;
                        case 10:
                                printf("\n\nenter the data :");
                                __fpurge(stdin);
                                scanf("%d",&num);
                                delete_node(num);
                                break;
                        case 11:
                                reverse_stack();
                                break;
                        case 12:
                                printf("enter the data that to be swap :");
                                __fpurge(stdin);
                                scanf("%d%d",&num,&dum);
                                swap_nodes(num,dum);
                                break;
                        case 13:
                                delete_duplicate_nodes();
                                break;
                        default:
                                printf("\n\tEnter the valid option\n\n");
		}
	}
}
