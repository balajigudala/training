#include<stdio_ext.h>
#include<stdlib.h>
struct node
{
        int data;
        struct node *link;
};
void create_stack(int *,int);
void push_stack(int );
void pop_stack();
void display();
int cnt_nodes();
int search_data(int);
void delete_stack();
void del_at_last();
void add_at_last(int);
void add_after_node(int, int);
void add_before_node(int, int);
void delete_node(int);
void reverse_stack();
void swap_nodes(int, int);
void delete_duplicate_nodes();

