#include"stack_header.h"
extern struct node *head;
void create_stack(int *iptr,int n)
{
        int i;
        for(i=0;i<n;i++)
        {
                struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
                if(ptr==NULL)
                {
                        printf("\n\tfailed to allocate memory\n\n");
                        exit(-1);
                }
                ptr->link=head;
                ptr->data=iptr[i];
                head=ptr;
        }
}

