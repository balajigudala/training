#include<stdio.h>
#include<stdlib.h>
#include "stack_header.h"
extern struct node *head;
void add_after_node(int snum,int num)
{
        struct node *ptr,*temp;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        temp=head;
        while(temp!=NULL)
        {
                if(temp->data==snum)
                {
                        ptr=(struct node*)malloc(1*sizeof(struct node));
                        if(ptr==NULL)
                        {
                                printf("\n\tfailed to alloc the memory in heap\n\n");
                                exit(-1);
                        }
                        ptr->data=num;
                        ptr->link=temp->link;
                        temp->link=ptr;
                        return;
                }
                temp=temp->link;
        }
        printf("\n\tthe element not found in list \n\n");
        return;
}

