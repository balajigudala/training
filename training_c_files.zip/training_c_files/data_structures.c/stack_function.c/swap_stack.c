#include"stack_header.h"
extern struct node *head;
void swap_nodes(int num,int val)
{
        struct node *c1,*p1,*c2,*p2,*temp;
        int pos1,pos2;
        pos1=pos2=0;
        if(num==val)
                return;
        if(head==NULL)
        {
                printf("\n\tthe lsit is empty\n\n");
                return;
        }
        c1=c2=head;
        while(c1!=NULL)
        {
                pos1++;
                if(c1->data==num)
                        break;
                p1=c1;
                c1=c1->link;
        }
        while(c2!=NULL)
        {
                pos2++;
                if(c2->data==val)
                        break;
                p2=c2;
                c2=c2->link;
        }
        if((c1==NULL)||(c2==NULL))
        {
                printf("\n\tdata not found \n\n");
                return;
        }
        if(pos1>pos2)
        {
                temp=c1;
                c1=c2;
                c2=temp;
                temp=p1;
                p1=p2;
                p2=temp;
        }
        if(c1->link!=c2)
        {
                temp=c1->link;
                c1->link=c2->link;
                c2->link=temp;
                p2->link=c1;
                if(head!=c1)
                {
                        p1->link=c2;
                }
                else
                        head=c2;
                return;
        }
        else
        {
                temp=c2->link;
                c2->link=c1;
                c1->link=temp;
                if(head!=c1)
                {
                        p1->link=c2;
                }
                else
                {
                        head=c2;
                }
                return;
        }
}

