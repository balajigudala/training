#include<stdio.h>
#include<stdlib.h>
#include "stack_header.h"
extern struct node *head;
int cnt_nodes()
{
        struct node *ptr;
        int cnt=0;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return 0;
        }
        ptr=head;
        while(ptr!=NULL)
        {
                cnt++;
                ptr=ptr->link;
        }
        return cnt;
}
