#include"stack_header.h"
extern struct node *head;
void delete_stack()
{
        struct node *ptr;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return ;
        }
        while(head!=NULL)
        {
                ptr=head;
                head=ptr->link;
                free(ptr);
        }
        printf("\n\tthe list is deleted\n\n");
}

