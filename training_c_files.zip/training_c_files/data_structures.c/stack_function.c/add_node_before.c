#include<stdio.h>
#include<stdlib.h>
#include"stack_header.h"
extern struct node *head;
void add_before_node(int snum, int num)
{
        struct node *prev,*cur;
        if(head==NULL)
        {
                printf("\n\tThe list is empty\n\n");
                return;
        }
        if(head->data==snum)
        {
                struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
                if(ptr==NULL)
                {
                        printf("\n\tfailed to alloc the memory in heap\n\n");
                        exit(-1);
                }
                ptr->data=num;
                ptr->link=head;
                head=ptr;
                return;
        }
        prev=head;
        cur=head->link;
        while(cur!=NULL)
        {
                if(cur->data==snum)
                {
                        struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
                        if(ptr==NULL)
                        {
                                printf("\n\tfailed to alloc the memory in heap\n\n");
                                exit(-1);
                        }
                        ptr->data=num;
                        ptr->link=cur;
                        prev->link=ptr;
                        return;
                }
                prev=cur;
                cur=cur->link;
        }
        printf("\n\tthe element not found \n\n");
}

