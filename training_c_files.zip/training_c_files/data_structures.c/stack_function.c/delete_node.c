#include"stack_header.h"
extern struct node *head;
void delete_node(int num)
{
        struct node *cur,*prev;
        if(head==NULL)
        {
                printf("\n\tThere is no nodes to add \n\n");
                return;
        }
        if(head->data==num)
        {
                if(head->link==NULL)
                {
                        free(head);
                        head=NULL;
                        return;
                }
                cur=head;
                head=head->link;
                free(cur);
                //printf("\n\tthe element not found\n\n");
                return;
        }
        prev=head;
        cur=head->link;
        while(cur!=NULL)
        {
                if(cur->data==num)
                {
                        prev->link=cur->link;
                        free(cur);
                        return;
                }
                prev=cur;
                cur=cur->link;
        }
        printf("\n\tthe element not found\n\n");
        return;
}

