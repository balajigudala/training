#include "stack_header.h"
extern struct node *head;
void reverse_stack()
{
        struct node *prev,*cur,*next;
        if(head==NULL)
        {
                printf("\n\tThe list is empty \n\n");
                return;
        }
        prev=NULL;
        cur=head;
        while(cur!=NULL)
        {
                next=cur->link;
                cur->link=prev;
                prev=cur;
                cur=next;
        }
        head=prev;
}

