//     ************ list of operations for double linked list *************
#include<stdio_ext.h>
#include<stdlib.h>
#pragma pack(1)
struct node
{
	struct node *prev;
	int data;
	struct node *next;
};
void add_at_begn(int );
void del_at_begn();
void display(struct node *);
void add_at_last(int );
void del_at_last();
struct node* create_list(struct node *,int*,int);
void del_purticular_node(int);
void add_at_position(int ,int);
void reverse_list();
void delete_duplicates();
void delete_list();
void swap(int ,int);
void add_after_node(int ,int);
void add_before_node(int ,int);
struct node * selection_sort(struct node*);
struct node* bubble_sort(struct node *);
void merge_sort();
struct node *head=NULL,*well=NULL,*done=NULL,*res=NULL;
//***********************************          main            *****************************
int main()
{
	int *ptr,n,i,num,dum,opt;
	while(1)
	{
		printf("\n\t>>>>>>>>>>>>>>>   menu   <<<<<<<<<<<<<<\n\n-1 -clear\n 0 -exit\n 1 -add at beggining \n 2 -delete at beginning \n 3 -add at last\n 4 -delete at last\n 5 -display\n 6 -create list\n 7 -delete purticular node \n 8 -add node at position\n 9 -reverse the list \n 10-delete duplicates data nodes \n 11-delete the list \n 12-swap the selected data \n 13-add_after the node \n 14-add before the node \n 15-selection sort \n 16-bubble sorting \n 17-merge_sorting\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case -1:
				system("vi /home/engineer/practice_files/data_structures.c/double_linked_list_operations.c");
				break;
			case 0:
				printf("\n\tsucesfull termination\n\n");
				exit(0);
			case 1:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_begn(num);
				break;
			case 2:
				del_at_begn();
				break;
			case 3:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_last(num);
				break;
			case 4:
				del_at_last();
				break;
			case 5:
				display(head);
				break;
			case 6:
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc(n*sizeof(int));
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
				}
				head=create_list(head,ptr,n);
				free(ptr);
				break;
			case 7:
				printf("\nenter the data to delete : ");
				__fpurge(stdin);
				scanf("%d",&num);
				del_purticular_node(num);
				break;
			case 8:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the position to add : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				add_at_position(num,dum);
				break;
			case 9:
				reverse_list();
				break;
			case 10:
				delete_duplicates();
				break;
			case 11:
				delete_list();
				break;
			case 12:
				printf("\nenter the data1 : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the data2 : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				swap(num,dum);
				break;
			case 13:
				printf("\nenter the data to search : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				printf("\nenter the data to add after node : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_after_node(dum,num);
				break;
			case 14:
				printf("\nenter the data to search : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				printf("\nenter the data to add before node : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_before_node(dum,num);
				break;
			case 15:
				head=selection_sort(head);
				break;
			case 16:
				head=bubble_sort(head);
				break;
			case 17:
				printf("\nenter the no of elements : ");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int*)malloc(1*sizeof(int));
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                well=create_list(well,ptr,n);
				well=selection_sort(well);
				//display(well);
                                free(ptr);
				printf("\nenter the no of elements : ");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int*)malloc(1*sizeof(int));
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                done=create_list(done,ptr,n);
				done=selection_sort(done);
				//display(done);
                                free(ptr);
				merge_sort();
				display(res);
				break;
			default:
				printf("\n\tinvalid option\n\n");
		}
	}
}
//****************************   add the node at beginning   *******************************
void add_at_begn(int num)
{
	struct node *ptr;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	ptr->prev=NULL;
	if(head!=NULL)
	{
		head->prev=ptr;
		ptr->next=head;
	}
	else
                ptr->next=NULL;
	head=ptr;
}
//*****************************   delete the node at beginning  ****************************
void del_at_begn()
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=head;
	head=head->next;
	head -> prev = NULL;
	free(temp);
}
//*****************************        displat the list        *****************************
void display(struct node *head1)
{
	struct node *temp;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	temp=head1;
	//printf("\n\nthe data is : ");
	while(temp!=NULL)
	{
		printf("%-15p   %-15p   %-15p     %d\n",temp->prev,temp,temp->next,temp->data);
		temp=temp->next;
	}
	printf("\n\n");
}
//****************************      add the node at last       *****************************
void add_at_last(int num)
{
	struct node *ptr,*temp;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->next=NULL;
	ptr->data=num;
	if(head==NULL)
	{
		ptr->prev=NULL;
		head=ptr;
		return;
	}
	temp=head;
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	ptr->prev=temp;
	temp->next=ptr;
}
//***************************     delete the node at last      ****************************
void del_at_last()
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tlist is empty\n\n");
		return;
	}
	if(head->next==NULL)
	{
		temp=head;
		head=head->next;
		free(temp);
		return;
	}
	temp=head;
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	temp->prev->next=temp->next;
	free(temp);
}
//*************************          create the list         ******************************
struct node * create_list(struct node *head1,int *arr,int n)
{
	struct node *start=NULL,*prev,*ptr,*temp;
	int i;
        for(i=0;i<n;i++)
	{
		ptr=(struct node*)malloc(1*sizeof(struct node));
		ptr->next=NULL;
		ptr->data=arr[i];
		if(start==NULL)
		{
			ptr->prev=start;
			start=ptr;
			prev=ptr;
		}
		else
		{
			prev->next=ptr;
			ptr->prev=prev;
			prev=ptr;
		}
	}
	if(head1==NULL)
	{
		head1=start;
		return head1;
	}
	temp=head1;
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	temp->next=start;
	start->prev=temp;
	return head1;
}
//*************************     delete the purticular node by data     ********************
void del_purticular_node(int num)
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->data==num)
	{
		if(head->next==NULL)
		{
		free(head);
		head=NULL;
		return;
		}
		temp=head;
		head=head->next;
		head->prev=NULL;
		free(temp);
		return;
	}
	temp=head->next;
	while(temp!=NULL)
	{
		if(temp->data==num)
		{
			temp->prev->next=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->prev;
			free(temp);
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found \n\n");
}
//******************************   add at position  ****************************************
void add_at_position(int num,int pos)
{
	int count=0;
	struct node *ptr,*temp;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	if(pos==0)
	{
		ptr->next=head;
		ptr->prev=NULL;
		head=ptr;
		return;
	}
	temp=head;
	count=0;
	while(temp!=NULL)
	{
		count++;
		if(count==pos)
		{
			ptr->next=temp->next;
			ptr->prev=temp;
			temp->next=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe position is not found\n\n");
}
//*************************     reverse the list     *************************************
//
void reverse_list()
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tlist is empty\n\n");
		return;
	}
	if(head->next==NULL)
		return;
	temp=head;
	while(temp!=NULL)
	{
		ptr=temp->prev;
		temp->prev=temp->next;
		temp->next=ptr;
		head=temp;
		temp=temp->prev;
	}
}
//************************      delete the duplicate nodes    *************************
void delete_duplicates()
{
	struct node *temp,*ptr,*main1;
	if(head==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	if(head->next==NULL)
		return;
	for(main1=head;main1!=NULL;main1=main1->next)
	{
		for(temp=main1->next;temp!=NULL;temp=temp->next)
		{
			if(main1->data==temp->data)
			{
				temp->prev->next=temp->next;
				if(temp->next!=NULL)
					temp->next->prev=temp->prev;
				ptr=temp->prev;
				free(temp);
				temp=ptr;
			}
		}
	}
}
//********************************   delete the list   *****************************
void delete_list()
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		ptr=temp->next;
		free(temp);
		temp=ptr;
	}
	head=temp;
}
// *******************************  swap the node by link  **************************
void swap(int num,int dum)
{
	int pos1=0,pos2=0;
	struct node *cur1,*cur2,*temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->next==NULL)
		return;
	if(num==dum)
		return;
	cur1=cur2=head;
	while(cur1!=NULL)
	{
		pos1++;
		if(cur1->data==num)
			break;
		cur1=cur1->next;
	}
	while(cur2!=NULL)
	{
		pos2++;
		if(cur2->data==dum)
			break;
		cur2=cur2->next;
	}
	if((cur1==NULL)||(cur2==NULL))
	{
		printf("\n\tthe data not found\n\n");
		return;
	}
	if(pos1>pos2)
	{
		temp=cur1;
		cur1=cur2;
		cur2=temp;
	}
	if(cur1->next!=cur2)
	{
		cur1->next->prev=cur2;
		cur2->prev->next=cur1;
		if(head==cur1)
			head=cur2;
		else
			cur1->prev->next=cur2;
		if(cur2->next!=NULL)
			cur2->next->prev=cur1;
		temp=cur1->next;
		cur1->next=cur2->next;
		cur2->next=temp;
		temp=cur1->prev;
		cur1->prev=cur2->prev;
		cur2->prev=temp;
	}
	else
	{
		if(head==cur1)
			head=cur2;
		else
			cur1->prev->next=cur2;
		if(cur2->next!=NULL)
			cur2->next->prev=cur1;
		cur1->next=cur2->next;
		cur2->prev=cur1->prev;
		cur2->next=cur1;
		cur1->prev=cur2;
	}
}
//*****************************     add after the selected node   ***********************
void add_after_node(int snum,int num)
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	temp=head;
	while(temp!=NULL)
	{
		if(temp->data==snum)
		{
			if(temp->next!=NULL)
			{
				ptr->next=temp->next;
				ptr->prev=temp;
				temp->next->prev=ptr;
				temp->next=ptr;
				return;
			}
			else
			{
				ptr->next=NULL;
				temp->next=ptr;
				ptr->prev=temp;
				return;
			}
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found\n\n");
}
// **************************   add before the selected node  ************************
void add_before_node(int snum,int num)
{
	struct node *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=head;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	while(temp!=NULL)
	{
		if(temp->data==snum)
		{
			if(head==temp)
			{
				ptr->prev=NULL;
				ptr->next=temp;
				temp->prev=ptr;
				head=ptr;
				return;
			}
			ptr->next=temp;
			ptr->prev=temp->prev;
			temp->prev->next=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found\n\n");
}
//***************************   selection  sorting    *********************************
struct node * selection_sort(struct node *head1)
{
	struct node *temp,*ptr,*dum;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return head1;
	}
	for(temp=head1;temp!=NULL;temp=temp->next)
	{
		for(ptr=temp->next;ptr!=NULL;ptr=ptr->next)
		{
			if(temp->data>ptr->data)
			{
				if(temp->next!=ptr)
				{
					temp->next->prev=ptr;
					ptr->prev->next=temp;
					if(head1==temp)
						head1=ptr;
					else
						temp->prev->next=ptr;
					if(ptr->next!=NULL)
						ptr->next->prev=temp;
					dum=temp->next;
					temp->next=ptr->next;
					ptr->next=dum;
					dum=temp->prev;
					temp->prev=ptr->prev;
					ptr->prev=dum;
				}
				else
				{
					if(head1==temp)
						head1=ptr;
					else
						temp->prev->next=ptr;
					if(ptr->next!=NULL)
						ptr->next->prev=temp;
					temp->next=ptr->next;
					ptr->prev=temp->prev;
					ptr->next=temp;
					temp->prev=ptr;
				}
				dum=temp;
                                temp=ptr;
                                ptr=temp;
			}
		}
	}
	return head1;
}
//*****************************   bubble sorting   ********************************
struct node* bubble_sort(struct node *head1)
{
	struct node *temp,*dum,*nxt,*dum1;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return head1;
	}
	for(dum=NULL;head1->next!=dum;dum=nxt)
	{
		for(temp=head1;temp->next!=dum;temp=temp->next)
		{
			nxt=temp->next;
			if(temp->data>nxt->data)
			{
				if(nxt->next!=NULL)
					nxt->next->prev=temp;
				nxt->prev=temp->prev;
				temp->next=nxt->next;
				nxt->next=temp;
				temp->prev=nxt;
				if(head1==temp)
					head1=nxt;
				else
					nxt->prev->next=nxt;
				dum1=temp;
				temp=nxt;
				nxt=dum1;
			}
		}
	}
	return head1;
}
//*******************************    merge sorting   ***************************************
void merge_sort()
{
	struct node *temp1,*temp2,*dum,*dumprev;
	if((well==NULL)&&(done==NULL))
	{
		printf("\n\tthe both lists are empty \n\n");
		return;
	}
	for(temp1=well,temp2=done,res=NULL;((temp1!=NULL)&&(temp2!=NULL));)
	{
		dum=(struct node*)malloc(1*sizeof(struct node));
		dum->next=NULL;
		if(temp1->data==temp2->data)
		{
			if(res==NULL)
			{
				dum->prev=NULL;
				dum->data=temp1->data;
				res=dum;
				dumprev=dum;
			}
			else
			{
				dum->data=temp1->data;
				dum->prev=dumprev;
				dum->prev->next=dum;
				dumprev=dum;
			}
			temp1=temp1->next;
			temp2=temp2->next;
		}
		else if(temp1->data>temp2->data)
		{
			if(res==NULL)
			{
				dum->prev=NULL;
				dum->data=temp2->data;
				res=dum;
				dumprev=dum;
			}
			else
			{
				dum->data=temp2->data;
				dum->prev=dumprev;
				dum->prev->next=dum;
				dumprev=dum;
			}
			temp2=temp2->next;
		}
		else
		{
			if(res==NULL)
			{
				dum->prev=NULL;
				dum->data=temp1->data;
				res=dum;
				dumprev=dum;
			}
			else
			{
				dum->data=temp1->data;
				dum->prev=dumprev;
				dum->prev->next=dum;
				dumprev=dum;
			}
			temp1=temp1->next;
		}
	}
	for(temp1;temp1!=NULL;temp1=temp1->next)
	{
		dum=(struct node*)malloc(1*sizeof(struct node));
		dum->next=NULL;
		if(res==NULL)
		{
			dum->prev=NULL;
			dum->data=temp1->data;
			res=dum;
			dumprev=dum;
		}
		else
		{
			dum->prev=dumprev;
			dum->prev->next=dum;
			dum->data=temp1->data;
			dumprev=dum;
		}
	}
	for(temp2;temp2!=NULL;temp2=temp2->next)
	{
		dum=(struct node*)malloc(1*sizeof(struct node));
		dum->next=NULL;
		if(res==NULL)
		{
			dum->prev=NULL;
			dum->data=temp2->data;
			res=dum;
			dumprev=dum;
		}
		else
		{
			dum->prev=dumprev;
			dum->prev->next=dum;
			dum->data=temp2->data;
			dumprev=dum;
		}
	}
}
//******************************************  end  *************************************
