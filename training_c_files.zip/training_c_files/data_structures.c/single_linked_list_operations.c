#include<stdio_ext.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *link;
};
struct node *head=NULL,*well=NULL,*done=NULL,*res=NULL;
struct node **dptr=NULL;
int i=0;
struct node* create_list(struct node *,int *,int);
void addatbegn(int );
void delatbegn();
void display(struct node*);
int cnt_nodes();
int search_data(int);
void delete_list();
void del_at_last();
void add_at_last(int);
void add_after_node(int, int);
void add_before_node(int, int);
void delete_node(int);
void reverse_list();
void swap_nodes(int, int);
void delete_duplicate_nodes();
void merge_sort();
struct node* selection_sort(struct node *);
struct node* bubble_sort(struct node*);
int main()
{
	int opt,dum,num,n,nodes,i,snum;
	int *ptr;
	while(1)
	{
		printf("\n\t*****  menu  *****\n0 -exit \n1 -creating the list \n2 -adding the node at beginning \n3 -deleting the node at beginning \n4 -displaying the data in nodes \n5 -count the nodes \n6 -search the data \n7 -delete the list \n8 -delete at last node \n9 -add the node at last \n10-add the node after selected node\n11-add the node before selected node \n12-delete purticular node \n13-reverse the list \n14-swaping the seleted nodes \n15-delete duplicate nodes\n16-merge sort \n17-selection sorting \n18-bubble sorting\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case 0:
				printf("\n\tthe sucessfull termination of program\n\n");
				exit(0);
			case 1:
				printf("enter the no of nodes :");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int *)malloc(n*sizeof(int));
				if(ptr==NULL)
				{
					printf("\n\tfailed to allocate memory\n\n");
					exit(0);
				}
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					scanf("%d",&ptr[i]);
				}
				head=create_list(head,ptr,n);
				free(ptr);
				break;

			case 2:
				printf("\n\nenter the data :");
				__fpurge(stdin);
				scanf("%d",&num);
				addatbegn(num);
				break;
			case 3:
				delatbegn();
				break;
			case 4:
				display(head);
				break;
			case 5:
				dum=cnt_nodes();
				if(dum>0)
					printf("\n\nthe nodes present is/are :%d\n\n",dum);
				break;
			case 6:
				printf("\n\nenter the data to search :");
				__fpurge(stdin);
				scanf("%d",&num);
				dum=search_data(num);
				if(dum>0)
					printf("\n\nthe %d is present in the %d node \n\n",num,dum);
				else if(dum==0)
					printf("\n\nthe given no %d is not found\n\n",num);
				break;
			case 7:
				delete_list();
				break;
			case 8:
				del_at_last();
				break;
			case 9:
				printf("\n\nenter the data :");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_last(num);
				break;
			case 10:
				printf("\n\nenter the data to data to be search and to be add : ");
				__fpurge(stdin);
				scanf("%d%d",&snum,&num);
				add_after_node(snum,num);
				break;
			case 11:
				printf("\n\nenter the data to data to be search and to be add : ");
				__fpurge(stdin);
				scanf("%d%d",&snum,&num);
				add_before_node(snum,num);
				break;
			case 12:
				printf("\n\nenter the data :");
				__fpurge(stdin);
				scanf("%d",&num);
				delete_node(num);
				break;
			case 13:
				reverse_list();
				break;
			case 14:
				printf("enter the data that to be swap :");
				__fpurge(stdin);
				scanf("%d%d",&num,&dum);
				swap_nodes(num,dum);
				break;
			case 15:
				delete_duplicate_nodes();
				break;
			case 16:
				well=NULL;done=NULL;
				printf("enter the no of nodes :");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int *)malloc(n*sizeof(int));
				if(ptr==NULL)
				{
					printf("\n\tfailed to allocate memory\n\n");
					exit(0);
				}
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
				}
				well=create_list(well,ptr,n);
				well=selection_sort(well);
			//	display(well);
				printf("enter the no of nodes :");
				__fpurge(stdin);
				scanf("%d",&n);
				__fpurge(stdin);
				ptr=(int *)malloc(n*sizeof(int));
				if(ptr==NULL)
				{
					printf("\n\tfailed to allocate memory\n\n");
					exit(0);
				}
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
				}
				done=create_list(done,ptr,n);
				done=selection_sort(done);
			//	display(done);
				merge_sort();
				display(res);
				break;
			case 17:
				head=selection_sort(head);
				break;
			case 18:
				head=bubble_sort(head);
				break;
			case 19:
				printf("enter the nth node data from  %d nodes:",i);
				__fpurge(stdin);
				scanf("%d",&n);
				printf("middle node : %d\n",dptr[i/2]->data);
				break;
			default:
				printf("\n\tEnter the valid option\n\n");
		}
	}
}
//        **************  fun to create the node  ****************
struct node* create_list(struct node *head1,int *iptr,int n)
{
	int i;
	struct node *prev,*start=NULL,*temp;
	for(i=0;i<n;i++)
	{
		struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
		if(ptr==NULL)
		{
			printf("\n\tfailed to allocate memory\n\n");
			exit(-1);
		}
		ptr->data=iptr[i];
		ptr->link=NULL;
		if(start==NULL)
		{
			start=ptr;
		}
		else 
			prev->link=ptr;
		prev=ptr;
	}	
	if(head1==NULL)
	{
		head1=start;
		return head1;
	}
	temp=head1;
	while(temp->link!=NULL)
	{
		temp=temp->link;
	}	
	temp->link=start;
	return head1;
}
//          *****************  adding nodes at beginning  ****************
void addatbegn(int num)
{
	struct node *ptr;
	ptr=(struct node *)calloc(1,sizeof(struct node));
	if(ptr==NULL)
	{
		printf("\n\tfailed to allocate \n\n");
		exit(1);
	}
	ptr->data=num;
	ptr->link=head;
	head=ptr;
}
//         *****************  delete nodes at beginning  ****************
void delatbegn()
{
	struct node *ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	ptr=head;
	head=head->link;
	free(ptr);
}
//         ****************   display the elements  ********************
void display(struct node *head1)
{	
	dptr=NULL,i=0;
	struct node *ptr;
	if(head1 == NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	ptr=head1;
	printf("\nThe data : ");
	while(ptr!=NULL)
	{
		dptr=(struct node **)realloc(dptr,i+1*sizeof(struct node*));
		dptr[i]=ptr;
		printf("%d  ",ptr->data);
		ptr=ptr->link;
	}
	printf("\n\n");
}
//      ****************  count no of nodes  ******************
int cnt_nodes()
{
	struct node *ptr;
	int cnt=0;
	if(head==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return 0;
	}
	ptr=head;
	while(ptr!=NULL)
	{
		cnt++;
		ptr=ptr->link;
	}
	return cnt;
}
//      ***************  search the data in nodes ****************
int search_data(int num)
{
	struct node *ptr;
	int cnt=0;
	if(head==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return -1;
	}
	ptr=head;
	while(ptr!=NULL)
	{
		cnt++;
		if((ptr->data)==num)
			return cnt;
		ptr=ptr->link;
	}
	return 0;
}
//        *****************  delete the all nodes or list **************
void delete_list()
{
	struct node *ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return ;
	}
	while(head!=NULL)
	{
		ptr=head;
		head=ptr->link;
		free(ptr);
	}
	printf("\n\tthe list is deleted\n\n");
}
//    *******************   delete the last node fun definition   ****************
void del_at_last()
{
	struct node *prev,*cur;
	if(head==NULL)
	{
		printf("\n\tThe list is empty \n\n");
		return;
	}
	if(head->link==NULL)
	{
		free(head);
		head=NULL;
		return;
	}
	prev=head;
	cur=prev->link;
	while(cur->link!=NULL)
	{
		prev=cur;
		cur=cur->link;
	}
	free(cur);
	prev->link=NULL;
}
//      **********************   adding  node at last  **********************
void add_at_last(int num)
{
	struct node *ptr,*temp;
	if(head==NULL)
	{
		printf("\n\tThere is no nodes to add \n\n");
		return;
	}
	ptr=(struct node *)malloc(1*sizeof(struct node));
	if(ptr==NULL)
	{
		printf("\n\tfailed to alloc the memory in heap\n\n");
		exit(-1);
	}
	ptr->data=num;
	ptr->link=NULL;
/*	if(head->link==NULL)
	{
		head->link=ptr;
		return;
	}
*/	temp=head;
	while(temp->link!=NULL)
	{
		temp=temp->link;
	}
	temp->link=ptr;
	return;
}
//  ***********************   adding node after the selected node   ********************
void add_after_node(int snum,int num)
{
	struct node *ptr,*temp;
	if(head==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->data==snum)
		{
			ptr=(struct node*)malloc(1*sizeof(struct node));
			if(ptr==NULL)
			{
				printf("\n\tfailed to alloc the memory in heap\n\n");
				exit(-1);
			}
			ptr->data=num;
			ptr->link=temp->link;
			temp->link=ptr;
			return;
		}
		temp=temp->link;
	}
	printf("\n\tthe element not found in list \n\n");
	return;
}
//   ********************    adding node before the selected node  ******************
void add_before_node(int snum, int num)
{
	struct node *prev,*cur;
	if(head==NULL)
	{
		printf("\n\tThe list is empty\n\n");
		return;
	}
	if(head->data==snum)
	{
		struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
		if(ptr==NULL)
		{
			printf("\n\tfailed to alloc the memory in heap\n\n");
			exit(-1);
		}
		ptr->data=num;
		ptr->link=head;
		head=ptr;
		return;
	}
	prev=head;
	cur=head->link;
	while(cur!=NULL)
	{
		if(cur->data==snum)
		{
			struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
			if(ptr==NULL)
			{
				printf("\n\tfailed to alloc the memory in heap\n\n");
				exit(-1);
			}
			ptr->data=num;
			ptr->link=cur;
			prev->link=ptr;
			return;
		}
		prev=cur;
		cur=cur->link;
	}
	printf("\n\tthe element not found \n\n");
}
//   ***********************  delete the purticular node  ************************
void delete_node(int num)
{
	struct node *cur,*prev;
	if(head==NULL)
	{
		printf("\n\tThere is no nodes to add \n\n");
		return;
	}
	if(head->data==num)
	{
		if(head->link==NULL)
		{
			free(head);
			head=NULL;
			return;
		}
		cur=head;
		head=head->link;
		free(cur);
		//printf("\n\tthe element not found\n\n");
		return;
	}
	prev=head;
	cur=head->link;
	while(cur!=NULL)
	{
		if(cur->data==num)
		{
			prev->link=cur->link;
			free(cur);
			return;
		}
		prev=cur;
		cur=cur->link;
	}
	printf("\n\tthe element not found\n\n");
	return;
}
//   ********************  reverse list function definition  ********************
void reverse_list()
{
	struct node *prev,*cur,*next;
	if(head==NULL)
	{
		printf("\n\tThe list is empty \n\n");
		return;
	}
	prev=NULL;
	cur=head;
	while(cur!=NULL)
	{
		next=cur->link;
		cur->link=prev;
		prev=cur;
		cur=next;
	}
	head=prev;
}
//  ************************   swap the selected nodes  *************************
void swap_nodes(int num,int val)
{
	struct node *c1,*p1,*c2,*p2,*temp;
	int pos1,pos2;
	pos1=pos2=0;
	if(num==val)
		return;
	if(head==NULL)
	{
		printf("\n\tthe lsit is empty\n\n");
		return;
	}
	c1=c2=head;
	while(c1!=NULL)
	{
		pos1++;
		if(c1->data==num)
			break;
		p1=c1;
		c1=c1->link;
	}
	while(c2!=NULL)
	{
		pos2++;
		if(c2->data==val)
			break;
		p2=c2;
		c2=c2->link;
	}
	if((c1==NULL)||(c2==NULL))
	{
		printf("\n\tdata not found \n\n");
	        return;
	}
	if(pos1>pos2)
	{
		temp=c1;
		c1=c2;
		c2=temp;
		temp=p1;
		p1=p2;
		p2=temp;
	}
	if(c1->link!=c2)
	{
		temp=c1->link;
		c1->link=c2->link;
		c2->link=temp;
		p2->link=c1;
		if(head!=c1)
		{
			p1->link=c2;
		}
		else
			head=c2;
		return;
	}
	else
	{
		temp=c2->link;
		c2->link=c1;
		c1->link=temp;
		if(head!=c1)
		{
			p1->link=c2;
		}
		else
		{
			head=c2;
		}
		return;
	}
}
//    *************************   deleting duplicate nodes   **********************
void delete_duplicate_nodes()
{
	struct node *main1,*cur,*prev;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	for(main1=head;main1!=NULL;main1=main1->link)
	{
		for(cur=main1->link,prev=main1;cur!=NULL;prev=cur,cur=cur->link)
		{
			if(main1->data==cur->data)
			{
				prev->link=cur->link;
				free(cur);
				cur=prev;
			}
		}
	}
}

void merge_sort()
{
	struct node *temp1,*temp2,*prev;
	res=NULL;
	if((well==NULL)&&(done==NULL))
	{
		printf("\n\tthe both lists are empty \n\n");
		return;
	}
        for(temp1=well,temp2=done;((temp1!=NULL)&&(temp2!=NULL));)
	{
		if(temp1->data==temp2->data)
		{
			struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
			ptr->data=temp1->data;
			ptr->link=NULL;
			if(res==NULL)
			{
				res=ptr;
			}
			else
				prev->link=ptr;
			prev=ptr;
			temp1=temp1->link;
			temp2=temp2->link;
			continue;
		}
		else if(temp1->data<temp2->data)
		{
			struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
			ptr->data=temp1->data;
			ptr->link=NULL;
			if(res==NULL)
			{
				res=ptr;
			}
			else
				prev->link=ptr;
			prev=ptr;
			temp1=temp1->link;
			continue;
		}
		else
		{
			struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
			ptr->data=temp2->data;
			ptr->link=NULL;
			if(res==NULL)
			{
				res=ptr;
				printf("res=%p ",res);
			}
			else
				prev->link=ptr;
			prev=ptr;
			temp2=temp2->link;
			continue;
		}
	}
	for(temp1;temp1!=NULL;temp1=temp1->link)
	{
		struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
		ptr->data=temp1->data;
		ptr->link=NULL;
		if(res==NULL)
		{
			res=ptr;
		}
		else
			prev->link=ptr;
		prev=ptr;
	}
	for(temp2;temp2!=NULL;temp2=temp2->link)
	{
		struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
		ptr->data=temp2->data;
		ptr->link=NULL;
		if(res==NULL)
		{
			res=ptr;
		}
		else
			prev->link=ptr;
		prev=ptr;
	}
}
struct node* selection_sort(struct node *head1)
{
	struct node *main,*prev1,*prev2,*cur1,*cur2,*temp;
	if(head1==NULL)
	{
		printf("\n\tthe queue is empty\n\n");
		return NULL;
	}
	if(head1->link==NULL)
		return head1;
	for(prev1=cur1=head1;cur1->link!=NULL;prev1=cur1,cur1=cur1->link)
	{
		for(prev2=cur2=cur1->link;cur2!=NULL;prev2=cur2,cur2=cur2->link)
		{
			if(cur1->data>cur2->data)
			{
				if(cur1->link!=cur2)
				{
					temp=cur2->link;
					cur2->link=cur1->link;
					cur1->link=temp;
					prev2->link=cur1;
					if(head1==cur1)
						head1=cur2;
					else
						prev1->link=cur2;
				}
		/*		else
				{
					temp=cur2->link;
					cur2->link=cur1;
					cur1->link=temp;
					if(head1==cur1)
						head1=cur2;
					else
						prev1->link=cur2;
				}
				*/
				temp=cur1;
				cur1=cur2;
				cur2=temp;
			}
		}
	}
	return head1;
}

struct node * bubble_sort(struct node *head1)
{
	struct node *main,*cur1,*cur2,*prev1,*temp;
	if(head1==NULL)
	{
		printf("\n\tthe queue is empty\n\n");
		return NULL;
	}
	if(head1->link==NULL)
		return head1;
	for(main=NULL;main!=head1->link;main=cur2)
	{
		for(cur1=cur2=head1;cur1->link!=main;prev1=cur1,cur1=cur1->link)
		{
			cur2=cur1->link;
			if(cur1->data>cur2->data)
			{
				temp=cur2->link;
				cur2->link=cur1;
				cur1->link=temp;
				if(head1==cur1)
					head1=cur2;
				else
					prev1->link=cur2;
				temp=cur1;
				cur1=cur2;
				cur2=temp;
			}
		}
	}
	return head1;
}




		//       ************************      end      ***************************
