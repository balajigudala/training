#include<stdio_ext.h>
#include<stdlib.h>
struct prior
{
	struct prior *prev;
	int pre;
	int data;
	int freq;
	struct prior *next;
};
struct prior *head=NULL;
void display()
{
	struct prior *temp;
        if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	printf("the  priority    :    data  \n\n");
	while(temp!=NULL)
	{
		printf("%-15p -- %-15p -- %-15p  ||  ",temp->prev,temp,temp->next);
		printf("%8d     :     %4d    :    %4d \n",temp->pre,temp->data,temp->freq);
		temp=temp->next;
	}
}
void display_prior(int perd)
{
	struct prior *temp;
	int count=0;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	printf("\n\n     priority    :    data  \n\n");
	while(temp!=NULL)
	{
		if(perd==temp->pre)
		{
			count++;
			printf("%-15p -- %-15p -- %-15p  ||  ",temp->prev,temp,temp->next);
			printf("%8d     :     %d  \n",temp->pre,temp->data);
		}
		temp=temp->next;
	}
	if(count==0)
		printf("the data with %d priority value is not found ",perd);
}
void insert(int perd ,int num)
{
	struct prior *temp,*ptr;
	if(perd<=0)
	{
		printf("\n\t the priority value shouldn't be zero and negitive value\n\n");
		return;
	}
	ptr=(struct prior *)malloc(1*sizeof(struct prior));
	if(ptr==NULL)
	{
		printf("\n\tfailed to allocate memory\n\n");
		return;
	}
	ptr->data=num;
	ptr->pre=perd;
	if(head==NULL)
	{
		ptr->prev=NULL;
		ptr->next=NULL;
		head=ptr;
		return;
	}
	for(temp=head;temp!=NULL;temp=temp->next)
	{
		if(temp->pre>perd)
		{
			if(head==temp)
			{
				temp->prev=ptr;
				ptr->next=temp;
				ptr->prev=NULL;
				head=ptr;
				return;
			}
			ptr->next=temp;
			ptr->prev=temp->prev;
			temp->prev->next=ptr;
			temp->prev=ptr;
			return;
		}
		if(temp->next==NULL)
		{
			temp->next=ptr;
			ptr->next=NULL;
			ptr->prev=temp;
			return;
		}
	}
}
void delete()
{
	struct prior *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		ptr=temp;
		temp=temp->next;
		free(ptr);
	}
	head=temp;
}
void delete_prior_pop(int perd)
{
	struct prior *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->pre==perd)
		{
			ptr=temp->next;
			if(temp->prev!=NULL)
				temp->prev->next=temp->next;
			else 
				head=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->prev;
			free(temp);
			temp=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("the priority %d doesn't exists",perd);
}
void delete_prior_data_pop(int perd,int num)
{
	struct prior *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->pre==perd&&temp->data==num)
		{
			ptr=temp->next;
			if(temp->prev!=NULL)
				temp->prev->next=temp->next;
			else
				head=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->prev;
			free(temp);
			temp=ptr;
			return;
		}
		else
			temp=temp->next;
	}
	printf("\n\tthe selected priority is not found in list\n\n");
}
void delete_prior(int perd)
{
	struct prior *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->pre==perd)
		{
			//ptr=temp->next;
			if(temp->prev!=NULL)
				temp->prev->next=temp->next;
			else
				head=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->prev;
			free(temp);
			//temp=ptr;
		}
		else
			temp=temp->next;
	}
}
struct prior * create_list(struct prior *head1,int *arr,int n)
{     
	struct prior *temp,*ptr;
	int i;
	for(i=0;i<n;i=i+2)
	{
		if(arr[i]<=0)
		{
			printf("\n\t the priority value shouldn't be negitive value\n\n");
			continue;
		}
		ptr=(struct prior *)malloc(1*sizeof(struct prior));
		if(ptr==NULL)
		{
			printf("\n\tfailed to allocate memory\n\n");
			return NULL;
		}
		ptr->data=arr[i+1];
		ptr->pre=arr[i];
		if(head1==NULL)
		{
			ptr->prev=NULL;
			ptr->next=NULL;
			head1=ptr;
			continue;
		}
		temp=head1;
		while(temp!=NULL)
		{
			if(temp->pre>arr[i])
			{
				if(head1==temp)
				{
					temp->prev=ptr;
					ptr->next=temp;
					ptr->prev=NULL;
					head1=ptr;
				}
				else
				{
					temp->prev->next=ptr;
					ptr->prev=temp->prev;
					ptr->next=temp;
					temp->prev=ptr;
				}
				break;
			}
			if(temp->next==NULL)
			{ 
				temp->next=ptr;
				ptr->next=NULL;
				ptr->prev=temp;
				break;
			}
			temp=temp->next;
		}
	}
	return head1;
}
struct prior *sort_prior(struct prior *head1,int perd)
{
	struct prior *temp,*ptr,*dum,*qw;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return head1;
	}
	qw=head1;
	while(qw!=NULL)
	{
		if(perd!=qw->pre)
		{
			qw=qw->next;
			continue;
		}
		for(temp=qw;(temp!=NULL)&&(temp->pre==perd);temp=temp->next)
		{
			for(ptr=temp->next;(ptr!=NULL)&&(ptr->pre==perd);ptr=ptr->next)
			{
				if(temp->data>ptr->data)
				{
					if(temp->next!=ptr)
					{
						temp->next->prev=ptr;
						ptr->prev->next=temp;
						if(head1==temp)
							head1=ptr;
						else
							temp->prev->next=ptr;
						if(ptr->next!=NULL)
							ptr->next->prev=temp;
						dum=temp->next;
						temp->next=ptr->next;
						ptr->next=dum;
						dum=temp->prev;
						temp->prev=ptr->prev;
						ptr->prev=dum;
					}
					else
					{
						if(head1==temp)
							head1=ptr;
						else
							temp->prev->next=ptr;
						if(ptr->next!=NULL)
							ptr->next->prev=temp;
						temp->next=ptr->next;
						ptr->prev=temp->prev;
						ptr->next=temp;
						temp->prev=ptr;
					}
					dum=temp;
					temp=ptr;
					ptr=temp;
				}
			}
		}
		break;
	}
	return head1;
}

struct prior *sort_prior_data(struct prior *head1)
{
        struct prior *temp,*ptr,*dum,*qw;
        int perd;
        if(head1==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return head1;
        }
        qw=head1;
        while(qw!=NULL)
        {
                for(temp=qw,perd=temp->pre;(temp!=NULL)&&(temp->pre==perd);temp=temp->next)
                {
                        for(ptr=temp->next;(ptr!=NULL)&&(ptr->pre==perd);ptr=ptr->next)
                        {
                                if(temp->data>ptr->data)
                                {
                                        if(temp->next!=ptr)
                                        {
                                                temp->next->prev=ptr;
                                                ptr->prev->next=temp;
                                                if(head1==temp)
                                                        head1=ptr;
                                                else
                                                        temp->prev->next=ptr;
                                                if(ptr->next!=NULL)
                                                        ptr->next->prev=temp;
                                                dum=temp->next;
                                                temp->next=ptr->next;
                                                ptr->next=dum;
                                                dum=temp->prev;
                                                temp->prev=ptr->prev;
                                                ptr->prev=dum;
                                        }
                                        else
                                        {
                                                if(head1==temp)
                                                        head1=ptr;
                                                else
                                                        temp->prev->next=ptr;
                                                if(ptr->next!=NULL)
                                                        ptr->next->prev=temp;
                                                temp->next=ptr->next;
                                                ptr->prev=temp->prev;
                                                ptr->next=temp;
                                                temp->prev=ptr;
                                        }
                                        dum=temp;
                                        temp=ptr;
                                        ptr=temp;
                                }
                        }
                }
                qw=temp;
        }
        return head1;
}

/*
struct prior *sort_prior_data(struct prior *head1)
{
	struct prior *temp,*ptr,*dum,*qw;
	int perd;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return head1;
	}
	qw=head1;
	while(qw!=NULL)
	{
		for(temp=qw,perd=temp->pre;(temp!=NULL)&&(temp->pre==perd);temp=temp->next)
		{
			for(ptr=temp->next;(ptr!=NULL)&&(ptr->pre==perd);ptr=ptr->next)
			{
				if(temp->data>ptr->data)
				{
					if(temp->next!=ptr)
					{
						temp->next->prev=ptr;
						ptr->prev->next=temp;
						if(head1==temp)
							head1=ptr;
						else
							temp->prev->next=ptr;
						if(ptr->next!=NULL)
							ptr->next->prev=temp;
						dum=temp->next;
						temp->next=ptr->next;
						ptr->next=dum;
						dum=temp->prev;
						temp->prev=ptr->prev;
						ptr->prev=dum;
					}
					else
					{
						if(head1==temp)
							head1=ptr;
						else
							temp->prev->next=ptr;
						if(ptr->next!=NULL)
							ptr->next->prev=temp;
						temp->next=ptr->next;
						ptr->prev=temp->prev;
						ptr->next=temp;
						temp->prev=ptr;
					}
					dum=temp;
					temp=ptr;
					ptr=temp;
				}
			}
		}
		qw=temp;
	}
	return head1;
}
*/
void sort_data()
{
	struct prior *temp,*dum;
	int well;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->next==NULL)
		return;
	for(temp=head;temp->next!=NULL;temp=temp->next)
	{
		for(dum=temp->next;dum!=NULL;dum=dum->next)
		{
			if(temp->pre==dum->pre)
			{
				if(temp->data>dum->data)
				{
					well=temp->data;
					temp->data=dum->data;
					dum->data=well;
				}
			}
			else
				break;
		}
	}
}
void frequency()
{
	int count=0;
	struct prior *temp,*dum;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	for(temp=head;temp!=NULL;temp=dum)
	{
		count=1;
		temp->freq=count;
		for(dum=temp->next;dum!=NULL;dum=dum->next)
		{
			if(temp->pre==dum->pre)
			{
				dum->freq=++count;
			}
			else
				break;
		}
	}
}
int main()
{
	int *ptr,i,n,num,dum,opt;
	char sub;
	while(1)
	{
		printf("\n\t>>>>>>>>>>>>   menu - priority queue  <<<<<<<<<<<<\n\n-1 - clear \n 0 - exit \n 1 - insert \n 2 - display \n 3 - delete \n 4 - create list \n 5 - sort the data by link in a purticular priority \n 6 - sort the data by link in all priorities \n 7 - sort the data by in all priorities \n 8 - set the frequency \n");
		printf("\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case -1:
				system("clear");
				break;
			case 0:
				printf("\n\t succesfull termination \n\n");
				exit(0);
			case 1:
				printf("\nenter the priority value : ");
				scanf("%d",&num);
				printf("\nenter the data to insert : ");
				scanf("%d",&dum);
				insert(num,dum);
				break;
			case 2:
				//while(1)
				{	
					printf("\n\n a-display the selected priority data values \n b-display the all data in Queue  \n\nselect the sub options : ");
					__fpurge(stdin);
					scanf("%c",&sub);
					switch(sub)
					{
						case 'a':
							printf("\nenter the priority value to display : ");
							scanf("%d",&num);
							display_prior(num);
							break;
						case 'b':
							display();
							break;
						default:
							printf("\n\tenter the valid sub Option\n\n");
					}
				}
				break;
			case 3:
				{
				//	while(1)
					{
						printf("\n\n 0 - exit \n a - delete the selected priority data values \n b - delete  all the data in Queue \n c - delete the selected priority first data \n d - delete the data in selected priority and data \n\n     select the sub options : ");
						__fpurge(stdin);
						scanf("%c",&sub);
						if(sub=='0')
							break;
						switch(sub)
						{
							case 'a':
								printf("\nenter the priority value to delete : ");
								__fpurge(stdin);
								scanf("%d",&num);
								delete_prior(num);
								break;
							case 'b':
								delete();
								break;
							case 'c':
								printf("\nenter the priority value to pop : ");
								__fpurge(stdin);
								scanf("%d",&num);
								delete_prior_pop(num);
								break;
							case 'd':
								printf("\nenter the priority value  : ");
								__fpurge(stdin);
								scanf("%d",&num);
								printf("\nenter the data to delete : ");
								__fpurge(stdin);
								scanf("%d",&dum);
								delete_prior_data_pop(num,dum);
								break;
							default:
								printf("\n\tenter the valid sub Option\n\n");
						}
					}
				}
				break;
			case 4:
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc((n=2*n)*sizeof(int));
				for(i=0;i<n;i=i+2)
				{
					printf("enter the priority value : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i+1]);
				}
				head=create_list(head,ptr,n);
				free(ptr);
				break;	
			case 5:
				printf("\nenter the priority value to sort the data : ");
				__fpurge(stdin);
				scanf("%d",&n);
				head=sort_prior(head,n);
				break;
			case 6:
				head=sort_prior_data(head);
				break;
			case 7:
				sort_data();
				break;
			case 8:
				frequency();
				break;
			default:
				printf("\n\tenter the valid Option\n\n");
		}
	}
}
