#include<stdio_ext.h>
#include<stdlib.h>
struct poly
{
	struct poly *prev;
	int pwr;
	int coef;
	struct poly *next;
};
struct poly *equ1=NULL,*equ2=NULL,*equ3=NULL,*head;
void display( struct poly *equ)
{
	struct poly *temp;
        if(equ==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=equ;
	printf("the  polyity    :    coef  \n\n");
	while(temp!=NULL)
	{
		printf("%-15p -- %-15p -- %-15p  ||  ",temp->prev,temp,temp->next);
		printf(" %dY^%d + \n",temp->coef,temp->pwr);
		temp=temp->next;
	}
}
struct poly* insert(struct poly *eqn,int num ,int pow)
{
	struct poly *temp,*ptr;
	if(num==0)
		return eqn;
	ptr=(struct poly *)malloc(1*sizeof(struct poly));
	if(ptr==NULL)
	{
		printf("\n\tfailed to allocate memory\n\n");
		return eqn;
	}
	ptr->coef=num;
	ptr->pwr=pow;
	if(eqn==NULL)
	{
		ptr->prev=NULL;
		ptr->next=NULL;
		eqn=ptr;
		return eqn;
	}
	for(temp=eqn;temp!=NULL;temp=temp->next)
	{
		if(temp->pwr==pow)
		{
			temp->coef=(temp->coef)+num;
			return eqn;
		}
		else if(temp->pwr<pow)
		{
			if(temp==eqn)
			{
				ptr->prev=NULL;
				eqn=ptr;
			}
			else
			{
				temp->prev->next=ptr;
				ptr->prev=temp->prev;
			}
			ptr->next=temp;
			temp->prev=ptr;
			return eqn;
		}
		else if(temp->next==NULL)
		{
			ptr->next=NULL;
			ptr->prev=temp;
			temp->next=ptr;
			return eqn;
		}
	}
}

void delete()
{
	struct poly *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		ptr=temp;
		temp=temp->next;
		free(ptr);
	}
	head=temp;
}
void delete_poly_pop(int perd)
{
	struct poly *temp,*ptr;
	if(temp==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=temp;
	while(temp!=NULL)
	{
		if(temp->pwr==perd)
		{
			ptr=temp->next;
			if(temp->prev!=NULL)
				temp->prev->next=temp->next;
			else 
				head=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->pwr;
			free(temp);
			temp=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("the polyity %d doesn't exists",perd);
}
void delete_poly_coef_pop(int perd,int num)
{
	struct poly *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->pwr==perd&&temp->coef==num)
		{
			ptr=temp->next;
			if(temp->prev!=NULL)
				temp->prev->next=temp->next;
			else
				head=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->pwr;
			free(temp);
			temp=ptr;
			return;
		}
		else
			temp=temp->next;
	}
	printf("\n\tthe selected polyity is not found in list\n\n");
}
void delete_poly(int perd)
{
	struct poly *temp,*ptr;
	if(head==NULL)
	{
		printf("\n\t The queue is empty \n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->pwr==perd)
		{
			//ptr=temp->next;
			if(temp->prev!=NULL)
				temp->prev->next=temp->next;
			else
				head=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->pwr;
			free(temp);
			//temp=ptr;
		}
		else
			temp=temp->next;
	}
}
struct poly * create_list(struct poly *head1,int *arr,int n)
{     
	struct poly *temp,*ptr;
	int i;
	for(i=0;i<n;i=i+2)
	{
		if(arr[i]<=0)
		{
			printf("\n\t the polyity value shouldn't be negitive value\n\n");
			continue;
		}
		ptr=(struct poly *)malloc(1*sizeof(struct poly));
		if(ptr==NULL)
		{
			printf("\n\tfailed to allocate memory\n\n");
			return NULL;
		}
		ptr->coef=arr[i+1];
		ptr->pwr=arr[i];
		if(head1==NULL)
		{
			ptr->prev=NULL;
			ptr->next=NULL;
			head1=ptr;
			continue;
		}
		temp=head1;
		while(temp!=NULL)
		{
			if(temp->pwr>arr[i])
			{
				if(head1==temp)
				{
					temp->prev=ptr;
					ptr->next=temp;
					ptr->prev=NULL;
					head1=ptr;
				}
				else
				{
					temp->prev->next=ptr;
					ptr->prev=temp->pwr;
					ptr->next=temp;
					temp->prev=ptr;
				}
				break;
			}
			if(temp->next==NULL)
			{ 
				temp->next=ptr;
				ptr->next=NULL;
				ptr->prev=temp;
				break;
			}
			temp=temp->next;
		}
	}
	return head1;
}
struct poly *sort_poly(struct poly *head1,int perd)
{
	struct poly *temp,*ptr,*dum,*qw;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return head1;
	}
	qw=head1;
	while(qw!=NULL)
	{
		if(perd!=qw->pwr)
		{
			qw=qw->next;
			continue;
		}
		for(temp=qw;(temp!=NULL)&&(temp->pwr==perd);temp=temp->next)
		{
			for(ptr=temp->next;(ptr!=NULL)&&(ptr->pwr==perd);ptr=ptr->next)
			{
				if(temp->coef>ptr->coef)
				{
					if(temp->next!=ptr)
					{
						temp->next->prev=ptr;
						ptr->prev->next=temp;
						if(head1==temp)
							head1=ptr;
						else
							temp->prev->next=ptr;
						if(ptr->next!=NULL)
							ptr->next->prev=temp;
						dum=temp->next;
						temp->next=ptr->next;
						ptr->next=dum;
						dum=temp->prev;
						temp->prev=ptr->pwr;
						ptr->prev=dum;
					}
					else
					{
						if(head1==temp)
							head1=ptr;
						else
							temp->prev->next=ptr;
						if(ptr->next!=NULL)
							ptr->next->prev=temp;
						temp->next=ptr->next;
						ptr->prev=temp->pwr;
						ptr->next=temp;
						temp->prev=ptr;
					}
					dum=temp;
					temp=ptr;
					ptr=temp;
				}
			}
		}
		break;
	}
	return head1;
}

struct poly *sort_poly_coef(struct poly *head1)
{
        struct poly *temp,*ptr,*dum,*qw;
        int perd;
        if(head1==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return head1;
        }
        qw=head1;
        while(qw!=NULL)
        {
                for(temp=qw,perd=temp->pwr;(temp!=NULL)&&(temp->pwr==perd);temp=temp->next)
                {
                        for(ptr=temp->next;(ptr!=NULL)&&(ptr->pwr==perd);ptr=ptr->next)
                        {
                                if(temp->coef>ptr->coef)
                                {
                                        if(temp->next!=ptr)
                                        {
                                                temp->next->prev=ptr;
                                                ptr->prev->next=temp;
                                                if(head1==temp)
                                                        head1=ptr;
                                                else
                                                        temp->prev->next=ptr;
                                                if(ptr->next!=NULL)
                                                        ptr->next->prev=temp;
                                                dum=temp->next;
                                                temp->next=ptr->next;
                                                ptr->next=dum;
                                                dum=temp->prev;
                                                temp->prev=ptr->pwr;
                                                ptr->prev=dum;
                                        }
                                        else
                                        {
                                                if(head1==temp)
                                                        head1=ptr;
                                                else
                                                        temp->prev->next=ptr;
                                                if(ptr->next!=NULL)
                                                        ptr->next->prev=temp;
                                                temp->next=ptr->next;
                                                ptr->prev=temp->pwr;
                                                ptr->next=temp;
                                                temp->prev=ptr;
                                        }
                                        dum=temp;
                                        temp=ptr;
                                        ptr=temp;
                                }
                        }
                }
                qw=temp;
        }
        return head1;
}

void sort_coef()
{
	struct poly *temp,*dum;
	int well;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->next==NULL)
		return;
	for(temp=head;temp->next!=NULL;temp=temp->next)
	{
		for(dum=temp->next;dum!=NULL;dum=dum->next)
		{
			if(temp->pwr==dum->pwr)
			{
				if(temp->coef>dum->coef)
				{
					well=temp->coef;
					temp->coef=dum->coef;
					dum->coef=well;
				}
			}
			else
				break;
		}
	}
}

struct poly* sum_poly(struct poly *equu1,struct poly *equu2, struct poly *equu3)
{
	struct poly *temp,*sim;
	if(equu1==NULL&&equu2==NULL)
	    return NULL;

	if(equu1==NULL)
			return equu2;
	if(equu2==NULL)
			return equu1;

/*	for(;equu1!=NULL&&equu2!=NULL;)
	{
		struct poly *ptr=(struct poly*)malloc(1*sizeof(struct poly));
		if(equu1->pwr==equu2->pwr)
		{
			if(equu3==NULL)
			{
				ptr->prev=NULL;
				ptr->next=NULL;
				ptr->coef=equu1->coef+equu2->coef;
				ptr->pwr=equu1->pwr;
				equu3=ptr;
				sim=equu3;
				equu1=equu1->next;
				equu2=equu2->next;
				continue;
				sim->next=ptr;
				ptr->coef=equu1->coef+equu2->coef;
				ptr->pwr=equu1->pwr;
				ptr->next=NULL;
				sim=ptr;
				continue;
		        }
		}
	}*/
}

int main()
{
	int *ptr,i,n,num,dum,opt;
	char sub;
	while(1)
	{
		printf("\n\t>>>>>>>>>>>>   menu - polynomial eqn <<<<<<<<<<<<\n\n-1 - clear \n 0 - exit \n 1 - insert \n 2 - display \n 3 - delete \n 4 - create list  \n 7 - sort the coef by in all polyities \n 8 -  \n");
		printf("\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case -1:
				system("clear");
				break;
			case 0:
				printf("\n\t succesfull termination \n\n");
				exit(0);
			case 1:
				printf("\nenter the coefficient value : ");
				scanf("%d",&num);
				printf("\nenter the power to insert : ");
				scanf("%d",&dum);
				equ1=insert(equ1,num,dum);
				break;
			case 21:
				printf("\nenter the coefficient value : ");
				scanf("%d",&num);
				printf("\nenter the power to insert : ");
				scanf("%d",&dum);
				equ2=insert(equ2,num,dum);
				break;
			case 2:
				display(equ1);
				break;
			case 22:
				display(equ2);
				break;
			case 3:
				printf("\nenter the polyity value to delete : ");
				__fpurge(stdin);
				scanf("%d",&num);
				//delete_poly(equ1);
				break;
			case 23:
				printf("\nenter the polyity value to delete : ");
				__fpurge(stdin);
				scanf("%d",&num);
				//delete_poly(equ2);
				break;
			case 24:
				equ3=NULL;
				equ3=sum_poly(equ1,equ2,equ3);
				display(equ3);
				break;
			case 4:
				//delete();
				break;
			case 'd':
				printf("\nenter the polyity value  : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the coef to delete : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				//delete_poly_coef_pop(num,dum);
				break;
			case 5:
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc((n=2*n)*sizeof(int));
				for(i=0;i<n;i=i+2)
				{
					printf("enter the polyity value : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
					printf("enter the coef : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i+1]);
				}
				//head=create_list(head,ptr,n);
				free(ptr);
				break;	
			case 6:
				printf("\nenter the polyity value to sort the coef : ");
				__fpurge(stdin);
				scanf("%d",&n);
				//head=sort_poly(head,n);
				break;
			case 7:
				//head=sort_poly_coef(head);
				break;
			case 8:
				//sort_coef();
				break;
			default:
				printf("\n\tenter the valid Option\n\n");
		}
	}
}

