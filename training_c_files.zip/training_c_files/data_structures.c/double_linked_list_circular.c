//     ************ list of operations for double linked circular list *************
#include<stdio_ext.h>
#include<stdlib.h>
#pragma pack(1)
struct node
{
        struct node *prev;
        int data;
        struct node *next;
};
void add_at_begn(int );
void del_at_begn();
void display(struct node *);
void add_at_last(int );
void del_at_last();
struct node* create_list(struct node *,int*,int);
void del_purticular_node(int);
void add_at_position(int ,int);
void reverse_list();
void delete_duplicates();
void delete_list();
void swap(int ,int);
void add_after_node(int ,int);
void add_before_node(int ,int);
struct node * selection_sort(struct node*);
struct node* bubble_sort(struct node *);
void merge_sort();
struct node *head=NULL,*well=NULL,*done=NULL,*res=NULL;

void add_at_begn(int num)
{
        struct node *ptr;
        ptr=(struct node*)malloc(1*sizeof(struct node));
        ptr->data=num;
        if(head==NULL)
        {
                ptr->prev=head=ptr->next=ptr;
		return;
        }
	ptr->next=head;
	ptr->prev=head->prev;
	head->prev->next=ptr;
	head->prev=ptr;
	head=ptr;

}
void display(struct node *head1)
{
        struct node *temp;
        if(head1==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        temp=head1;
        printf("\n\nthe data is : \n");
        while(temp->next!=head1)
        {
                printf("%-15p -- cur :%-15p -- %d -- %-15p\n",temp->prev,temp,temp->data,temp->next);
                temp=temp->next;
        }

                printf("%-15p -- cur :%-15p -- %d -- %-15p\n",temp->prev,temp,temp->data,temp->next);
        printf("\n\n");
}

void del_at_begn()
{
        struct node *temp;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
	if(head->next==head)
	{
		free(head);
		head=NULL;
		return;
	}
	head->next->prev=head->prev;
	head->prev->next=head->next;
	temp=head;
	head=head->next;
	free(temp);
}

void add_at_last(int num)
{
        struct node *ptr,*temp;
        ptr=(struct node*)malloc(1*sizeof(struct node));
        ptr->data=num;
        if(head==NULL)
        {
                ptr->prev=ptr->next=head=ptr;
                return;
        }
	
}


int main()
{
        int *ptr,n,i,num,dum,opt;
        while(1)
        {
                printf("\n\t>>>>>>>>>>>>>>>   menu   <<<<<<<<<<<<<<\n\n-1 -clear\n 0 -exit\n 1 -add at beggining \n 2 -delete at beginning \n 3 -add at last\n 4 -delete at last\n 5 -display\n 6 -create list\n 7 -delete purticular node \n 8 -add node at position\n 9 -reverse the list \n 10-delete duplicates data nodes \n 11-delete the list \n 12-swap the selected data \n 13-add_after the node \n 14-add before the node \n 15-selection sort \n 16-bubble sorting \n 17-merge_sorting\n\nselect the option : ");
                __fpurge(stdin);
                scanf("%d",&opt);
                switch(opt)
                {
                        case -1:
                                system("clear");
                                break;
                        case 0:
                                printf("\n\tsucesfull termination\n\n");
                                exit(0);
			case 1:
                                printf("\nenter the data to add : ");
                                __fpurge(stdin);
                                scanf("%d",&num);
                                add_at_begn(num);
                                break;
                        case 2:
  //                              del_at_begn();
                                break;
                        case 3:
                                printf("\nenter the data to add : ");
                                __fpurge(stdin);
                                scanf("%d",&num);
		}
                ptr->data=arr[i];
                if(head1==NULL)
                {
                        ptr->prev=ptr->next=head1=ptr;
                }
                else
                {
			ptr->next=head1;
			ptr->prev=head1->prev;
			head1->prev->next=ptr;
			head1->prev=ptr;
		}
	}
	return head1;
}

void del_purticular_node(int num)
{
        struct node *temp;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        if(head->data==num)
        {
                if(head->next==head)
                {
			free(head);
			head=NULL;
			return;
                }
                temp=head;
		head->prev->next=head->next;
		head->next->prev=head->prev;
                head=head->next;
                free(temp);
                return;
        }
        temp=head->next;
        while(temp!=head)
        {
                if(temp->data==num)
                {
			temp->prev->next=temp->next;
			if(temp->next!=head)
			{
				temp->next->prev=temp->prev;
			}
			else
				
				head->prev=temp->prev;
			free(temp);
                        return;
                }
                temp=temp->next;
        }
        printf("\n\tthe data not found \n\n");
}

void reverse_list()
{
        struct node *temp,*ptr,*new;
        if(head==NULL)
        {
                printf("\n\tlist is empty\n\n");
                return;
        }
        if(head->next==head)
                return;
        temp=head;
	new=head->prev;
        do
       	{
                ptr=temp->prev;
                temp->prev=temp->next;
                temp->next=ptr;
                temp=temp->next;
        }
        while(temp!=head);
	head=new;
}

void delete_duplicates()
{
        struct node *temp,*ptr,*main1;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        if(head->next==head)
                return;
        for(main1=head;main1->next!=head;main1=main1->next)
        {
		temp=main1->next;
                do
                {
                        if(main1->data==temp->data)
                        {
                                temp->prev->next=temp->next;
                                if(temp->next!=head)
                                        temp->next->prev=temp->prev;
                                ptr=temp->prev;
                                free(temp);
                                temp=ptr;
                        }
			temp=temp->next;
                }
		while(temp!=head);
        }
}

void swap(int num,int dum)
{
        int pos1=0,pos2=0,flag1=0,flag2=0;
        struct node *cur1,*cur2,*temp,*ptr;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(head->next==head)
		return;
	if(num===dum)
		return;
	cur1=cur2=head;
	do
	{
		pos1++;
		if(cur1->data==num)
		{
			flag1=1;
			break;
		}
		cur1=cur1->next;
	}
	while(cur1!=head);
	do
	{
		pos2++;
		if(cur2->data==num)
		{
			flag2=1;
			break;
		}
		cur2=cur2->next;
	}
	while(cur2!=head);
	if((flag1!=1)||(flag2!=1))
	{
		printf("\n\t the data not found \n\n");
		return;
	}
	if(pos1>pos2)
	{
		temp=cur1;
		cur1=cur2;
		cur2=temp;
	}
	if(cur1->next!=cur2)
	{
		temp=cur1->prev;
		cur1->prev=cur2->prev;
		cur2->prev=temp;
		temp=cur1->next;
		cur1->next=cur2->next;
		cur2->next=temp;
		if(head!=cur1)
			cur2->prev->next=cur2;
		else
		{
			temp=head;
			/*while(temp->next!=head)
				temp=temp->next;
			temp->next=cur2;*/
			if(cur2==cur2->prev)
			{
				temp=cur1->next;
				cur1->next=cur2->prev;
				cur2->prev=temp;
			}
			else
				cur2->next->prev=cur2;

			head=cur2;
		}
		cur2->next->prev=cur2;
		cur1->prev->next=cur1;
		if(cur1->next!=cur2->prev)
			cur1->next->prev=cur1;
	}
}
