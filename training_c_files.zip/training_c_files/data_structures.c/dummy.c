#include<stdio_ext.h>
#include<stdlib.h>
struct node
{
        int data;
        struct node *link;
};
struct node *head=NULL;
void create_list(int *,int);
void addatbegn(int );
void delatbegn();
void display();
int cnt_nodes();
int search_data(int);
void delete_list();
void del_at_last();
void add_at_last(int);
void add_after_node(int, int);
void add_before_node(int, int);
void delete_node(int);
void reverse_list();
void swap_nodes(int, int);
int main()
{
        int opt,dum,num,n,nodes,i,snum;
        int *ptr;
        while(1)
        {
                printf("\n\t*****  menu  *****\n0 -exit \n1 -creating the list \n2 -displaying the data in nodes\n3 -delete purticular node \n4 -swaping the seleted nodes \n\nselect the option : ");
                __fpurge(stdin);
                scanf("%d",&opt);
                switch(opt)
                {
                        case 0:
                                printf("\n\tthe sucessfull termination of program\n\n");
                                exit(0);
                        case 1:
                                printf("enter the no of nodes :");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int *)malloc(n*sizeof(int));
                                if(ptr==NULL)
                                {
                                        printf("\n\tfailed to allocate memory\n\n");
                                        exit(0);
                                }
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        scanf("%d",&ptr[i]);
                                }
                                create_list(ptr,n);
                                free(ptr);
                                break;
			case 2:
				display();
				break;
			case 3:
				printf("\n\nenter the data to erase : ");
				scanf("%d",&num);
				delete_node(num);
				break;
			case 4:
				printf("\n\nenter the data to be swap : ");
				scanf("%d%d",&num,&dum);
				swap_nodes(num,dum);
				break;
			default :
				printf("\n\tinvalid ooption\n\n");
		}
	}
}
void create_list(int *iptr,int n)
{
        int i;
        struct node *prev,*start=NULL,*temp;
        for(i=0;i<n;i++)
        {
                struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
                if(ptr==NULL)
                {
                        printf("\n\tfailed to allocate memory\n\n");
                        exit(-1);
                }
                ptr->data=iptr[i];
                ptr->link=NULL;
                if(start==NULL)
                {
                        start=ptr;
                }
                else
                        prev->link=ptr;
                prev=ptr;
        }
        if(head==NULL)
        {
                head=start;
                return;
        }
        temp=head;
        while(temp->link!=NULL)
        {
                temp=temp->link;
        }
        temp->link=start;
}
void delete_node(int num)
{
        struct node *cur,*prev;
        if(head==NULL)
        {
                printf("\n\tThe list is empt \n\n");
                return;
        }
        if(head->data==num)
        {
                if(head->link==NULL)
                {
                        free(head);
                        head=NULL;
                        return;
                }
                cur=head;
                head=head->link;
                free(cur);
                //printf("\n\tthe element not found\n\n");
                return;
        }
        prev=head;
        cur=head->link;
        while(cur!=NULL)
        {
                if(cur->data==num)
                {
                        prev->link=cur->link;
                        free(cur);
                        return;
                }
                prev=cur;
                cur=cur->link;
        }
        printf("\n\tthe element not found\n\n");
        return;
}
void display()
{
        struct node *ptr;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        ptr=head;
        printf("\nThe data : ");
        while(ptr!=NULL)
        {
                printf("%d  ",ptr->data);
                ptr=ptr->link;
        }
        printf("\n\n");
}
void swap_nodes(int num1,int num2)
{
	struct node *cur1,*cur2,*prev1,*prev2,*temp;
	int pos1,pos2;
	pos1=pos2=0;
	if(num1==num2)
		return;
	if(head==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	cur1=cur2=head;
	while(cur1!=NULL)
	{
		pos1++;
		if(cur1->data==num1)
			break;
		prev1=cur1;
		cur1=cur1->link;
	}
	while(cur2!=NULL)
	{
		pos2++;
		if(cur2->data==num2)
			break;
		prev2=cur2;
		cur2=cur2->link;
	}
	if((cur1==NULL)||(cur2==NULL))
	{
		printf("\n\tthe data not found\n\n");
		return;
	}
	if(pos1>pos2)
	{
		temp=cur1;
		cur1=cur2;
		cur2=temp;
		temp=prev1;
		prev1=prev2;
		prev2=temp;
	}
	if(cur1->link!=cur2)
	{
		temp=cur1->link;
		cur1->link=cur2->link;
		cur2->link=temp;
		prev2->link=cur1;
		if(head!=cur1)
			prev1->link=cur2;
		else
			head=cur2;
		return;
	}
	else
	{
		temp=cur2->link;
		cur2->link=cur1;
		cur1->link=temp;
		if(head!=cur1)
			prev1->link=cur2;
		else
			head=cur2;
		return;
	}
}
