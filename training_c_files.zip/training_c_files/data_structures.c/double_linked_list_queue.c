//   double linked list queue  
#include<stdio_ext.h>
#include<stdlib.h>
#pragma pack(1)
struct node
{
	struct node *prev;
	int data;
	struct node *next;
};
//void add_at_begn(int );
void pop();
void display(struct node *,struct node *);
void insert(int );
//void del_at_last();
struct node* create_queue(struct node *,struct node *,int*,int);
void del_purticular_node(int);
void add_at_position(int ,int);
void reverse_queue();
void delete_duplicates();
void delete_queue();
void swap(int ,int);
void add_after_node(int ,int);
void add_before_node(int ,int);
struct node * selection_sort(struct node*,struct node *);
struct node* bubble_sort(struct node *,struct node *);
void merge_sort();
struct node *front=NULL,*rearf=NULL,*rear1=NULL;*well=NULL,*rearw=NULL,*done=NULL,*reard=NULL,*res=NULL,*rearr=NULL;
int main()
{
	int *ptr,n,i,num,dum,opt;
	while(1)
	{
		printf("\n\t>>>>>>>>>>>>>>>   menu   <<<<<<<<<<<<<<\n\n-1 -clear\n 0 -exit\n 1 -delete at beginning \n 2 -add at last\n 3 -display\n 4 -create queue\n 5 -delete purticular node \n 6 -add node at position\n 7 -reverse the queue \n 8 -delete duplicates data nodes \n 9 -delete the queue \n 10-swap the selected data \n 11-add_after the node \n 12-add before the node \n 13-selection sort \n 14-bubble sorting \n 15-merge_sorting\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case -1:
				system("clear");
				break;
			case 0:
				printf("\n\tsucesfull termination\n\n");
				exit(0);
			case 1:
				pop();
				break;
			case 2:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				insert(num);
				break;
			case 3:
				display(front,rearf);
				break;
			case 4:
				printf("\nenter the no of elements : ");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int*)malloc(1*sizeof(int));
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					__fpurge(stdin);
					scanf("%d",&ptr[i]);
				}
				front=create_queue(front,rearf,ptr,n);
				rearf=rear1;
				rear1=NULL;
				free(ptr);
				break;
			case 5:
				printf("\nenter the data to delete : ");
				__fpurge(stdin);
				scanf("%d",&num);
				del_purticular_node(num);
				break;
			case 6:
				printf("\nenter the data to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the position to add : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				add_at_position(num,dum);
				break;
			case 7:
				reverse_queue();
				break;
			case 8:
				delete_duplicates();
				break;
			case 9:
				delete_queue();
				break;
			case 10:
				printf("\nenter the data1 : ");
				__fpurge(stdin);
				scanf("%d",&num);
				printf("\nenter the data2 : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				swap(num,dum);
				break;
			case 11:
				printf("\nenter the data to search : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				printf("\nenter the data to add after node : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_after_node(dum,num);
				break;
			case 12:
				printf("\nenter the data to search : ");
				__fpurge(stdin);
				scanf("%d",&dum);
				printf("\nenter the data to add before node : ");
				__fpurge(stdin);
				scanf("%d",&num);
				add_before_node(dum,num);
				break;
			case 13:
				front=selection_sort(front,rearf);
				rearf=rear1;
				rear1=NULL;
				break;
			case 14:
				front=bubble_sort(front,rearf);
				rearf=rear1;
				rear1=NULL;
				break;
			case 15:
				printf("\nenter the no of elements : ");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int*)malloc(1*sizeof(int));
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                well=create_list(well,rearw,ptr,n);
				rearw=rear1;
				rear1=NULL;
				well=selection_sort(well,rearw);
				rearw=rear1;
				rear1=NULL;
				//display(well);
                                free(ptr);
				printf("\nenter the no of elements : ");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int*)malloc(1*sizeof(int));
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                done=create_list(done,reard,tr,n);
				reard=rear1;
				rear1=NULL;
				done=selection_sort(done,reard);
				reard=rear1;
				rear1=NULL;
				//display(done);
                                free(ptr);
				merge_sort();
				display(res);
				break;
			default:
				printf("\n\tinvalid option\n\n");
		}
	}
}

void pop()
{
	struct node *temp;
	if(front==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=front;
	if(temp->next==NULL)
		rear1=NULL;
	front=front->next;
	free(temp);
}

void display(struct node *head1,struct node *rearf)
{
	struct node *temp;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	temp=head1;
	printf("\n\nthe data is : ");
	while(temp!=NULL)
	{
		printf("  %d",temp->data);
		temp=temp->next;
	}
	printf("\n\n");
}

void insert(int num)
{
	struct node *ptr,*temp;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->next=NULL;
	ptr->data=num;
	if(front==NULL)
	{
		ptr->prev=NULL;
		front=ptr;
		rearf=front;
		return;
	}
	temp=front;
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	ptr->prev=temp;
	rearf=ptr;
	temp->next=ptr;
}

struct node * create_list(struct node *head1,stuct node *rearfun,int *arr,int n)
{
	struct node *start=NULL,*rears=NULL,*prev,*ptr,*temp;
	int i;
        for(i=0;i<n;i++)
	{
		ptr=(struct node*)malloc(1*sizeof(struct node));
		ptr->next=NULL;
		ptr->data=arr[i];
		if(start==NULL)
		{
			ptr->prev=start;
			start=ptr;
			rears=ptr;
			prev=ptr;
		}
		else
		{
			prev->next=ptr;
			ptr->prev=prev;
			prev=ptr;
			rears=ptr;
		}
	}
	if(head1==NULL)
	{
		head1=start;
		rear1=rears;
		return head1;
	}
	temp=head1;
/*	while(temp->next!=NULL)
	{
		temp=temp->next;
	}*/
	rearfun->next=start;
	start->prev=temp;
	rear1=rearfun;
	return head1;
}

void del_purticular_node(int num)
{
	struct node *temp;
	if(front==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(front->data==num)
	{
		if(front->next==NULL)
		{
		free(front);
		front=NULL;
		rear1=NULL;
		return;
		}
		temp=front;
		front=head->next;
		front->prev=NULL;
		free(temp);
		return;
	}
	temp=front->next;
	while(temp!=NULL)
	{
		if(temp->data==num)
		{
			if(temp->link==NULL)
				rear1=temp;
			temp->prev->next=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->prev;
			free(temp);
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found \n\n");
}

void add_at_position(int num,int pos)
{
	int count=0;
	struct node *ptr,*temp;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	if(pos==0)
	{
		ptr->next=front;
		ptr->prev=NULL;
		rear1=ptr;
		front=ptr;
		return;
	}
	temp=front;
	count=0;
	while(temp!=NULL)
	{
		count++;
		if(count==pos)
		{
			if(temp->next==NULL)
				rear1=ptr;
			ptr->next=temp->next;
			ptr->prev=temp;
			temp->next=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe position is not found\n\n");
}

void reverse_queue()
{
	struct node *temp,*ptr;
	if(front==NULL)
	{
		printf("\n\tlist is empty\n\n");
		return;
	}
	if(front->next==NULL)
		return;
	temp=front;
	rear1=front;
	while(temp!=NULL)
	{
		ptr=temp->prev;
		temp->prev=temp->next;
		temp->next=ptr;
		front=temp;
		temp=temp->prev;
	}
}

void delete_duplicates()
{
	struct node *temp,*ptr,*main1;
	if(front==NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	if(front->next==NULL)
		return;
	for(main1=front;main1!=NULL;main1=main1->next)
	{
		for(temp=main1->next;temp!=NULL;temp=temp->next)
		{
			if(main1->data==temp->data)
			{
				temp->prev->next=temp->next;
				if(temp->next!=NULL)
					temp->next->prev=temp->prev;
				else
					rear1 = ptr;
				ptr=temp->prev;
				free(temp);
				temp=ptr;
			}
		}
	}
}

void delete_queue()
{
	struct node *temp,*ptr;
	if(front==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=front;
	while(temp!=NULL)
	{
		ptr=temp->next;
		free(temp);
		temp=ptr;
	}
	front=temp;
	rear1=NULL;
}

void swap(int num,int dum)
{
	int pos1=0,pos2=0;
	struct node *cur1,*cur2,*temp,*ptr;
	if(front==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	if(front->next==NULL)
	{
		rear1=front;
		return;
	}
	if(num==dum)
		return;
	cur1=cur2=front;
	while(cur1!=NULL)
	{
		pos1++;
		if(cur1->data==num)
			break;
		cur1=cur1->next;
	}
	while(cur2!=NULL)
	{
		pos2++;
		if(cur2->data==dum)
			break;
		cur2=cur2->next;
	}
	if((cur1==NULL)||(cur2==NULL))
	{
		printf("\n\tthe data not found\n\n");
		return;
	}
	if(pos1>pos2)
	{
		temp=cur1;
		cur1=cur2;
		cur2=temp;
	}
	if(cur1->next!=cur2)
	{
		cur1->next->prev=cur2;
		cur2->prev->next=cur1;
		if(front==cur1)
			front=cur2;
		else
			cur1->prev->next=cur2;
		if(cur2->next!=NULL)
			cur2->next->prev=cur1;
		temp=cur1->next;
		cur1->next=cur2->next;
		cur2->next=temp;
		temp=cur1->prev;
		cur1->prev=cur2->prev;
		cur2->prev=temp;
	}
	else
	{
		if(front==cur1)
			front=cur2;
		else
			cur1->prev->next=cur2;
		if(cur2->next!=NULL)
			cur2->next->prev=cur1;
		cur1->next=cur2->next;
		cur2->prev=cur1->prev;
		cur2->next=cur1;
		cur1->prev=cur2;
	}
}

void add_after_node(int snum,int num)
{
	struct node *temp,*ptr;
	if(front==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	temp=front;
	while(temp!=NULL)
	{
		if(temp->data==snum)
		{
			if(temp->next!=NULL)
			{
				ptr->next=temp->next;
				ptr->prev=temp;
				temp->next->prev=ptr;
				if(temp->next==NULL)
					rearf=ptr;
				temp->next=ptr;
				return;
			}
			else
			{
				ptr->next=NULL;
				temp->next=ptr;
				if(temp->next==NULL)
					rearf=ptr;
				ptr->prev=temp;
				return;
			}
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found\n\n");
}

void add_before_node(int snum,int num)
{
	struct node *temp,*ptr;
	if(front==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return;
	}
	temp=front;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	while(temp!=NULL)
	{
		if(temp->data==snum)
		{
			if(front==temp)
			{
				ptr->prev=NULL;
				ptr->next=temp;
				temp->prev=ptr;
				front=ptr;
				return;
			}
			ptr->next=temp;
			ptr->prev=temp->prev;
			temp->prev->next=ptr;
			return;
		}
		temp=temp->next;
	}
	printf("\n\tthe data not found\n\n");
}

struct node * selection_sort(struct node *head1)
{
	struct node *temp,*ptr,*dum;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return head1;
	}
	for(temp=head1;temp!=NULL;temp=temp->next)
	{
		for(ptr=temp->next;ptr!=NULL;ptr=ptr->next)
		{
			if(temp->data>ptr->data)
			{
				if(temp->next!=ptr)
				{
					temp->next->prev=ptr;
					ptr->prev->next=temp;
					if(head1==temp)
						head1=ptr;
					else
						temp->prev->next=ptr;
					if(ptr->next!=NULL)
						ptr->next->prev=temp;
					dum=temp->next;
					temp->next=ptr->next;
					ptr->next=dum;
					dum=temp->prev;
					temp->prev=ptr->prev;
					ptr->prev=dum;
				}
				else
				{
					if(head1==temp)
						head1=ptr;
					else
						temp->prev->next=ptr;
					if(ptr->next!=NULL)
						ptr->next->prev=temp;
					temp->next=ptr->next;
					ptr->prev=temp->prev;
					ptr->next=temp;
					temp->prev=ptr;
				}
				dum=temp;
                                temp=ptr;
                                ptr=temp;
			}
		}
	}
	return head1;
}

struct node* bubble_sort(struct node *head1)
{
	struct node *temp,*dum,*nxt,*dum1;
	if(head1==NULL)
	{
		printf("\n\tthe list is empty\n\n");
		return head1;
	}
	for(dum=NULL;head1->next!=dum;dum=nxt)
	{
		for(temp=head1;temp->next!=dum;temp=temp->next)
		{
			nxt=temp->next;
			if(temp->data>nxt->data)
			{
				if(nxt->next!=NULL)
					nxt->next->prev=temp;
				nxt->prev=temp->prev;
				temp->next=nxt->next;
				nxt->next=temp;
				temp->prev=nxt;
				if(head1==temp)
					head1=nxt;
				else
					nxt->prev->next=nxt;
				dum1=temp;
				temp=nxt;
				nxt=dum1;
			}
		}
	}
	return head1;
}

void merge_sort()
{
	struct node *temp1,*temp2,*dum,*dumprev;
	if((well==NULL)&&(done==NULL))
	{
		printf("\n\tthe both lists are empty \n\n");
		return;
	}
	for(temp1=well,temp2=done,res=NULL;((temp1!=NULL)&&(temp2!=NULL));)
	{
		dum=(struct node*)malloc(1*sizeof(struct node));
		dum->next=NULL;
		if(temp1->data==temp2->data)
		{
			if(res==NULL)
			{
				dum->prev=NULL;
				dum->data=temp1->data;
				res=dum;
				dumprev=dum;
			}
			else
			{
				dum->data=temp1->data;
				dum->prev=dumprev;
				dum->prev->next=dum;
				dumprev=dum;
			}
			temp1=temp1->next;
			temp2=temp2->next;
		}
		else if(temp1->data>temp2->data)
		{
			if(res==NULL)
			{
				dum->prev=NULL;
				dum->data=temp2->data;
				res=dum;
				dumprev=dum;
			}
			else
			{
				dum->data=temp2->data;
				dum->prev=dumprev;
				dum->prev->next=dum;
				dumprev=dum;
			}
			temp2=temp2->next;
		}
		else
		{
			if(res==NULL)
			{
				dum->prev=NULL;
				dum->data=temp1->data;
				res=dum;
				dumprev=dum;
			}
			else
			{
				dum->data=temp1->data;
				dum->prev=dumprev;
				dum->prev->next=dum;
				dumprev=dum;
			}
			temp1=temp1->next;
		}
	}
	for(temp1;temp1!=NULL;temp1=temp1->next)
	{
		dum=(struct node*)malloc(1*sizeof(struct node));
		dum->next=NULL;
		if(res==NULL)
		{
			dum->prev=NULL;
			dum->data=temp1->data;
			res=dum;
			dumprev=dum;
		}
		else
		{
			dum->prev=dumprev;
			dum->prev->next=dum;
			dum->data=temp1->data;
			dumprev=dum;
		}
	}
	for(temp2;temp2!=NULL;temp2=temp2->next)
	{
		dum=(struct node*)malloc(1*sizeof(struct node));
		dum->next=NULL;
		if(res==NULL)
		{
			dum->prev=NULL;
			dum->data=temp2->data;
			res=dum;
			dumprev=dum;
		}
		else
		{
			dum->prev=dumprev;
			dum->prev->next=dum;
			dum->data=temp2->data;
			dumprev=dum;
		}
	}
}
