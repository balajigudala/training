#include<stdlib.h>
#include<stdio_ext.h>
struct node
{
	int data;
	struct node *link;
}__attribute__((packed));
void create_list(int*,int);
void display();
void insert(int);
void delete();
void delete_queue();
void delete_purticular_node(int);
void delete_duplicates();
void reverse_queue();
void swap_queue(int ,int);
void selection_sort();
void bubble_sort();
void merge_sort();
void merge_display();
struct node *frontd=NULL,*reard=NULL,*front=NULL,*rear=NULL,*wellf=NULL,*wellr=NULL,*donef=NULL,*doner=NULL,*resf=NULL,*resr=NULL;
int main()
{
	int num,dum,size,opt,*ptr,i;
	while(1)
	{
		printf("\n\t>>>>>>>  menu  <<<<<<<\n\n0 -exit \n1 -create list \n2 -insert \n3 -delete\n4 -display\n5 -delete queue \n6 -search queue \n7 -delete purticular node \n8 -delete duplicates\n9 -reverse queue \n10-swap the selected nodes\n11-selection_sort \n12-bubble_sort \n13-merge sort\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case 0:
				printf("\n\tsuccesfull termination\n\n");
				exit(0);
			case 1:
				printf("\n\nenter the no of nodes : ");
				scanf("%d",&size);
				ptr=(int *)malloc(size*sizeof(int));
				if(ptr==NULL)
				{
					printf("\n\tfailed to allocate memory \n\n");
					break;
				}
				for(i=0;i<size;i++)
				{
					printf("enter the data : ");
					scanf("%d",&ptr[i]);
				}
				create_list(ptr,size);
				front=frontd;rear=reard;
				frontd=NULL;reard=NULL;
				break;
			case 2:
				printf("\n\nenter the data to insert : ");
				scanf("%d",&num);
				insert(num);
				break;
			case 3:
				delete();
				break;
			case 4:
				printf("\n\nthe data in queue is : ");
				display();
				printf("\n\n");
				break;
			case 5:
			       delete_queue();
			       break;
			case 7:
			       printf("\n\nenter the data to delete : ");
			       scanf("%d",&num);
			       delete_purticular_node(num);
			       break;
			case 8:
			       delete_duplicates();
			       break;
			case 9:
			       reverse_queue();
			       break;
			case 10:
			       printf("\n\nenter the numbers to swap : ");
			       scanf("%d%d",&num,&dum);
			       swap_queue(num,dum);
			       break;
			case 11:
			       selection_sort();
			       break;
			case 12:
			       bubble_sort();
			       break;
			case 13:
                                printf("\n\nenter the no of nodes : ");
                                scanf("%d",&size);
                                ptr=(int *)malloc(size*sizeof(int));
                                if(ptr==NULL)
                                {
                                        printf("\n\tfailed to allocate memory \n\n");
                                        break;
                                }
                                for(i=0;i<size;i++)
                                {
                                        printf("enter the data : ");
                                        scanf("%d",&ptr[i]);
                                }
                                create_list(ptr,size);
                                wellf=frontd;wellr=reard;
                                frontd=NULL;reard=NULL;
                                printf("\n\nenter the no of nodes : ");
                                scanf("%d",&size);
                                ptr=(int *)malloc(size*sizeof(int));
                                if(ptr==NULL)
                                {
                                        printf("\n\tfailed to allocate memory \n\n");
                                        break;
                                }
                                for(i=0;i<size;i++)
                                {
                                        printf("enter the data : ");
                                        scanf("%d",&ptr[i]);
                                }
                                create_list(ptr,size);
                                donef=frontd;doner=reard;
                                frontd=NULL;reard=NULL;
				merge_sort();
				merge_display();
				break;
			default:
			       printf("\n\tinvalid option\n\n");
		}
	}
}

void create_list(int *iptr,int size)
{
	int i;
	struct node *ptr;
	for(i=0;i<size;i++)
	{
		ptr=(struct node*)malloc(1*sizeof(struct node));
		ptr->data=iptr[i];
		ptr->link=NULL;
		if(frontd==NULL)
		{
			frontd=reard=ptr;
		}
		else
		{
			reard->link=ptr;
			reard=ptr;
		//	prev=ptr;
		}
	}
}

void display()
{
	struct node *temp;
	if(front==NULL)
	{
		printf("The Queue is empty\n\n");
		return;
	}
	temp=front;
	while(temp!=NULL)
	{
		printf(" %d",temp->data);
		temp=temp->link;
	}
}
void merge_display()
{
        struct node *temp;
        if(resf==NULL)
        {
                printf("The Queue is empty\n\n");
                return;
        }
        temp=resf;
        while(temp!=NULL)
        {
                printf(" %d",temp->data);
                temp=temp->link;
        }
}

void insert(int num)
{
	struct node *ptr;
	ptr=(struct node*)malloc(1*sizeof(struct node));
	ptr->data=num;
	ptr->link=NULL;
	if(front==NULL)
	{
		front=rear=ptr;
	}
	else
	{
		rear->link=ptr;
		rear=ptr;
	}
}

void delete()
{
	struct node *temp;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	if(front==rear)
	{
		free(front);
		rear=front=NULL;
		return;
	}
	temp=front->link;
	free(front);
	front=temp;
}

void delete_queue()
{
	struct node *temp,*ptr;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	temp=front;
	while(temp!=NULL)
	{
		if(temp==rear)
		{
			front=rear=NULL;
			free(temp);
			return;
		}
		ptr=temp;
		temp=temp->link;
		free(ptr);
	}
}

void delete_purticular_node(int num)
{
	struct node *temp,*prev;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	if(front==rear)
	{
		if(front->data==num)
		{
			free(front);
			front=rear=NULL;
			return;
		}
		printf("\n\tthe element not found\n\n");
	}
	else
	{
		temp=front;
		while(temp!=NULL)
		{
			if(temp->data==num)
			{
				if(temp==rear)
				{
					rear=prev;
					prev->link=NULL;
					free(temp);
					return;
				}
				if(front->data==num)
				{
					temp=front->link;
					free(front);
					front=temp;
					return;
				}
				prev->link=temp->link;
				free(temp);
				return;
			}
			prev=temp;
			temp=temp->link;
		}
		printf("\n\telement not found\n\t");
	}
}

void delete_duplicates()
{
	struct node *main,*cur,*prev,*temp;
	if(front==NULL)
	{
		printf("\n\tthe Queue is empty \n\n");
		return;
	}
	if(rear==front)
		return;
	for(main=front;main!=NULL;main=main->link)
	{
		for(prev=main,cur=main->link;cur!=NULL;prev=cur,cur=cur->link)
		{
			if(main->data==cur->data)
			{
				if(cur==rear)
				{
					prev->link=cur->link;
					free(cur);
					rear=prev;
					break;
				}
				else
				{
					prev->link=cur->link;
					free(cur);
					cur=prev;
				}
			}
		}
	}
}

void reverse_queue()
{
	struct node *prev,*cur,*next,*temp;
	if(front==NULL)
	{
		printf("\n\tthe queue is empty\n\n");
		return;
	}
	if(front==rear)
		return;
	prev=NULL;
	cur=front;
	while(cur!=NULL)
	{
		next=cur->link;
		cur->link=prev;
		prev=cur;
		cur=next;
	}
	rear=front;
	front=prev;
//	rear=prev->link;
}

void swap_queue(int num1,int num2)
{
	int pos1=0,pos2=0;
	struct node *cur1,*cur2,*prev1,*prev2,*temp;
	if(rear==NULL)
	{
		printf("\n\tthe queue is empty\n\n1");
		return;
	}
	if(rear==front)
		return;
	cur1=cur2=front;
	while(cur1!=NULL)
	{
		pos1++;
		if(cur1->data==num1)
			break;
		prev1=cur1;
		cur1=cur1->link;
	}
	while(cur2!=NULL)
	{
		pos2++;
		if(cur2->data==num2)
			break;
		prev2=cur2;
		cur2=cur2->link;
	}
	if(pos1>pos2)
	{
		temp=cur1;
		cur1=cur2;
		cur2=temp;
		temp=prev1;
		prev1=prev2;
		prev2=temp;
	}
	if(cur1->link!=cur2)
	{
		temp=cur2->link;
		cur2->link=cur1->link;
		cur1->link=temp;
		prev2->link=cur1;
		if(cur2==rear)
			rear=cur1;
		if(front==cur1)
			front=cur2;
		else
			prev1->link=cur2;
	}
	else
	{
		temp=cur2->link;
		cur2->link=cur1;
		cur1->link=temp;
		if(cur2==rear)
			rear=cur1;
		if(front==cur1)
			front=cur2;
		else
			prev1->link=cur2;
	}
}

//     ******************************  selection sorting  *************************************
void selection_sort()
{
        struct node *main,*prev1,*prev2,*cur1,*cur2,*temp;
        if(front==NULL)
        {
                printf("\n\tthe queue is empty\n\n");
                return ;
        }
        if(front->link==NULL)
                return;
        for(prev1=cur1=front;cur1->link!=NULL;prev1=cur1,cur1=cur1->link)
        {
                for(prev2=cur2=cur1->link;cur2!=NULL;prev2=cur2,cur2=cur2->link)
                {
                        if(cur1->data>cur2->data)
                        {
                                if(cur1->link!=cur2)
                                {
                                        temp=cur2->link;
                                        cur2->link=cur1->link;
                                        cur1->link=temp;
                                        prev2->link=cur1;
					if(rear==cur2)
						rear=cur1;
                                        if(front==cur1)
                                                front=cur2;
                                        else
                                                prev1->link=cur2;
                                }
                                else
                                {
                                        temp=cur2->link;
                                        cur2->link=cur1;
                                        cur1->link=temp;
					if(rear==cur2)
						rear=cur1;
                                        if(front==cur1)
                                                front=cur2;
                                        else
                                                prev1->link=cur2;
                                }
                                temp=cur1;
                                cur1=cur2;
                                cur2=temp;
                        }
                }
        }
        return;
}
//   ***********************************  bubble sorting  ***************************************
void  bubble_sort()
{
        struct node *main,*cur1,*cur2,*prev1,*temp;
        if(front==NULL)
        {
                printf("\n\tthe queue is empty\n\n");
                return;
        }
        if(front->link==NULL)
                return;
        for(main=NULL;main!=front->link;main=cur2)
        {
                for(cur1=cur2=front;cur1->link!=main;prev1=cur1,cur1=cur1->link)
                {
                        cur2=cur1->link;
                        if(cur1->data>cur2->data)
                        {
                                temp=cur2->link;
                                cur2->link=cur1;
                                cur1->link=temp;
				if(rear==cur2)
					rear=cur1;
                                if(front==cur1)
                                        front=cur2;
                                else
                                        prev1->link=cur2;
                                temp=cur1;
                                cur1=cur2;
                                cur2=temp;
                        }
                }
        }
        return;
}
//    **************************  merge sorting   ***************************
void merge_sort()
{
        struct node *temp1,*temp2,*prev;
        resf=NULL,resr=NULL;
        if((wellf==NULL)&&(donef==NULL))
        {
                printf("\n\tthe both lists are empty \n\n");
                return;
        }
        for(temp1=wellf,temp2=donef;((temp1!=NULL)&&(temp2!=NULL));)
        {
                if(temp1->data==temp2->data)
                {
                        struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
                        ptr->data=temp1->data;
                        ptr->link=NULL;
                        if(resf==NULL)
                        {
                                resf=ptr;
                        }
                        else
                                prev->link=ptr;
                        prev=ptr;
                        temp1=temp1->link;
                        temp2=temp2->link;
                        continue;
                }
                else if(temp1->data<temp2->data)
                {
                        struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
                        ptr->data=temp1->data;
                        ptr->link=NULL;
                        if(resf==NULL)
                        {
                                resf=ptr;
                        }
                        else
                                prev->link=ptr;
                        prev=ptr;
                        temp1=temp1->link;
                        continue;
                }
                else
                {
                        struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
                        ptr->data=temp2->data;
                        ptr->link=NULL;
                        if(resf==NULL)
                        {
                                resf=ptr;
                                //printf("resf=%p ",res);
                        }
                        else
                                prev->link=ptr;
                        prev=ptr;
                        temp2=temp2->link;
                        continue;
                }
        }
   for(temp1;temp1!=NULL;temp1=temp1->link)
        {
                struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
                ptr->data=temp1->data;
                ptr->link=NULL;
                if(resf==NULL)
                {
                        resf=ptr;
                }
                else
                        prev->link=ptr;
                prev=ptr;
        }
        for(temp2;temp2!=NULL;temp2=temp2->link)
        {
                struct node *ptr=(struct node*)malloc(1*sizeof(struct node));
                ptr->data=temp2->data;
                ptr->link=NULL;
                if(resf==NULL)
                {
                        resf=ptr;
                }
                else
                        prev->link=ptr;
                prev=ptr;
        }
}

