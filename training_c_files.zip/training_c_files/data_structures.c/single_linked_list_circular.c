//        single linked llist circular 
#include<stdio_ext.h>
#include<stdlib.h>
struct node
{
        int data;
        struct node *link;
	int freq;
};
struct node *head=NULL,*well=NULL,*done=NULL,*res=NULL;
struct node * create_list(struct node *,int *,int);
void addatbegn(int );
void delatbegn();
void display(struct node*);
int cnt_nodes();
int search_data(int);
void delete_list();
void del_at_last();
void add_at_last(int);
void add_after_node(int, int);
void add_before_node(int, int);
void delete_node(int);
void reverse_list();
void swap_nodes(int, int);
void delete_duplicate_nodes();
void merge_sort();
struct node * selection_sort(struct node *);
struct node * bubble_sort(struct node*);

void addatbegn(int num)
{
        struct node *ptr,*temp;
        ptr=(struct node *)calloc(1,sizeof(struct node));
        if(ptr==NULL)
        {
                printf("\n\tfailed to alloc the memory in heap\n\n");
                exit(-1);
        }
	ptr->data=num;
	if(head==NULL)
	{
		ptr->link=head=ptr;
		return;
	}
        ptr->link=head;
	temp=head;
	while(temp->link!=head)
		temp=temp->link;
        temp->link=head=ptr;
}

void delatbegn()
{
        struct node *temp;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
	if(head->link==head)
	{
		free(head);
		head=NULL;
		return;
	}
        temp=head;
	while(temp->link!=head)
		temp=temp->link;
        temp->link=head->link;
	free(head);
        head=temp->link;
}

void display(struct node * head1)
{
        struct node *temp;
        if(head1 == NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return;
        }
        printf("\nThe data : \n");
	temp=head1;
	do
        {
                printf("%-15p  --  %-15p  --  %d \n",temp,temp->link,temp->data);
                temp=temp->link;
        }
        while(temp!=head1);
}

int cnt_nodes()
{
        struct node *ptr;
        int cnt=0;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return 0;
        }
        ptr=head;
	do
        {
                cnt++;
                ptr=ptr->link;
        }
        while(ptr!=head);
        return (++cnt);
}

int search_data(int num)
{
        struct node *ptr;
        int cnt=0;
        if(head==NULL)
        {
                printf("\n\tthe list is empty \n\n");
                return -1;
        }
        ptr=head;
        while(ptr->link!=head)
        {
                cnt++;
                if((ptr->data)==num)
                        return cnt;
                ptr=ptr->link;
        }
	if(ptr->data==num)
		return (++cnt);
        return 0;
}

void delete_list()
{
        struct node *ptr,*temp;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return ;
        }
	ptr=head;
        while(ptr->link!=head)
        {
                temp=ptr->link;
                free(ptr);
                ptr=temp;
        }
	free(ptr);
        head=NULL;
        printf("\n\tthe list is deleted\n\n");
}

struct node* create_list(struct node *head1,int *iptr,int n)
{
        int i;
        struct node *prev,*start=NULL,*temp,*ptr;
        for(i=0;i<n;i++)
        {
                ptr=(struct node *)malloc(1*sizeof(struct node));
                if(ptr==NULL)
                {
                        printf("\n\tfailed to allocate memory\n\n");
                        exit(-1);
                }
                ptr->data=iptr[i];
                if(start==NULL)
                {
                        start=ptr;
                }
                else
                        prev->link=ptr;
                prev=ptr;
        }
        if(head1==NULL)
        {
                head1=ptr->link=start;
                return head1;
        }
        temp=head1;
        while(temp->link!=head1)
        {
                temp=temp->link;
        }
        temp->link=start;
	ptr->link=head1;
        return head1;
}

void del_at_last()
{
        struct node *prev,*cur;
        if(head==NULL)
        {
                printf("\n\tThe list is empty \n\n");
                return;
        }
        if(head->link==head)
        {
                free(head);
                head=NULL;
                return;
        }
        prev=head;
        cur=head->link;
        while(cur->link!=head)
        {
                prev=cur;
                cur=cur->link;
        }
        free(cur);
        prev->link=head;
}

void add_at_last(int num)
{
        struct node *ptr,*temp;
        ptr=(struct node *)malloc(1*sizeof(struct node));
        if(ptr==NULL)
        {
                printf("\n\tfailed to alloc the memory in heap\n\n");
                exit(-1);
        }
        ptr->data=num;
        if(head==NULL)
        {
                head=ptr->link=ptr;;
                return;
        }
        temp=head;
        while(temp->link!=head)
        {
                temp=temp->link;
        }
        temp->link=ptr;
	ptr->link=head;
        return;
}

void swap_nodes(int num,int val)
{
        struct node *c1,*p1,*c2,*p2,*temp;
        int pos1,pos2,flag1=0,flag2=0;
        pos1=pos2=0;
        if(num==val)
                return;
        if(head==NULL)
        {
                printf("\n\tthe lsit is empty\n\n");
                return;
        }
	if(head->link==head)
		return;
        c1=c2=head;
	do
        {
                pos1++;
                if(c1->data==num)
		{
			flag1=1;
                        break;
		}
                p1=c1;
                c1=c1->link;
        }
	while(c1!=NULL);
	do
        {
                pos2++;
                if(c2->data==val)
		{
			flag2=1;
                        break;
		}
                p2=c2;
                c2=c2->link;
        }
        while(c2!=head);
        if((flag1!=1)||(flag2!=1))
        {
                printf("\n\tdata not found \n\n");
                return;
        }
        if(pos1>pos2)
        {
                temp=c1;
                c1=c2;
                c2=temp;
                temp=p1;
                p1=p2;
                p2=temp;
        }
	if(c1->link!=c2)
        {
                if(head!=c1)
                {
                        p1->link=c2;
                }
                else
		{
			temp=head;
			while(temp->link!=head)
				temp=temp->link;
			temp->link=c2;
			head=c2;
		}
		temp=c1->link;
		c1->link=c2->link;
		c2->link=temp;
		p2->link=c1;
	}
	else
        {
                if(head!=c1)
                {
                        p1->link=c2;
                }
                else
                {
			temp=head;
			while(temp->link!=head)
				temp=temp->link;
			temp->link=c2;
                        head=c2;
                }
                temp=c2->link;
                c2->link=c1;
                c1->link=temp;
                return;
        }
}

struct node* selection_sort(struct node *head1)
{
        struct node *main,*prev1,*prev2,*cur1,*cur2,*temp;
        if(head1==NULL)
        {
                printf("\n\tthe queue is empty\n\n");
                return NULL;
        }
        if(head1->link==NULL)
                return head1;
        for(prev1=cur1=head1;cur1->link!=head1;prev1=cur1,cur1=cur1->link)
        {
                for(prev2=cur2=cur1->link;cur2!=head1;prev2=cur2,cur2=cur2->link)
                {
                        if(cur1->data>cur2->data)
                        {
                                if(cur1->link!=cur2)
                                {
                                        if(head1==cur1)
					{
						temp=head1;
						while(temp->link!=head1)
							temp=temp->link;
						temp->link=cur2;
						head1=cur2;
					}
                                        else
                                                prev1->link=cur2;
                                        temp=cur2->link;
                                        cur2->link=cur1->link;
                                        cur1->link=temp;
                                        prev2->link=cur1;
                                }
				else
                                {
					if(head1==cur1)
					{
						temp=head1;
						while(temp->link!=head1)
							temp=temp->link;
						temp->link=cur2;
						head1=cur2;
					}
					else
						prev1->link=cur2;
                                        temp=cur2->link;
                                        cur2->link=cur1;
					cur1->link=temp;
				}
				temp=cur1;
				cur1=cur2;
				cur2=temp;
			}
		}
	}
	return head1;
}

struct node * bubble_sort(struct node *head1)
{
	struct node *main1,*cur1,*cur2,*prev1,*temp;
	if(head1==NULL)
	{
		printf("\n\tthe queue is empty\n\n");
		return NULL;
	}
	if(head1->link==head1)
		return head1;
	for(main1=head1;main1!=head1->link;main1=cur1)
	{
		for(cur1=cur2=head1;cur1->link!=main1;prev1=cur1,cur1=cur1->link)
		{
			cur2=cur1->link;
			if(cur1->data>cur2->data)
			{
				if(head1==cur1)
				{
					temp=head1;
					while(temp->link!=head1)
						temp=temp->link;
					temp->link=cur2;
					head1=cur2;
					main1=head1;
				}
				else
					prev1->link=cur2;
				temp=cur2->link;
				cur2->link=cur1;
				cur1->link=temp;
			temp=cur1;
			cur1=cur2;
			cur2=temp;
			}
		}
	}

	return head1;
}



int main()
{
	int opt,dum,num,n,nodes,i,snum;
	int *ptr;
	while(1)
	{
		printf("\n\t*****  menu  *****\n0 -exit \n1 -creating the circular list \n2 -adding the node at beginning \n3 -deleting the node at beginning \n4 -displaying the data in nodes \n5 -count the nodes \n6 -search the data \n7 -delete the list \n8 -delete at last node \n9 -add the node at last \n10-add the node after selected node\n11-add the node before selected node \n12-delete purticular node \n13-reverse the list \n14-swaping the seleted nodes \n15-delete duplicate nodes\n16-merge sort \n17-selection sorting \n18-bubble sorting\n\nselect the option : ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case -1:
				system("clear");
				break;
			case 0:
				printf("\n\tthe sucessfull termination of program\n\n");
				exit(0);
			case 1:
				printf("enter the no of nodes :");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int *)malloc(n*sizeof(int));
				if(ptr==NULL)
				{
					printf("\n\tfailed to allocate memory\n\n");
					exit(0);
				}
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					scanf("%d",&ptr[i]);
				}
				head=create_list(head,ptr,n);
				free(ptr);
				break;

			case 2:
				printf("\n\nenter the data :");
				__fpurge(stdin);
				scanf("%d",&num);
				addatbegn(num);
				break;
			case 3:
				delatbegn();
				break;
			case 4:
				display(head);
				break;
			case 5:
				dum=cnt_nodes();
				if(dum>0)
					printf("\n\nthe nodes present is/are :%d\n\n",dum);
				break;
			case 6:
				printf("\n\nenter the data to search :");
				__fpurge(stdin);
				scanf("%d",&num);
				dum=search_data(num);
				if(dum>0)
					printf("\n\nthe %d is present in the %d node \n\n",num,dum);
				else if(dum==0)
					printf("\n\nthe given no %d is not found\n\n",num);
				break;
			case 7:
				delete_list();
				break;
			case 8:
				del_at_last();
				break;
			case 9:
				printf("\n\nenter the data :");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_last(num);
				break;
			case 14:
				printf("enter the data that to be swap :");
				__fpurge(stdin);
				scanf("%d%d",&num,&dum);
				swap_nodes(num,dum);
                                break;
                        case 17:
                                head=selection_sort(head);
                                break;
                        case 18:
                                head=bubble_sort(head);
                                break;
   /*                     case 10:
                                printf("\n\nenter the data to data to be search and to be add : ");
                                __fpurge(stdin);
                                scanf("%d%d",&snum,&num);
                                add_after_node(snum,num);
                                break;
                        case 11:
                                printf("\n\nenter the data to data to be search and to be add : ");
                                __fpurge(stdin);
                                scanf("%d%d",&snum,&num);
                                add_before_node(snum,num);
                                break;
                        case 12:
                                printf("\n\nenter the data :");
                                __fpurge(stdin);
                                scanf("%d",&num);
                                delete_node(num);
                                break;
                        case 13:
                                reverse_list();
                                break;
                        case 15:
                                delete_duplicate_nodes();
                                break;
          case 16:
                                well=NULL;done=NULL;
                                printf("enter the no of nodes :");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int *)malloc(n*sizeof(int));
                                if(ptr==NULL)
                                {
                                        printf("\n\tfailed to allocate memory\n\n");
                                        exit(0);
                                }
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                well=create_list(well,ptr,n);
                                well=selection_sort(well);
                        //      display(well);
                                printf("enter the no of nodes :");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                __fpurge(stdin);
                                ptr=(int *)malloc(n*sizeof(int));
                                if(ptr==NULL)
                                {
                                        printf("\n\tfailed to allocate memory\n\n");
                                        exit(0);
                                }
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        __fpurge(stdin);
                                        scanf("%d",&ptr[i]);
                                }
                                done=create_list(done,ptr,n);
                                done=selection_sort(done);
                        //      display(done);
                                merge_sort();
                                display(res);
                                break;
*/                        default:
                                printf("\n\tEnter the valid option\n\n");
                }
        }
}

