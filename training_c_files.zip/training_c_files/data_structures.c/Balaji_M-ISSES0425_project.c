//    ******************   priority queue program   **************************
#include<stdio_ext.h>
#include<stdlib.h>
struct miss_es_0425_node
{
	struct miss_es_0425_node *prev;
	int prior;
	int data;
	struct miss_es_0425_node *next;
};

struct miss_es_0425_node *head=NULL;

// ************************  display over all data  *********************
void display()
{
	struct miss_es_0425_node *temp;
	if(head==NULL)                                   // checking the list is empty
	{
		printf("\n\t the list is empty \n\n");
		return;
	}
	temp=head;
	printf("\t\t\t\t\t\t\t\tpriority    :      data\n\n");
	while(temp!=NULL)   
	{
		printf(" %-14p  --  %-14p  --  %-14p  --       %-5d    --       %-5d  \n",temp->prev,temp,temp->next,temp->prior,temp->data);
		temp=temp->next;
	}
}

//  **********************   display the data in selected priority   *************
void display_prior( int priority)
{
	struct miss_es_0425_node *temp;
	int count=0;
	if(head==NULL)                                    // checking the list is empty 
	{
		printf("\n\t the list is empty \n\n");
		return;
	}
	temp=head;
	printf("\t\t\t\t\t\t\t\tpriority    :      data\n\n");
	while(temp!=NULL)
	{
		if(temp->prior==priority)                 // checking the nodes priority with given priority
		{
			count=1;
			printf(" %-14p  --  %-14p  --  %-14p  --       %-5d    --       %-5d  \n",temp->prev,temp,temp->next,temp->prior,temp->data);
		}
		temp=temp->next;
	}
	if(count==0)
		printf("\n\tthe priority was not found to display \n\n");
}

//  ****************************  insert function   ****************************
void insert(int pri,int num)
{
	struct miss_es_0425_node *temp,*ptr;
	if(pri<=0)                                         // checking the priority not be negitive values
	{
		printf("\n\nthe priority value should not be negitive and zero\n\n");
		return;
	}
	ptr=(struct miss_es_0425_node *)malloc(1*sizeof(struct miss_es_0425_node));
	if(ptr==NULL)
	{
		printf("\n\t failed to allocate memory\n\n");
		return ;
	}
	ptr->data =num;
	ptr->prior=pri;
	if(head==NULL)                                       // checking it be the first node
	{
		ptr->prev=ptr->next=head;
		head=ptr;
		return;
	}
        temp=head;
	while(temp!=NULL)
	{
		if(temp->prior > pri)                       // checking the node priority greaterr than the given priority
		{
			if(temp->prev!=NULL)                // checking it not be the first node
			{
				ptr->prev=temp->prev;
				temp->prev->next=ptr;
			}
			else
			{
				ptr->prev=NULL;
				head=ptr;
			}
			ptr->next=temp;
			temp->prev=ptr;
			return;
		}
		if(temp->next==NULL)                        // checking that this be the last node
		{
			ptr->next=NULL;
			ptr->prev=temp;
			temp->next=ptr;
			return;
		}
		temp=temp->next;
	}
}

// ******************  create list functin  ******************
void create_list(int *arr,int num)
{
	struct miss_es_0425_node *temp,*ptr;
	int i;
	for(i=0;i<num;i=i+2)
	{
		if(arr[i]<=0)                              //  checking the given priorities not be negitive values
		{
			printf("\n\nthe priority value should not be negitive and zero\n\n");
			continue;
		}
		ptr=(struct miss_es_0425_node *)malloc(1*sizeof(struct miss_es_0425_node));
		if(ptr==NULL)                             
		{
			printf("\n\t failed to allocate memory\n\n");
			return ;
		}
		ptr->prior=arr[i];
		ptr->data =arr[i+1];
		if(head==NULL)                              // checking  the list is empty
		{
			ptr->prev=ptr->next=head;
			head=ptr;
			continue;
		}
		temp=head;
		while(temp!=NULL)
		{
			if(temp->prior > arr[i])           //  checking the node priority is greater the the given priority
			{
				if(temp->prev!=NULL)       // checking that this is not the first node
				{
					ptr->prev=temp->prev;
					temp->prev->next=ptr;
				}
				else
				{
					ptr->prev=NULL;
					head=ptr;
				}
				ptr->next=temp;
				temp->prev=ptr;
				break;
			}
			if(temp->next==NULL)             //  checking this will be the last node
			{
				ptr->next=NULL;
				ptr->prev=temp;
				temp->next=ptr;
				break;
			}
			temp=temp->next;
		}
	}
}
			
//**************  delete the over all data in list  ******************
void delete()
{
	struct miss_es_0425_node *temp;
	if(head==NULL)                                   // checking the list is empty
	{
		printf("\n\t the list is empty\n\n");
		return;
	}
	while(head!=NULL)                                 // traversing to last node to delete all the nodes
	{
		temp=head;
		head=head->next;
		free(temp);
	}
}

//***************   delete the selected priority  *********************
void delete_prior(int priority)
{
	struct miss_es_0425_node *temp,*ptr;
	int count=0;
	if(head==NULL)                                   // checking the list is empty
	{
		printf("\n\t the list is empty\n\n");
		return;
	}
	temp=head;                        
	while(temp!=NULL)                   
	{
		if(temp->prior==priority)               // checking the priority  is equal to the given priority
		{
			count++;
			ptr=temp->next;
			if(temp->prev!=NULL)            // checking this not be the first node
			     temp->prev->next=temp->next;
			else
				head=temp->next;
			if(temp->next!=NULL)           // checking this not be the last node
				temp->next->prev=temp->prev;
			temp=ptr;
		}
		else
			temp=temp->next;
	}
	if(count==0)                                    // checking that given data not found
		printf("\n\tthe priority was not found to delete \n\n");
}

//***************** delete the selected data and priority *****************
void delete_prior_data(int priority, int num)
{
	struct miss_es_0425_node *temp,*ptr;
	if(head==NULL)                           // checking the list is empty
	{
		printf("\n\t the list is empty\n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->prior==priority&&temp->data==num)     //checking both priority and data with given data
		{
			ptr=temp->next;
			if(temp->prev!=NULL)                  // checking it is first node
			     temp->prev->next=temp->next;
			else                                  
				head=temp->next;
			if(temp->next!=NULL)                  // checking it is not the last node
				temp->next->prev=temp->prev;
			temp=ptr;
			return;
		}
		else
			temp=temp->next;
	}
	printf("\n\tthe priority or data was not found to delete \n\n");
}

//****************  delete the first node in selected priority ************
void delete_prior_pop(int priority)
{
	struct miss_es_0425_node *temp,*ptr;
	int count=0;
	if(head==NULL)                              //  checking the list is empty
	{
		printf("\n\t the list is empty\n\n");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->prior==priority)            // checking the priority with given priority
		{
			count++;
			ptr=temp->next;
			if(temp->prev!=NULL)        // checking it is not the first node 
			     temp->prev->next=temp->next;
			else                        // else this is first node
				head=temp->next;
			if(temp->next!=NULL)         // checking its not the last node
				temp->next->prev=temp->prev;
			temp=ptr;
			return;
		}
		else
			temp=temp->next;
	}
	if(count==0)
		printf("\n\tthe priority was not found to delete \n\n");
}
//********************    sort the data by link   ***********************
void sort_link()
{
	struct miss_es_0425_node *cur1,*cur2,*temp;
	if(head==NULL)                                         // checking the list is empty 
	{
		printf("\n\t the list is empty \n\n");
		return;
	}
	for(cur1=head;cur1!=NULL;cur1=cur1->next)
	{
		for(cur2=cur1->next;(cur2!=NULL)&&(cur2->prior==cur1->prior);cur2=cur2->next)
		{
			if(cur1->data > cur2->data)           //condition for checking the present and next data
			{
				if(cur1->prev!=NULL)   
					cur1->prev->next=cur2;
				else
					head=cur2;
				if(cur2->next!=NULL)
					cur2->next->prev=cur1;
				if(cur1->next!=cur2)          // condition for non adjaccent nodes 
				{
					cur1->next->prev=cur2;
					cur2->prev->next=cur1;
					temp=cur1->prev;
					cur1->prev=cur2->prev;
					cur2->prev=temp;
					temp=cur1->next;
					cur1->next=cur2->next;
					cur2->next=temp;
				}
				else                             // for adjacent nodes
				{
					cur2->prev=cur1->prev;
					cur1->next=cur2->next;
					cur2->next=cur1;
					cur1->prev=cur2;
				}
				temp=cur1;                        // swaping the position to privious 
				cur1=cur2;
				cur2=temp;
			}
		}
	}
}

//******************  sorting the data by swapping data  ********************
void sort_data()
{
	struct miss_es_0425_node *cur1,*cur2;
	int temp;
	if(head==NULL)                                         // checking the list is empty
	{
		printf("\n\t the list is empty \n\n");
		return;
	}
	for(cur1=head;cur1!=NULL;cur1=cur1->next)
	{
		for(cur2=cur1->next;(cur2!=NULL)&&(cur2->prior==cur1->prior);cur2=cur2->next)
		{
			if(cur1->data > cur2->data)            // checking the cur data is greater than the next node data
			{
				temp=cur1->data;
				cur1->data=cur2->data;
				cur2->data=temp;
			}
		}
	}
}

//******************************  main function    *************************
int main()
{
	int var1,var2,num,opt,sub,i;
	int *arr;
	while(1)
	{
		printf("\n\t >>>>>>>>>>  Menu  <<<<<<<<<<\n\n 0 - Exit \n 1 - Insert \n 2 - Display over all list \n 3 - Display the purticular priority \n 4 - Create list \n 5 - Delete the over all list \n 6 - Delete the entire priority nodes \n 7 - Delete the selected priority and data \n 8 - Delete the selected priority first node \n 9 - Sort by link \n 10- Sort by data \n\n Select the option ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case 0 :
				printf("\n\t the successfull termination \n\n");
				exit(0);
			case 1:
				printf(" Enter the priority : ");
				__fpurge(stdin);
				scanf("%d",&var1);
				printf(" Enter the data : ");
				__fpurge(stdin);
				scanf("%d",&var2);
				insert(var1,var2);
				break;
			case 2: 
				display();
				break;
			case 3:
				printf("\n Enter the priority : ");
				__fpurge(stdin);
				scanf("%d",&var1);
				display_prior(var1);
				break;
			case 4:
				printf("\n Enter the no of node to add : ");
				__fpurge(stdin);
				scanf("%d",&num);
				arr=(int*)malloc(num*2*sizeof(int));
				if(arr==NULL)
				{
					printf("\n\t failed to allocate memory \n\n");
					return -1;
				}
				for(i=0;i<num*2;i=i+2)
				{
					printf(" Enter the priority : ");
					__fpurge(stdin);
					scanf("%d",&arr[i]);
					printf(" Enter the data : ");
					__fpurge(stdin);
					scanf("%d",&arr[i+1]);
				}
				create_list(arr,num*2);
				free(arr);
				break;
			case 5:
				delete();
				break;
			case 6:
				printf(" Enter the priority : ");
				__fpurge(stdin);
				scanf("%d",&var1);
				delete_prior(var1);
				break;
			case 7:
				printf(" Enter the priority : ");
				__fpurge(stdin);
				scanf("%d",&var1);
				printf(" Enter the data : ");
				__fpurge(stdin);
				scanf("%d",&var2);
				delete_prior_data(var1,var2);
				break;
			case 8:
				printf(" Enter the priority : ");
				__fpurge(stdin);
				scanf("%d",&var1);
				delete_prior_pop(var1);
				break;
			case 9:
				sort_link();
				break;
			case 10:
				sort_data();
				break;
			default:
				printf("\n\t select the valid option\n\n");
		}
	}
}
//********************************   End  ************************************
