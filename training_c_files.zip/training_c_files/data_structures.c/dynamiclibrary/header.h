#include<stdio_ext.h>
#include<stdlib.h>
struct node
{
        int data;
        struct node *link;
};
//struct node *head=NULL;
void create_list(int *,int);
void addatbegn(int );
void delatbegn();
void display();
int cnt_nodes();
int search_data(int);
void delete_list();
void del_at_last();
void add_at_last(int);
void add_after_node(int, int);
void add_before_node(int, int);
void delete_node(int);
void reverse_list();
void swap_nodes(int, int);

