
extern struct node *head;
#include"header.h"
#include<stdio_ext.h>
#include<stdlib.h>
void create_list(int *iptr,int n)
{
        int i;
        struct node *prev,*start=NULL,*temp;
        for(i=0;i<n;i++)
        {
                struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
                if(ptr==NULL)
                {
                        printf("\n\tfailed to allocate memory\n\n");
                        exit(-1);
                }
                ptr->data=iptr[i];
                ptr->link=NULL;
                if(start==NULL)
                {
                        start=ptr;
                }
                else
                        prev->link=ptr;
                prev=ptr;
        }
        if(head==NULL)
        {
                head=start;
                return;
        }
        temp=head;
        while(temp->link!=NULL)
        {
                temp=temp->link;
        }
        temp->link=start;
}

