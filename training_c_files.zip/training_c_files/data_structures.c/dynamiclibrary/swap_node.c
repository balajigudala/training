
#include"header.h"
#include<stdio_ext.h>
#include<stdlib.h>
extern struct node *head;
void swap_nodes(int num1,int num2)
{
        struct node *cur1,*cur2,*prev1,*prev2,*temp;
        int pos1,pos2;
        pos1=pos2=0;
        if(num1==num2)
                return;
        if(head==NULL)
        {
                printf("\n\tthe list is empty\n\n");
                return;
        }
        cur1=cur2=head;
        while(cur1!=NULL)
        {
                pos1++;
                if(cur1->data==num1)
                        break;
                prev1=cur1;
                cur1=cur1->link;
        }
        while(cur2!=NULL)
        {
                pos2++;
                if(cur2->data==num2)
                        break;
                prev2=cur2;
                cur2=cur2->link;
        }
        if((cur1==NULL)||(cur2==NULL))
        {
                printf("\n\tthe data not found\n\n");
                return;
        }
        if(pos1>pos2)
        {
                temp=cur1;
                cur1=cur2;
                cur2=temp;
                temp=prev1;
                prev1=prev2;
                prev2=temp;
        }
        if(cur1->link!=cur2)
        {
                temp=cur1->link;
                cur1->link=cur2->link;
                cur2->link=temp;
                prev2->link=cur1;
                if(head!=cur1)
                        prev1->link=cur2;
                else
                        head=cur2;
                return;
        }
        else
        {
                temp=cur2->link;
                cur2->link=cur1;
                cur1->link=temp;
                if(head!=cur1)
                        prev1->link=cur2;
                else
                        head=cur2;
                return;
        }
}

