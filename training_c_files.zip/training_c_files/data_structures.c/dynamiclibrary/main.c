
#include"header.h"
struct node *head=NULL;
/*#include<stdio_ext.h>
#include<stdlib.h>
struct node
{
        int data;
        struct node *link;
};
struct node *head=NULL;
void create_list(int *,int);
void addatbegn(int );
void delatbegn();
void display();
int cnt_nodes();
int search_data(int);
void delete_list();
void del_at_last();
void add_at_last(int);
void add_after_node(int, int);
void add_before_node(int, int);
void delete_node(int);
void reverse_list();
void swap_nodes(int, int);
*/
int main()
{
        int opt,dum,num,n,nodes,i,snum;
        int *ptr;
        while(1)
        {
                printf("\n\t*****  menu  *****\n0 -exit \n1 -creating the list \n2 -displaying the data in nodes\n3 -delete purticular node \n4 -swaping the seleted nodes \n\nselect the option : ");
                __fpurge(stdin);
                scanf("%d",&opt);
                switch(opt)
                {
                        case 0:
                                printf("\n\tthe sucessfull termination of program\n\n");
                                exit(0);
                        case 1:
                                printf("enter the no of nodes :");
                                __fpurge(stdin);
                                scanf("%d",&n);
                                ptr=(int *)malloc(n*sizeof(int));
                                if(ptr==NULL)
                                {
                                        printf("\n\tfailed to allocate memory\n\n");
                                        exit(0);
                                }
                                for(i=0;i<n;i++)
                                {
                                        printf("enter the data : ");
                                        scanf("%d",&ptr[i]);
                                }
                                create_list(ptr,n);
                                free(ptr);
                                break;
                        case 2:
                                display();
                                break;
                        case 3:
                                printf("\n\nenter the data to erase : ");
                                scanf("%d",&num);
                                delete_node(num);
                                break;
                        case 4:
                                printf("\n\nenter the data to be swap : ");
                                scanf("%d%d",&num,&dum);
                                swap_nodes(num,dum);
                                break;
                        default :
                                printf("\n\tinvalid ooption\n\n");
                }
        }
}
