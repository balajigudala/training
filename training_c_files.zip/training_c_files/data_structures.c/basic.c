#include<stdio.h>
int main()
{
      char x=129;
      printf("%d",x);
}

