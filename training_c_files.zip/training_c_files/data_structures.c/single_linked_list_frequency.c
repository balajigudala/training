#include<stdio_ext.h>
#include<string.h>
#include<stdlib.h>
#pragma pack(1)
struct node
{
	int data;
	int freq;
	struct node *link;
};
struct node *head1=NULL;
struct node * create_list(struct node *,int *,int);
void display(struct node*);
void add_at_last();
void del_at_last();
int main()
{
	int opt,dum,num,n,nodes,i,snum;
	int *ptr;
	while(1)
	{
		printf("\n\t*****  menu  *****\n0 -exit \n1 -creating the list \n2 -adding the node at last \n3 -deleting the node at last  \n4 -display \n\n5 -select the option ");
		__fpurge(stdin);
		scanf("%d",&opt);
		switch(opt)
		{
			case 0:
				printf("\n\tthe sucessfull termination of program\n\n");
				exit(0);
			case 1:
				printf("enter the no of nodes :");
				__fpurge(stdin);
				scanf("%d",&n);
				ptr=(int *)malloc(n*sizeof(int));
				if(ptr==NULL)
				{
					printf("\n\tfailed to allocate memory\n\n");
					exit(0);
				}
				for(i=0;i<n;i++)
				{
					printf("enter the data : ");
					scanf("%d",&ptr[i]);
				}
				head1=create_list(head1,ptr,n);
				free(ptr);
				break;
			case 2:
				printf("\n\nenter the data :");
				__fpurge(stdin);
				scanf("%d",&num);
				add_at_last(num);
				break;
			case 3:
				del_at_last();
				break;
			case 4:
				display(head1);
				break;
		//	case 8:
		//		del_at_last();
		//		break;

		}
	}
}





struct node* create_list(struct node *head1,int *iptr,int n)
{
	int i,j,num,count;
	struct node *prev,*start=NULL,*temp;
	for(i=0;i<n;i++)
	{
		struct node *ptr=(struct node *)malloc(1*sizeof(struct node));
		if(ptr==NULL)
		{
			printf("\n\tfailed to allocate memory\n\n");
			exit(-1);
		}
		ptr->data=iptr[i];
		ptr->link=NULL;
		if(start==NULL)
		{
			ptr->freq=0;
			start=ptr;
		}
		else
		{
			count=0;
			num=iptr[i];
			for(j=0;j<=i;j++)
			{
				if(iptr[j]==num)
					count++;
			}
			ptr->freq=--count;
			prev->link=ptr;
		}
		prev=ptr;
	}
	if(head1==NULL)
	{
		head1=start;
		return head1;
	}
	temp=head1;
	while(temp->link!=NULL)
	{
		temp=temp->link;
	}
	temp->link=start;
	return head1;
}
void display(struct node *head1)
{
	struct node *ptr;
	if(head1 == NULL)
	{
		printf("\n\tthe list is empty \n\n");
		return;
	}
	ptr=head1;
	printf("\nThe data : ");
	while(ptr!=NULL)
	{
		printf("data is %d and freq is %d \n",ptr->data,ptr->freq);
		ptr=ptr->link;
	}
	printf("\n\n");
}
void add_at_last(int num)
{
	struct node *ptr,*temp;
	int count=0;
	ptr=(struct node *)malloc(1*sizeof(struct node));
	if(ptr==NULL)
	{
		printf("\n\tfailed to alloc the memory in heap\n\n");
		exit(-1);
	}
	ptr->data=num;
	ptr->link=NULL;
	if(head1==NULL)
	{
		ptr->freq=0;
		head1=ptr;
		return;
	}
	if(head1->link==NULL)
	{
		if(head1->data==num)
			count++;
		head1->freq=count;
		head1->link=ptr;
		return;
	}
	temp=head1;
	while(temp->link!=NULL)
	{
		if(temp->data==num)
			count++;
		temp=temp->link;
	}
	if(temp->data==num)
		count++;
	ptr->freq=count;
	temp->link=ptr;
	return;
}
void del_at_last()
{
	struct node *prev,*cur;
	if(head1==NULL)
	{
		printf("\n\tThe list is empty \n\n");
		return;
	}
	if(head1->link==NULL)
	{
		free(head1);
		head1=NULL;
		return;
	}
	prev=head1;
	cur=prev->link;
	while(cur->link!=NULL)
	{
		prev=cur;
		cur=cur->link;
	}
	free(cur);
	prev->link=NULL;
}
