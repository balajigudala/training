// calling predefined function with function pointer  //
#include<stdio.h>
int main()
{
	int n=20;
//	char arr[10]="%d\n";
	int(*fprint)(char*,...);
	fprint=printf;
	fprint("%d\n",n);
}

