/**************************** string comparision **************************/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdio_ext.h>
int strlen1(char *);
void inttoascii(char *,int);
void strpldm(char *);
void charrptd(char *);
char* strcnctn(char*,char*,char*);
int searchstring(char *,char*);
int main()
{
        int num,opt;
        while(1)
        {
                printf("\n\t\tmenu of operations \n0-Exit \n1-int to ascii \n2-string palindrome \n3-count no of repeted character in a string \n4-string concatination \n5-Searching string in a statement \nSelect the option to perform operation : ");
        char arr[50]={'\0'},arr1[50]={'\0'},arr2[100]={'\0'};
                scanf("%d",&opt);
                switch(opt)
                {
                        case 0:
                                exit(0);
                        case 1:
                               printf("\nenter the number : ");
                               scanf("%d",&num);
			       void (*fptr)(char *,int);
			       fptr=inttoascii;       
                               fptr(arr,num);
                               printf("\nchar : %s\n",arr);
                               break;
                        case 2:
                               printf("\nenter the string : ");
                               scanf("%s",arr);
                               void (*pldmptr)(char*);
                               pldmptr=strpldm;
                               pldmptr(arr);
                               break;
                        case 3:
                               printf("\nenter the string : ");
                               scanf("%s",arr);
			       void(*rptdptr)(char*);
                               rptdptr=charrptd;
                               rptdptr(arr);
                               break;
                        case 4:
                               printf("\nentr the two strings : ");
                               scanf("%s",arr);
                               __fpurge(stdin);
                               scanf("%s",arr1);
			       char* (*cnctnptr)(char *,char *,char *);
			       cnctnptr=strcnctn;
                               cnctnptr(arr,arr1,arr2);
                               printf("\n%s",arr2);
                               break;
                        case 5:
                               printf("\nenter the statement : ");
                               __fpurge(stdin);
                               scanf("%[^\n]",arr);
                               __fpurge(stdin);
                               printf("\nenter the string : ");
                               scanf("%s",arr1);
			       int(*srchptr)(char*,char*);
			       srchptr=searchstring;
                               srchptr(arr,arr1);
                               break;
                        default:
                               printf("\n\t\tInvalid option '_'  \n\n");
                }
        }
}
/************************** string length ***********************/
int strlen1(char *ptr)
{
        int i;
        if(ptr==NULL)
                return 0;
        for(i=0;ptr[i]!='\0';i++);
        return i;
}
/*********************** integer to ascii char ******************/
void inttoascii(char*ptr,int num)
{
        int rem,res=0,temp,i,j;
        if(ptr==NULL)
                return;
        for(temp=num;temp!=0;i++)
        {
                rem=temp%10;
                temp=temp/10;
                res=rem+(res*10);
        }
        for(temp=res,rem=0,j=0;temp!=0;j++)
        {
                rem=temp%10;
                temp=temp/10;
                rem=rem+48;
                ptr[j]=rem;
        }
}
/************************ string palindrome *********************/
void strpldm(char *ptr)
{
        int i=0,j;
        if(ptr==NULL)
                return;
	int(*strlenptr)(char*);
	strlenptr=strlen1;
        j=strlenptr(ptr);
        for(i=0,j=(j-1);i<=(j/2);i++)
        {
                if(ptr[i]!=ptr[j-i])
                {
                        printf("\nGiven string is not palindrome\n");
                        return;
                }
        }
        printf("\nGiven string is palindrome\n");
}
/********************* count of char in a string ***************/
void charrptd(char *ptr1)
{
        int i,j,count;
        if(ptr1==NULL)
                return;
        char *arr1=ptr1;
        for(i=0;arr1[i]!='\0';i++)
        {
                if(arr1[i]==1)
                {
                        continue;
                }
                count=1;
                for(j=i+1;arr1[j]!='\0';j++)
                {
                        if(arr1[i]==arr1[j])
                        {
                                count++;
                        arr1[j]=1;
                        }

                }
                if(count==1)
                {
                        printf("%c=1\n",arr1[i]);
                        continue;
                }
                printf("%c=%d\n",arr1[i],count);
        }

}
/********************** string concatination ********************/
char* strcnctn(char *ptr1,char *ptr2,char *ptr3)
{
        int k,l=0,j;
        if((ptr1==NULL)&&(ptr2==NULL)&&(ptr3==NULL))
                return NULL;
        {
                for(k=0;ptr1[k]!='\0';k++)
                {
                        ptr3[k]=ptr1[k];
                        l++;
                }
                for(j=0,k=l;ptr2[j]!='\0';j++,k++)
                {
                        ptr3[k]=ptr2[j];
                }
        }
        return ptr3;
}
/********************* searching string *************************/
int searchstring(char*arr,char *arr1)
{
        int j,i,k,count=0;
        if((arr==NULL)&&(arr1==NULL))
                return 1;
        k=strlen1(arr1);
        for(i=0,j=0;arr[i]!='\0';i++)
        {
                if(arr[i]==' ')
                        continue;
                if(arr[i]!=arr1[j])
                {
                        j=0;count=0;
                        continue;
                }
                j++;
                count++;
                if(count==(k))
                {
                        printf("\ngiven string is present in statement\n");
                        return 1;
                }
        }
        printf("\ngiven string is not present in statement\n");
}
/***************************** end ******************************/
