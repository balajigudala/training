#include<stdio.h>
#include<stdio_ext.h>
void display(int*,int,int(*fptr)(char*,...));
int main()
{
	int n,i;
	printf("enter the no of elements : ");
	scanf("%d",&n);
        int (*sptr)(char*,...);
        sptr=&scanf;
	int arr1[n];
	for(i=0;i<n;i++){
	__fpurge(stdin);
	sptr("%d",&arr1[i]);}
	void (*dspl)(int *,int,int(*fptr)(char*,...));
	dspl=&display;
	dspl(arr1,n,printf);
}
void display(int *arr2, int n,int(*fptr)(char*,...))
{
	int i;
	for(i=0;i<n;i++){
	fptr("%d ",arr2[i]);}
}

