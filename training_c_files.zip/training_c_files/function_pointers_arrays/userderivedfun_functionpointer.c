#include<stdio.h>
int count(int);
int main()
{
	int num;
	scanf("%d",&num);
	int (*count1)(int);
	count1=count;
	printf("%d",	count1(num));
}
int count(int n1)
{
	int rem,c;
	if(n1==0)
	{
		c=1;
		return 1;
	}
	for(c=0;n1!=0;n1=n1/10)
	{
		c++;
	}
	return c;
}

