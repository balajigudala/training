#include<stdio.h>
sub(int,int);
int main()
{
	int res,num1,num2;
	printf("enter the two numbers : ");
	scanf("%d %d",&num1,&num2);
	int (*fptr)(int,int);
	fptr=&sub;
	res=fptr(num1,num2);
	//res=sub(num1,num2);
	printf("result = %d",res);
}
sub(int n1,int n2)
{
	return (n1-n2);
}
