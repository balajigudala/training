#include<stdio_ext.h>
#include<unistd.h>
#include<string.h>
int main()
{
	int res ,res2, fd[2],fd2[2];
	pid_t pid;
	res2=pipe(fd2);
	res = pipe(fd);
	if(res<0||res2<0)
	{
		printf("the pipe sys call is failed \n");
		return -1;
	}
	res = fork();
	if(res<0)
	{
		printf("the pipe sys call is failed \n");
		return -1;
	}
	if(res==0)
	{
		char buff[5],ruff[50];
		int ret;
	//	close(fd[1]);
	//	close(fd2[0]);
		while(1)
		{
			while(ret=read(fd[0],buff,5))
			{
				write(1,buff,ret);
			}
			printf("child : enter the string : ");
			__fpurge(stdin);
			scanf("%[^\n]",ruff);
			write(fd2[1],ruff,strlen(ruff));
		}
		printf("\n\nchild :\nres : %d\n current : %d \n ",res,getpid());
	//	close(fd[0]);
	//	close(fd2[1]);
	}
	if(res)
	{
		char ruff[50],buff[5];
		int ret;
	//	close(fd[0]);
	//	close(fd2[1]);
		printf("\n\nparent :\nres : %d\n current : %d \n\n\n ",res,getpid());
		while(1)
		{
			printf("parent : enter the string : ");
			__fpurge(stdin);
			scanf("%[^\n]",ruff);
			write(fd[1],ruff,strlen(ruff));
			while(ret=read(fd2[0],buff,5))
			{
				write(1,buff,ret);
			}
		}
	//	close(fd[1]);
	//	close(fd2[0]);
	}
}
