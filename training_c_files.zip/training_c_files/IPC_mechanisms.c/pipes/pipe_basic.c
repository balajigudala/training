#include<stdio.h>	
#include<fcntl.h>	
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
int main()
{
	pid_t pid;
        char buff[100];
	int fd[2],res,fd1;
        res=pipe(fd);
	if(res<0)
	{
		printf("failed to create the pipe \n");
		exit(1);
	}
	pid=fork();
	if(pid<0)
	{
		printf("failed to create the child \n");
                exit(2);
	}
	else if(pid>0)
	{
		close(fd[0]);
		fd1=open("file1",O_RDWR);
		res=read(fd1,buff,99);
		buff[res]='\0';
		res=write(fd[1],buff,strlen(buff));
		if(res<0)
		{
			printf("failed to write in the parent \n");
			exit(3);
		}
		close(fd[1]);
		exit(3);
	}
	else
	{
		close(fd[1]);
	//	pid=read(fd[0],buff,100);
		if(pid<0)
		{
			printf("failed to write in the parent \n");
			exit(63);
		}
		buff[pid]='\0';
//		printf("%s \n",buff);
		write(1,"hello",strlen("hello"));
		close(fd[0]);
		exit(4);
	}
}
