#include<stdio.h>	
#include<fcntl.h>	
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
int main()
{
	pid_t pid;
        char buff[100];
	int fd[2],fd1[2],res,res1,fd2;
        res=pipe(fd);
        res1=pipe(fd1);
	if(res<0||res<0)
	{
		printf("failed to create the pipe \n");
		exit(1);
	}
	pid=fork();
	if(pid<0)
	{
		printf("failed to create the child \n");
                exit(2);
	}
	else if(pid>0)
	{
		close(fd[0]);
		close(fd1[1]);
	//	fd2=open("file1",O_RDWR);
	//	res=read(fd2,buff,99);
	//	buff[res]='\0';
	        res=write(fd[1],"tHIS iS bALU",12);
	//	res=write(fd[1],buff,strlen(buff));
		if(res<0)
		{
			printf("failed to write in the parent \n");
			exit(3);
		}
		res=read(fd1[0],buff,99);
		buff[res]='\0';
		write(1,buff,strlen(buff));
		close(fd[1]);
		close(fd1[0]);
		exit(3);
	}
	else
	{
		int i;
		close(fd[1]);
		close(fd1[0]);
		pid=read(fd[0],buff,100);
		if(pid<0)
		{
			printf("failed to write in the parent \n");
			exit(63);
		}
		buff[pid]='\0';
		for(i=0;buff[i]!='\0';i++)
		{
			if(buff[i]>='a'&&buff[i]<='z')
				buff[i]=buff[i]-('a'-'A');
			else if(buff[i]>='A'&&buff[i]<='Z')
				buff[i]=buff[i]+('a'-'A');
		}
//		printf("%s \n",buff);
		write(fd1[1],buff,strlen(buff));
		close(fd[0]);
		close(fd1[1]);
		exit(4);
	}
}
