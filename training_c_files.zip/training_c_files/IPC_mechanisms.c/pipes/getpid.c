#include<stdio.h>    // for printf()
#include<stdlib.h>   //for exit()
#include<unistd.h>  // for system calls getpid()
#include<signal.h>  // for raise and kill syscall

int main()
{
	pid_t pid;
	pid=getpid();
	printf("in main : \n current process pid : %d \n",pid);
	int res=fork();
	if(res<0)
	{
		printf("fork call failed to create the child \n");
		return 0;
	}
	if(res>0)
	{
		printf("entered\n");
		pid=getpid();
		printf("\n\nin parent : \nthe current process pid : %d \n",pid);
		printf("the return in parent : %d \n ",res);
		//exit(1); // mandatory for the vfork sys call.
		//raise(2);
	}
	printf("res= %d \n",res);
	if(res==0)
	{
		pid=getpid();
		printf("\n\nin child  : \nthe current process pid : %d \n",pid);
		printf("the return in child : %d \n ",res);
	}



}


