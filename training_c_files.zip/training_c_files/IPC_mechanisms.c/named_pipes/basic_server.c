#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<string.h>
int main()
{
	int res;
	char rbuff[5],wbuff[20];
	int fd;
	fd=open("fifofile",O_RDWR,0664);
//	printf("fififile fd = %d \n",fd);
	if(fd<0)
	{
		fd=mkfifo("fifofile",0777);
		if(fd<0)
		{
			printf("failed to create the fifo file \n");
			exit(1);
		}
		else
		{
			fd=open("fifofile",O_RDONLY);
			if(fd<0)
			{
				printf("failed to open the fifo file \n");
				exit(1);
			}
		}
	}
	while(res=read(fd,rbuff,5))
	{
	write(1,rbuff,res);
	}
}
