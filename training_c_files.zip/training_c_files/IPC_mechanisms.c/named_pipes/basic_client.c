#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<sys/stat.h>
int main()
{
	int res;
	int fd;
	char buff[100];
	fd=open("fifofile",O_RDWR);
	printf("fd : %d\n",fd);
	if(fd==-1)
	{
		printf("failed to create fifofile \n");
		exit(1);
	}
	printf("enter the msg to send : ");
	scanf("%[^\n]",buff);
	write(fd,buff,strlen(buff));

}



