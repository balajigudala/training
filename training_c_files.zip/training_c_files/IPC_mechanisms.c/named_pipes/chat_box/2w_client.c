//    program to understand the client side in named pipes
#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<string.h>
int main()
{       
        char fd1[2],rbuff[20],wbuff[20];
	int fd,res;
	while(1)
	{
		fd=open("fifofile",O_WRONLY);
		if(fd<0)
		{       
			printf("failed to open the fifo file in client \n");
			exit(1);
		}
		printf("\nenter the string message : " );
		__fpurge(stdin);
		scanf("%[^\n]s",rbuff);
		__fpurge(stdin);
		res=write(fd,rbuff,strlen(rbuff));
		if(res<0)
		{
			printf("failed to write the fifo file in client \n");
			exit(2);
		}
		close(fd);
		fd=open("fifofile",O_RDONLY);
		if(fd<0)
		{
			fd=mkfifo("fifofile",0664);
			if(fd<0)
			{
				printf("failed to create the fifo file \n");
				exit(1);
			}
			else
			{
				fd=open("fifofile",O_RDONLY);
				if(fd<0)
				{
					printf("failed to open the fifo file \n");
					exit(1);
				}
			}
		}
		res=read(fd,rbuff,20);
		if(res<0)
		{
			printf("failed to read the fifo file \n");
			exit(1);
		}
		rbuff[res]='\0';
		res=write(1,rbuff,res);
		if(res<0)
		{
			printf("failed to write the fifo file \n");
			exit(1);
		}
		close(fd);
	}
}
