//    program to understand the client side in named pipes
#include<stdio_ext.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
int main()
{       
        char fd1[2],rbuff[20],wbuff[20];
	int fd,res,i;
	fd=open("fifofile",O_WRONLY);
	if(fd<0)
	{       
		printf("failed to open the fifo file in client \n");
		exit(1);
	}
	printf("enter the string message : " );
	scanf("%[^\n]s",rbuff);
	for(i=0;rbuff[i]!='\0';i++)
	{
		if(rbuff[i]>='a'&&rbuff[i]<='z')
			rbuff[i]=rbuff[i]-('a'-'A');
		else if(rbuff[i]>='A'&&rbuff[i]<='Z')
			rbuff[i]=rbuff[i]+('a'-'A');
	}
	res=write(fd,rbuff,strlen(rbuff));
	if(res<0)
	{
		printf("failed to write the fifo file in client \n");
		exit(2);
	}
}
