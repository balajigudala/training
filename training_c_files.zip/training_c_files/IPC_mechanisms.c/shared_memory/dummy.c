#include<stdio.h>
#include<unistd.h>
void my_fun(void)
{
	printf("------ hello -----\n");
}
int main()
{
	signal(2,my_fun);
	signal(3,my_fun);
	while(1)
	{
		printf("pid : %d \n",getpid());
		sleep(4);
	}
}
