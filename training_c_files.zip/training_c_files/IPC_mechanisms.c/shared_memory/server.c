#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/shm.h>
#define KEY 0x11223344
int main()
{
	char *ptr;
	int shmid,ret;
        shmid=shmget(KEY,200,IPC_CREAT|0664);
	if(shmid<0)
	{
		printf("failed to create the shared memory \n");
		exit(1);
	}
	ptr=shmat(shmid,NULL,0);
	if(ptr==NULL)
	{
		printf("failed to attach the shared memory to the current process i.e update dating the page table value with the returned value(virtual adress )from the shmat\n");
		exit(1);
	}
	ptr[0]='\0';
	while(ptr[0]!='\0');
	sleep(10);
	printf("recieved message  : %s \n",ptr);
	ret=shmdt(ptr);
	if(ret<0)
		printf("failed to detach the shared memory from process \n");

}

	
