#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/shm.h>
#define KEY 0x11223344
int main()
{
	char *ptr;
	int shmid,ret;
        shmid=shmget(KEY,200,0);
	if(shmid<0)
	{
		printf("failed to create the shared memory \n");
		exit(1);
	}
	ptr=shmat(shmid,NULL,0);
	if(ptr==NULL)
	{
		printf("failed to attach the shared memory to the current process i.e update dating the page table value with the returned value(virtual adress )from the shmat\n");
		exit(1);
	}
	printf("enter the meassage : ");
	scanf("%[^\n]s",ptr);
	struct shmid_ds info;
//	struct ipc_perm data;
	shmctl(shmid,IPC_STAT,&info);
	//printf("time : %f/%f/%f\n",info.data.shm_atime,info.data.shm_dtime,info.data.shm_ctime);
	printf("cpid : %hu\n",info.shm_perm.__key);
//	printf("no of attaches : %hu \n",info.shm_nattch);
	ret=shmdt(ptr);
	if(ret<0)
		printf("failed to detach the shared memory from the process \n");
        
}

