#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<sys/sem.h>
#define KEY 0x11223344
int main()
{
	char *ptr;
	struct sembuf buff;
	int shmid,semid,ret;
        shmid=shmget(KEY,400,IPC_CREAT|0664);
	if(shmid<0)
	{
		printf("failed to create the shared memory \n");
		exit(1);
	}
	semid=semget(KEY,1,IPC_CREAT|0664);
	ptr=shmat(shmid,NULL,0);
	ret=semctl(semid,0,SETVAL,0);
//ret=semctl(semid,1,SETVAL,0);
	buff.sem_num=0;
	buff.sem_op=-1;
	buff.sem_flg=0;
	ret=semop(semid,&buff,1);
	if(ptr==NULL)
	{
		printf("failed to attach the shared memory to the current process i.e update dating the page table value with the returned value(virtual adress )from the shmat\n");
		exit(1);
	}
	printf("recieved message  : %s \n",ptr);
	//ret=shmdt(ptr);
	if(ret<0)
		printf("failed to detach the shared memory from process \n");
}
