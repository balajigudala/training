#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<sys/sem.h>
#define KEY 0x11223344
int main()
{
	char *ptr;
	int shmid,semid,ret;
	struct sembuf buff;
	semid=semget(KEY,1,0);
        shmid=shmget(KEY,400,0);
	if(shmid<0)
	{
		printf("failed to create the shared memory \n");
		exit(1);
	}
	ptr=shmat(shmid,NULL,0);
	if(ptr==NULL)
	{
		printf("failed to attach the shared memory to the current process i.e update dating the page table value with the returned value(virtual adress )from the shmat\n");
		exit(1);
	}
	printf("enter the meassage : ");
	scanf("%[^\n]s",ptr);
	buff.sem_num=0;
	buff.sem_op=1;
	buff.sem_flg=0;
	semop(semid,&buff,1);
	ret=shmdt(ptr);
	if(ret<0)
		printf("failed to detach the shared memory from the process \n");
}

