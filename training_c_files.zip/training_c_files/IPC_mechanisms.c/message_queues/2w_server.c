#include<stdio_ext.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/msg.h>
#include<sys/ipc.h>
#define MSG_TYPE 1
#define KEY 0x11223344
struct msg
{
//	struct msg *temp;
        long msgtype;
        long pid;
        char buff[100];
}message;
int main()
{
	char buffer[100],*res1;
	int ret,res,i;
	int msqid;
	while(1)
	{
		msqid=msgget(KEY,IPC_CREAT|0664);
		if(msqid<0)
		{
			printf("failed to create the message queue \n");
			exit(1);
		}
		printf("the server msgid : %d \n",msqid);
		ret=msgrcv(msqid,&message,sizeof(message),MSG_TYPE,0);
		printf("no of byte recieved : %d \n",ret);
		if(ret<0)
		{
			printf("failed to recieve the message \n");
			exit(2);
		}
		for(i=0;message.buff[i]!='\0';i++)
		{
			if(message.buff[i]>='a'&&message.buff[i]<='z')
				message.buff[i]=message.buff[i]-('a'-'A');
			else if(message.buff[i]>='A'&&message.buff[i]<='Z')
				message.buff[i]=message.buff[i]+('a'-'A');
		}
		printf("message recieved : %s \n ",message.buff);
	//	struct ipc_perm permission;
	//	printf("creator user ID : %d ",permission.cuid);
	//	printf("mode : %o ",permission.mode);

		printf("\nenter the message : ");
		scanf("%[^\n]s",buffer);
		__fpurge(stdin);
		//struct msg message;
		msqid=msgget(KEY,0);
		printf("the clients msqid : %d \n ",msqid);
		if(msqid<0)
		{
			printf("there is no message with that key \n");
			exit(1);
		}
		message.msgtype=MSG_TYPE;
		message.pid=getpid();
		if(message.pid<0)
		{
			printf("failed to get the pid \n");
			exit(1);
		}
		res1=strcpy(message.buff,buffer);
		if(res1==NULL)
		{
			printf("failed to copy the string  \n");
			exit(1);
		}
		printf("the adress : %p strlen : %ld \n ",res1,strlen(message.buff));
		//      msgsnd(msqid,&message,(2*sizeof(long int))+strlen(message.buff)+1,0);
		msgsnd(msqid,&message,sizeof(message),0);
	}
}

