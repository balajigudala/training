#include<stdio_ext.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/msg.h>
#define KEY 0x11223344
#define MSG_TYPE 1
struct msg 
{
	long msgtype;
	long pid;
	char buff[100];
}message;
int main()
{
	int msqid,res;
	char *ret,buffer[100];
	printf("enter the message : ");
	scanf("%[^\n]s",buffer);
	__fpurge(stdin);
	//struct msg message;
	msqid=msgget(KEY,0);
	printf("the clients msqid : %d \n ",msqid);
	if(msqid<0)
	{
		printf("there is no message with that key \n");
		exit(1);
	}
	message.msgtype=MSG_TYPE;
	message.pid=getpid();
	if(message.pid<0)
        {
                printf("failed to get the pid \n");
                exit(1);
        }
	ret=strcpy(message.buff,buffer);
	if(ret==NULL)
        {
                printf("failed to copy the string  \n");
                exit(1);
        }
	printf("the adress : %p strlen : %ld \n ",ret,strlen(message.buff));
//	msgsnd(msqid,&message,(2*sizeof(long int))+strlen(message.buff)+1,0);
	msgsnd(msqid,&message,sizeof(message),0);
}
