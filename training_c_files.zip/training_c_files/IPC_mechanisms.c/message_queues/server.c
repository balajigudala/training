#include<stdio_ext.h>
#include<stdlib.h>
#include<string.h>
#include<sys/msg.h>
#include<sys/ipc.h>
#define MSG_TYPE 1
#define KEY 0x11223344
struct msg
{
//	struct msg *temp;
        long msgtype;
        long pid;
        char buff[100];
}message;
int main()
{
	char rbuff[100];
	int ret,i;
	int msqid=msgget(KEY,IPC_CREAT|0664);
	if(msqid<0)
	{
		printf("failed to create the message queue \n");
		exit(1);
	}
	printf("the server msgid : %d \n",msqid);
	ret=msgrcv(msqid,&message,sizeof(message),MSG_TYPE,0);
	printf("no of byte recieved : %d \n",ret);
	if(ret<0)
	{
		printf("failed to recieve the message \n");
		exit(2);
	}
	for(i=0;message.buff[i]!='\0';i++)
	{
		if(message.buff[i]>='a'&&message.buff[i]<='z')
			message.buff[i]=message.buff[i]-('a'-'A');
		else if(message.buff[i]>='A'&&message.buff[i]<='Z')
			message.buff[i]=message.buff[i]+('a'-'A');
	}
	printf("message recieved : %s \n ",message.buff);
	struct ipc_perm permission;
	printf("creator user ID : %d ",permission.cuid);
	printf("mode : %o ",permission.mode);
}

