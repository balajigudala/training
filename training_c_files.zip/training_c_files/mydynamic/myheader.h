#include<stdio.h>
int add(int ,int );
int sub(int ,int );
