int sub(int num1,int num2)
{
	int sub;
	return(sub=num1-num2);
}
