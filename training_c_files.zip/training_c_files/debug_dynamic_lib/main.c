#include<stdio.h>
int add(int,int);
int sub(int,int);
int main()
{
	int num1,num2,res;
	printf("\nenter the two intege value : ");
	scanf("%d%d",&num1,&num2);
	res=add(num1,num2);
	printf("\nres = %d\n",res);
}
