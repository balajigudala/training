int add(int num1,int num2)
{
	int sum;
	return(sum=num1+num2);
}
