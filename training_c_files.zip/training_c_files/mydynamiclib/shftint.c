void shftint(int *arr1,int m,int n)
{
	int i,j,temp;
	for(i=0;i<m;i++)
	{
		temp=arr1[0];
		for(j=0;j<n;j++)
		{
			arr1[j]=arr1[j+1];
		}
		arr1[n-1]=temp;
	}
}
