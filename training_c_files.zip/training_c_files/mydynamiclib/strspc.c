void strspc(char *arr1)
{
	int i,j,count=0;
	for(i=0,j=0;arr1[i]!='\0';i++)
	{
		if(arr1[i]==' ')
			count++;
		if(arr1[i]!=' ')
			count=0;
		if(count>1)
			continue;
		arr1[j]=arr1[i];
		j++;
	}
	arr1[j]='\0';
}
