#include<stdio.h>
int add(int,int);
inline int add(int a,int b)
{
	return(a+b);
}
int main()
{
	int x,y,z;
	printf("enter the two integer values : ");
	scanf("%d%d",&x,&y);
	printf("sum = %d \n",z=add(x,y));
}

